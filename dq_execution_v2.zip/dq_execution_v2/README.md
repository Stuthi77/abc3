# LakeWatch DQ Framework (pipeline-metadata-free build)

## Structure vs original repo
| Original | This build | Notes |
|---|---|---|
| dq_run.py | dq_run.py | widget-driven (catalog/schema); no calculate_dq_table_metrics call |
| config.yaml | config.yaml | adds result/cleaned catalog+schema |
| dq_framework/* (executor, query_builder, generic_rules, dq_logger, error logger, move_bad_records, validators, constants, utils) | same modules | pipeline_metadata removed; serverless-safe caching; backtick-quoted columns; incremental batch + clean promotion + Critical hold-back; SELECT * builders; several SQL bug fixes (marked FIX:) |
| dq_framework/email_alert.py | dq_framework/email_alert.py | driven by dq_logs (not dq_table_metrics/pipeline_metadata); credentials via dbutils.secrets (scope "dq", keys "alert_mail"/"password"); dq_alerts dedup kept |
| dq_framework/table_metrics.py | (intentionally omitted) | profiling + flag update depended on pipeline_metadata.table_id; Success/Failure is derivable from dq_logs |
| dq logs ddl/dq_tables_ddl.py, dq_rules.py | ddl/dq_tables_ddl.py | creates dq_rules, dq_logs, dq_bad_records, dq_error_logs, dq_alerts in cdw_dev.domain_config + ml_cleaned_datasets schema; no pipeline_metadata / dq_table_metrics DDL |
| dq logs ddl/pipeline_metadata.py | (intentionally omitted) | per requirement |
| DQ Documentation/* | this README | |

## Run order
1. ddl/dq_tables_ddl.py (once per environment)
2. Insert rules into cdw_dev.domain_config.dq_rules
3. dq_run.py (widgets: catalog_name, schema_name) — validates, quarantines, promotes clean records
4. dq_framework/email_alert.py (widgets: catalog_name, schema_name, receiver_emails) — schedule after dq_run

## Secrets required for alerting
databricks secrets create-scope dq
databricks secrets put-secret dq alert_mail   # sender address
databricks secrets put-secret dq password     # SMTP app password

## Restored in this version (per request)
- ddl: cdw_dev.domain_config.dq_pipeline_metadata (pipeline_key/name, identity table_id) — executor enriches rules with pipeline_key/pipeline_name via TOLERANT lookup (nulls if unregistered; never crashes)
- ddl + dq_framework/table_metrics.py: cdw_dev.domain_config.dq_table_metrics — TABLE/COLUMN/KPI metric levels, Delta-history schema-change detection, kpi_metric_value history (KPI_CHECK trends against it), and a flag column set to Success/Failure per table per run. Toggles in config.yaml.
- dq_requeue.py: remediation notebook — after fixing/disabling a wrong rule, re-validates quarantined records against CURRENT rules; passing records merge into ml_cleaned_datasets; their dq_bad_records rows get reprocess_status='REPROMOTED' (audit kept); REQUEUE entry written to dq_logs. Supports dry_run and filters (table/rule_id/violation_id/since_date). Existing installs must run the ALTER TABLE in ddl to add reprocess_status/reprocessed_at.

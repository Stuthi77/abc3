# Databricks notebook source
# MAGIC %md
# MAGIC # LakeWatch DQ — Email Alerting (design doc §7.2)
# MAGIC Rebuilt from the original `email_alert.py` with these changes:
# MAGIC - **No `pipeline_metadata` / `dq_table_metrics`** — failure detection and the
# MAGIC   summary come straight from `dq_logs` (+ `dq_error_logs`), scoped by
# MAGIC   catalog + schema instead of pipeline_key
# MAGIC - **No hardcoded credentials** — sender email/password come from a
# MAGIC   Databricks secret scope. ⚠️ The original file had a real Gmail app
# MAGIC   password in plain text in a public repo — REVOKE it and use secrets:
# MAGIC   `databricks secrets create-scope dq`
# MAGIC   `databricks secrets put-secret dq alert_mail`
# MAGIC   `databricks secrets put-secret dq password`
# MAGIC - Duplicate-alert suppression via `dq_alerts` kept (per recipient per day)

# COMMAND ----------

# Databricks notebook source
# MAGIC %md
# MAGIC # LakeWatch DQ — Email Alerting via Logic App
# MAGIC Sends one email per violated table, summarising every rule violation
# MAGIC detected in `dq_logs` (+ threshold breaches from `dq_rules`).
# MAGIC
# MAGIC **Alert conditions** — a row in `dq_logs` triggers when EITHER holds,
# MAGIC AND the rule has alerting enabled (`dq_rules.email_alert_enabled != false`):
# MAGIC 1. `status` is `Fail` or `Error` (case-insensitive), OR
# MAGIC 2. `violation_count` > `violation_threshold` configured in `dq_rules`
# MAGIC
# MAGIC Rules where `email_alert_enabled = false` are excluded entirely. NULL
# MAGIC defaults to enabled so existing rules keep alerting unchanged.
# MAGIC
# MAGIC **Recipients** — resolved from GROUP MEMBERSHIP, not table_owner:
# MAGIC 1. If any violated rule has an explicit `alert_group_id` override, that
# MAGIC    group's members receive the alert.
# MAGIC 2. Otherwise the table's own group (`dq_tables.group_id`) is used.
# MAGIC 3. Every group member (`dq_users` array_contains) is emailed as
# MAGIC    `{user_id}@latentview.com` (see SENDER_DOMAIN constant).
# MAGIC
# MAGIC **Mail transport** — Azure Logic App HTTP Webhook.

# COMMAND ----------

import json
import requests
from collections import defaultdict
import html
import re

from pyspark.sql import Row
from pyspark.sql import types as T

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

CONFIG_CATALOG = "dev_platform"
CONFIG_SCHEMA  = "data_quality_config"

LOGS_TABLE          = f"{CONFIG_CATALOG}.{CONFIG_SCHEMA}.dq_logs"
RULES_TABLE         = f"{CONFIG_CATALOG}.{CONFIG_SCHEMA}.dq_rules"
TABLES_CONFIG_TABLE = f"{CONFIG_CATALOG}.{CONFIG_SCHEMA}.dq_tables"
USERS_TABLE         = f"{CONFIG_CATALOG}.{CONFIG_SCHEMA}.dq_users"

# Recipient email = {user_id}@{SENDER_DOMAIN}.
# dq_users stores only the user_id prefix (the part before "@").
SENDER_DOMAIN = "latentview.com"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def widget_value(name: str) -> str:
    return dbutils.widgets.get(name).strip()


def sql_literal(value: str) -> str:
    return value.replace("'", "''")


def is_email_address(value: str) -> bool:
    return bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", value or ""))


def resolve_group_recipients(catalog_name, schema_name, table_name,
                             violated_rule_ids):
    effective_group_id = None

    if violated_rule_ids:
        ids_lit = ", ".join(f"'{sql_literal(str(r))}'" for r in violated_rule_ids)
        row = spark.sql(f"""
            SELECT alert_group_id FROM {RULES_TABLE}
            WHERE rule_id IN ({ids_lit}) AND alert_group_id IS NOT NULL
            LIMIT 1
        """).first()
        if row and row["alert_group_id"]:
            effective_group_id = row["alert_group_id"]

    if not effective_group_id:
        row = spark.sql(f"""
            SELECT group_id FROM {TABLES_CONFIG_TABLE}
            WHERE catalog_name = '{sql_literal(catalog_name)}'
              AND schema_name  = '{sql_literal(schema_name)}'
              AND table_name   = '{sql_literal(table_name)}'
            LIMIT 1
        """).first()
        if row and row["group_id"]:
            effective_group_id = row["group_id"]

    if not effective_group_id:
        return [], None

    members = spark.sql(f"""
        SELECT user_id FROM {USERS_TABLE}
        WHERE array_contains(group_id, '{sql_literal(effective_group_id)}')
    """).collect()

    recipients = [f"{r['user_id']}@{SENDER_DOMAIN}"
                  for r in members if r["user_id"]]
    return recipients, effective_group_id


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def send_dq_owner_alerts(catalog_name="", schema_name="", table_name="",
                         lookback_hours=168, dry_run=True,
                         logic_app_url=None):
    params = {
        "catalog_name":   (catalog_name  or "").strip(),
        "schema_name":    (schema_name   or "").strip(),
        "table_name":     (table_name    or "").strip(),
        "lookback_hours": int(lookback_hours),
        "dry_run":        bool(dry_run),
    }
    if params["lookback_hours"] <= 0:
        raise ValueError("lookback_hours must be positive")

    print("Alert parameters:")
    for k in ["catalog_name", "schema_name", "table_name",
              "lookback_hours", "dry_run"]:
        print(f"  {k}: {params[k]}")

    scope_filters = [
        f"l.batch_timestamp >= current_timestamp() - "
        f"INTERVAL {params['lookback_hours']} HOURS",
        "COALESCE(r.email_alert_enabled, true) = true",
    ]
    if params["catalog_name"]:
        scope_filters.append(
            f"l.catalog_name = '{sql_literal(params['catalog_name'])}'")
    if params["schema_name"]:
        scope_filters.append(
            f"l.schema_name = '{sql_literal(params['schema_name'])}'")
    if params["table_name"]:
        scope_filters.append(
            f"l.table_name = '{sql_literal(params['table_name'])}'")

    scope_clause = " AND\n      ".join(scope_filters)

    ALERT_CONDITION = """(
          UPPER(l.status) IN ('FAIL', 'ERROR')
          OR l.violation_count > COALESCE(r.violation_threshold, 0)
        )"""

    cte = f"""
    WITH filtered_logs AS (
      SELECT
        l.rule_id,
        l.catalog_name,
        l.schema_name,
        l.table_name,
        l.column_name,
        l.condition_category,
        l.condition_type,
        l.status,
        l.severity,
        l.violation_count,
        COALESCE(r.violation_threshold, 0) AS violation_threshold,
        CASE
          WHEN UPPER(l.status) = 'ERROR' THEN 'RULE_EXECUTION_ERROR'
          WHEN UPPER(l.status) = 'FAIL'  THEN 'STATUS_FAIL'
          WHEN l.violation_count > COALESCE(r.violation_threshold, 0)
                                         THEN 'THRESHOLD_BREACH'
        END AS alert_reason,
        l.batch_timestamp
      FROM {LOGS_TABLE} l
      LEFT JOIN {RULES_TABLE} r ON l.rule_id = r.rule_id
      WHERE {scope_clause}
        AND {ALERT_CONDITION}
    )
    """

    violated_tables_df = spark.sql(cte + """
    SELECT
      f.catalog_name,
      f.schema_name,
      f.table_name,
      COUNT(DISTINCT f.rule_id)                                                 AS violated_rule_count,
      COUNT(DISTINCT CASE WHEN UPPER(f.status)='FAIL'  THEN f.rule_id END)      AS failed_rule_count,
      COUNT(DISTINCT CASE WHEN UPPER(f.status)='ERROR' THEN f.rule_id END)      AS errored_rule_count,
      COUNT(DISTINCT CASE WHEN f.alert_reason='THRESHOLD_BREACH'
                          THEN f.rule_id END)                                   AS threshold_breach_rule_count,
      SUM(f.violation_count)                                                    AS total_violations,
      MAX(f.batch_timestamp)                                                    AS latest_batch_timestamp,
      collect_set(f.rule_id)                                                    AS violated_rule_ids
    FROM filtered_logs f
    GROUP BY f.catalog_name, f.schema_name, f.table_name
    ORDER BY latest_batch_timestamp DESC,
             f.catalog_name, f.schema_name, f.table_name
    """)

    violation_details_df = spark.sql(cte + """
    SELECT
      f.catalog_name,
      f.schema_name,
      f.table_name,
      f.column_name,
      f.condition_category,
      f.condition_type,
      f.status,
      f.alert_reason,
      f.severity,
      MAX(f.violation_threshold) AS violation_threshold,
      COUNT(DISTINCT f.rule_id)  AS violated_rule_count,
      SUM(f.violation_count)     AS violation_count,
      MAX(f.batch_timestamp)     AS latest_batch_timestamp
    FROM filtered_logs f
    GROUP BY f.catalog_name, f.schema_name, f.table_name,
             f.column_name, f.condition_category, f.condition_type,
             f.status, f.alert_reason, f.severity
    ORDER BY latest_batch_timestamp DESC,
             f.catalog_name, f.schema_name, f.table_name, f.column_name
    """)

    print(f"Violation detail rows : {violation_details_df.count()}")
    print(f"Violated tables       : {violated_tables_df.count()}")

    if violation_details_df.count() == 0:
        print("No Fail/Error/threshold-breach rows with alerting enabled "
              "found for the selected scope and window.")

    display(violated_tables_df)
    display(violation_details_df)

    violated_table_rows   = [r.asDict(recursive=True)
                             for r in violated_tables_df.collect()]
    violation_detail_rows = [r.asDict(recursive=True)
                             for r in violation_details_df.collect()]

    detail_rows_by_table = defaultdict(list)
    for row in violation_detail_rows:
        detail_rows_by_table[
            (row["catalog_name"], row["schema_name"], row["table_name"])
        ].append(row)

    alert_messages  = []
    preview_rows    = []
    unresolved_rows = []

    for table_row in violated_table_rows:
        cat = table_row["catalog_name"]
        sch = table_row["schema_name"]
        tbl = table_row["table_name"]
        fq  = f"{cat}.{sch}.{tbl}"
        violated_rule_ids = table_row.get("violated_rule_ids") or []

        recipients, resolved_group_id = resolve_group_recipients(
            cat, sch, tbl, violated_rule_ids)
        recipients = [r for r in recipients if is_email_address(r)]
        detail_rows = detail_rows_by_table.get((cat, sch, tbl), [])

        if not recipients:
            unresolved_rows.append({
                "catalog_name":      cat,
                "schema_name":       sch,
                "table_name":        tbl,
                "resolved_group_id": resolved_group_id or "",
                "reason": (
                    "No group resolved: neither a rule-level alert_group_id "
                    "nor dq_tables.group_id is set"
                    if not resolved_group_id else
                    "Resolved group has no members with a valid email"
                ),
            })
            continue

        vc  = int(table_row["violated_rule_count"]        or 0)
        fc  = int(table_row["failed_rule_count"]          or 0)
        ec  = int(table_row["errored_rule_count"]         or 0)
        tbc = int(table_row["threshold_breach_rule_count"] or 0)
        tv  = int(table_row["total_violations"]           or 0)
        lbt = table_row["latest_batch_timestamp"]

        detail_html = "".join(
            f"<tr>"
            f"<td>{html.escape(str(r['column_name'] or ''))}</td>"
            f"<td>{html.escape(str(r['condition_category'] or ''))}</td>"
            f"<td>{html.escape(str(r['condition_type'] or ''))}</td>"
            f"<td>{html.escape(str(r['status'] or ''))}</td>"
            f"<td>{html.escape(str(r['alert_reason'] or ''))}</td>"
            f"<td>{html.escape(str(r['severity'] or ''))}</td>"
            f"<td style='text-align:right'>{int(r['violation_threshold'] or 0):,}</td>"
            f"<td style='text-align:right'>{int(r['violation_count'] or 0):,}</td>"
            f"<td>{html.escape(str(r['latest_batch_timestamp']))}</td>"
            f"</tr>"
            for r in detail_rows
        )

        html_body = f"""<html><body>
          <p>Hello,</p>
          <p>Data quality issues were detected for <b>{html.escape(fq)}</b>.</p>
          <ul>
            <li>Alert group : <b>{html.escape(resolved_group_id or 'N/A')}</b></li>
            <li>Rules with violations (total) : <b>{vc:,}</b></li>
            <li>&nbsp;&nbsp;• Status = Fail : <b>{fc:,}</b></li>
            <li>&nbsp;&nbsp;• Rule execution errors : <b>{ec:,}</b></li>
            <li>&nbsp;&nbsp;• Threshold breaches : <b>{tbc:,}</b></li>
            <li>Total violating records : <b>{tv:,}</b></li>
            <li>Latest batch : <b>{html.escape(str(lbt))}</b></li>
          </ul>
          <table border='1' cellspacing='0' cellpadding='6'>
            <tr>
              <th>Column</th><th>Category</th><th>Type</th>
              <th>Status</th><th>Reason</th><th>Severity</th>
              <th>Threshold</th><th>Violations</th><th>Latest batch</th>
            </tr>
            {detail_html}
          </table>
          <p><small>
            Audit-only rules still appear here when they breach status/threshold —
            that setting controls Silver filtering, not alerting.
            Rules with alerting disabled are excluded entirely.<br>
            Logs: {LOGS_TABLE} | Bad records: {CONFIG_CATALOG}.{CONFIG_SCHEMA}.dq_bad_records |
            Errors: {CONFIG_CATALOG}.{CONFIG_SCHEMA}.dq_error_logs
          </small></p>
        </body></html>"""

        subject = (f"[DQ Alert] {fq}: {fc} failed / {ec} errored / "
                   f"{tbc} threshold-breached rule(s)")

        alert_messages.append({
            "table_name": fq, "recipients": recipients,
            "subject": subject, "html_body": html_body,
        })
        preview_rows.append({
            "catalog_name": cat, "schema_name": sch, "table_name": tbl,
            "resolved_group_id": resolved_group_id or "",
            "recipients": ", ".join(recipients),
            "violated_rule_count": vc, "failed_rule_count": fc,
            "errored_rule_count": ec, "threshold_breach_rule_count": tbc,
            "total_violations": tv,
            "latest_batch_timestamp": str(lbt),
            "send_mode": "DRY_RUN" if params["dry_run"] else "SEND",
        })

    preview_schema = T.StructType([
        T.StructField("catalog_name",               T.StringType(),  True),
        T.StructField("schema_name",                T.StringType(),  True),
        T.StructField("table_name",                 T.StringType(),  True),
        T.StructField("resolved_group_id",          T.StringType(),  True),
        T.StructField("recipients",                 T.StringType(),  True),
        T.StructField("violated_rule_count",        T.IntegerType(), True),
        T.StructField("failed_rule_count",          T.IntegerType(), True),
        T.StructField("errored_rule_count",         T.IntegerType(), True),
        T.StructField("threshold_breach_rule_count",T.IntegerType(), True),
        T.StructField("total_violations",           T.LongType(),    True),
        T.StructField("latest_batch_timestamp",     T.StringType(),  True),
        T.StructField("send_mode",                  T.StringType(),  True),
    ])
    unresolved_schema = T.StructType([
        T.StructField("catalog_name",      T.StringType(), True),
        T.StructField("schema_name",       T.StringType(), True),
        T.StructField("table_name",        T.StringType(), True),
        T.StructField("resolved_group_id", T.StringType(), True),
        T.StructField("reason",            T.StringType(), True),
    ])

    preview_df    = (spark.createDataFrame(preview_rows, preview_schema)
                     if preview_rows else
                     spark.createDataFrame([], preview_schema))
    unresolved_df = (spark.createDataFrame(unresolved_rows, unresolved_schema)
                     if unresolved_rows else
                     spark.createDataFrame([], unresolved_schema))

    print(f"Prepared alerts   : {len(alert_messages)}")
    print(f"Unresolved tables : {unresolved_df.count()}")
    display(preview_df)
    display(unresolved_df)

    if not alert_messages:
        print("No alert emails to prepare for this scope.")
        return {"preview_df": preview_df, "unresolved_df": unresolved_df,
                "send_results_df": None,
                "alerts_prepared": 0, "alerts_sent": 0}

    if params["dry_run"]:
        print("DRY RUN — no emails sent. "
              "Review preview_df and re-run with dry_run=False to send.")
        return {"preview_df": preview_df, "unresolved_df": unresolved_df,
                "send_results_df": None,
                "alerts_prepared": len(alert_messages), "alerts_sent": 0}

    # ------------------------------------------------------------------
    # EXACT LOGIC FROM ORIGINAL SCRIPT (Resolving LA-Email-Export-Url)
    # ------------------------------------------------------------------
    if not logic_app_url:
        try:
            logic_app_url = dbutils.secrets.get(
                scope="scope_kv_smazbi", 
                key="LA-Email-Export-Url"
            )
        except Exception as e:
            raise ValueError(f"Could not fetch Logic App URL from secrets: {e}")

    send_results = []
    
    for alert in alert_messages:
        email_to_list = ", ".join(alert["recipients"])
        
        # EXACT PAYLOAD FROM ORIGINAL SCRIPT (includes "files" array)
        payload = {
            "files": [],  # <--- Essential: Logic app fails without this key!
            "email_to": email_to_list,
            "subject": alert["subject"],
            "body": alert["html_body"],
            "body_footer": "Automated message generated by LakeWatch DQ Monitoring."
        }

        try:
            response = requests.post(logic_app_url, json=payload, timeout=60)
            
            if response.status_code >= 300:
                raise RuntimeError(f"Logic App failed ({response.status_code}): {response.text}")
                
            status = "SENT"
        except Exception as e:
            status = f"FAILED: {e}"
        
        send_results.append(Row(
            table_name=alert["table_name"],
            recipients=email_to_list,
            status=status
        ))

    send_results_df = (spark.createDataFrame(send_results)
                       if send_results else
                       spark.createDataFrame(
                           [], "table_name string, recipients string, status string"))
    display(send_results_df)
    
    sent = send_results_df.filter("status = 'SENT'").count()
    print(f"Sent {sent} / {len(alert_messages)} alert email(s) via Logic App.")
    
    return {"preview_df": preview_df, "unresolved_df": unresolved_df,
            "send_results_df": send_results_df,
            "alerts_prepared": len(alert_messages), "alerts_sent": sent}


# COMMAND ----------
# MAGIC %md
# MAGIC ### Standalone execution (widgets)
# MAGIC Run directly or via `dbutils.notebook.run`. To call from another notebook:
# MAGIC `%run ./email_alert` then call `send_dq_owner_alerts(...)` directly.

# COMMAND ----------

RUN_FROM_WIDGETS = True   # set False when using %run-import pattern

if RUN_FROM_WIDGETS:
    dbutils.widgets.text("catalog_name",   "")
    dbutils.widgets.text("schema_name",    "")
    dbutils.widgets.text("table_name",     "")
    dbutils.widgets.text("lookback_hours", "168")
    dbutils.widgets.dropdown("dry_run",    "true", ["true", "false"])

    result = send_dq_owner_alerts(
        catalog_name   = widget_value("catalog_name"),
        schema_name    = widget_value("schema_name"),
        table_name     = widget_value("table_name"),
        lookback_hours = int(widget_value("lookback_hours") or "168"),
        dry_run        = widget_value("dry_run").lower() == "true",
    )
    print(f"alerts_prepared={result['alerts_prepared']}  "
          f"alerts_sent={result['alerts_sent']}")
import json
from pyspark.sql.utils import AnalysisException

from dq_error_logger import dq_error_logs
from generic_rules import *
from utils import *  # includes qualified, bq, unbq, fill_placeholders
from validate_json import *
from constants import *

# Standard rule dispatch (pipeline_metadata is intentionally NOT used anywhere)
CONDITION_FUNCTIONS = {
    "NOT_NULL": construct_not_null_query,
    "BLANK": construct_blank_query,
    "LENGTH_CHECK": construct_length_check_query,
    "NOT_NULL_LENGTH_CHECK": construct_not_null_length_check_query,
    "MUST_HAVE_VALUE": construct_must_have_value_query,
    "REGEX_MATCH": construct_regex_match_query,
    "TIME_STAMP_CHECK": construct_time_stamp_check_query,
    "UNIQUE": construct_unique_query,
    "DUPLICATE": construct_duplicate_query,
    "RANGE_CHECK": construct_range_check_query,
    "FORMAT_CHECK": construct_format_check_query,
    "VALUE_THRESHOLD": construct_value_threshold_query,
    "OUTLIER_DETECTION": construct_outlier_detection_query,
    "DATE_RANGE": construct_date_range_check_query,
    "MAPPING_CHECK": construct_mapping_check_query,
    "CASE_STANDARDIZATION": construct_case_standardization_query,
    "REFERENCE_CHECK": construct_reference_check_query,
    "REFERENCE_CHECK_CUSTOM": construct_reference_check_custom_query,
}

# Aliases so rules written with design-doc names still resolve
TYPE_ALIASES = {
    "BLANK_CHECK": "BLANK",
    "REGEX": "REGEX_MATCH",
    "TIMESTAMP_CHECK": "TIME_STAMP_CHECK",
    "UNIQUE_VALUE_CHECK": "UNIQUE",
    "DUPLICATE_CHECK": "DUPLICATE",
    "OUTLIER": "OUTLIER_DETECTION",
    "CUSTOM_BUSINESS_RULE": "CUSTOM_RULE",
    "KPI_METRICS": "KPI_CHECK",
    "KPI_METRICS_CHECK": "KPI_CHECK",
    "ROW_COUNT_TREND_CHECK": "ROW_COUNT_TREND",
    "CROSS_TABLE_CHECK": "REFERENCE_CHECK",
    "LOOKUP_CHECK": "REFERENCE_CHECK",
    "REFERENTIAL_INTEGRITY": "REFERENCE_CHECK",
    "REFERENTIAL_INTEGRITY_CHECK": "REFERENCE_CHECK",
    "CUSTOM_REFERENCE_CHECK": "REFERENCE_CHECK_CUSTOM",
    "PARTIAL_REFERENCE_CHECK": "REFERENCE_CHECK_CUSTOM",
    "SUBSTRING_REFERENCE_CHECK": "REFERENCE_CHECK_CUSTOM",
}

# Rules whose comma-separated column_name is a COMPOSITE key (do NOT expand)
COMPOSITE_COLUMN_TYPES = {"DUPLICATE", "UNIQUE"}
# Table-level rules — executed directly in dq_executor, no per-record quarantine
TABLE_LEVEL_TYPES = {"ROW_COUNT_TREND", "KPI_CHECK"}
# Rules where column_name may be empty
NO_COLUMN_TYPES = {"CUSTOM_RULE", "ROW_COUNT_TREND", "KPI_CHECK"}


def normalize_type(condition_type):
    key = str(condition_type or "").strip().upper()
    return TYPE_ALIASES.get(key, key)


def construct_query(spark, result_catalog, result_schema, pipeline_key, rule_id,
                    catalog_name, schema_name, table_name,
                    column_name, condition_type, condition_criteria,
                    condition_category=None, batch_timestamp=None,
                    real_catalog=None, real_schema=None, real_table=None):
    """Builds the violation-selecting SQL for a rule.

    catalog_name/schema_name/table_name -> where the query should RUN
      (may be '', '', '<temp view>' in incremental mode).
    real_catalog/real_schema/real_table -> the true source identifiers,
      used only for {placeholders} in CUSTOM_RULE queries."""
    try:
        ctype = normalize_type(condition_type)

        # Validate column existence (skipped for SQL-driven / table-level rules)
        if ctype not in NO_COLUMN_TYPES:
            df = spark.table(qualified(catalog_name, schema_name, table_name)).limit(1)
            table_columns = df.columns
            columns = [unbq(col) for col in (column_name or "").split(",") if col.strip()]
            for column in columns:
                if column not in table_columns:
                    error_message = f"Column '{column}' not found in table '{table_name}'."
                    dq_error_logs(spark, result_catalog, result_schema, rule_id, pipeline_key,
                                  None, real_catalog or catalog_name,
                                  real_schema or schema_name,
                                  real_table or table_name, error_message, batch_timestamp)
                    raise ValueError(error_message)

        # Custom business rules (SQL supplied in criteria)
        if ctype == "CUSTOM_RULE" or condition_category == "Business Integrity":
            try:
                parsed_value = json.loads(condition_criteria)
            except json.JSONDecodeError:
                try:  # tolerate single-quoted JSON from the rules UI
                    parsed_value = json.loads(condition_criteria.replace("'", '"'))
                except Exception as e:
                    raise ValueError(f"Invalid JSON in condition_criteria: {e}")
            custom_query = (parsed_value.get("custom_query")
                            or parsed_value.get("query")
                            or parsed_value.get("sql"))
            if not custom_query:
                raise ValueError("Missing 'custom_query' key in condition_criteria JSON")
            custom_query = str(custom_query).strip().rstrip(";").strip()
            if not custom_query.upper().startswith(("SELECT", "WITH")):
                raise ValueError("custom_query must be a SELECT/WITH statement")
            # .replace-based fill: other braces in the SQL no longer break it
            return fill_placeholders(custom_query,
                                     real_catalog or catalog_name,
                                     real_schema or schema_name,
                                     real_table or table_name)

        if ctype == "KPI_CHECK":
            return construct_kpi_aggregation_query(
                spark, real_catalog or catalog_name, real_schema or schema_name,
                real_table or table_name, column_name, condition_criteria,
                result_catalog=result_catalog, result_schema=result_schema)

        condition_func = CONDITION_FUNCTIONS.get(ctype)
        if not condition_func:
            raise ValueError(f"Unsupported condition_type: {condition_type}")

        # Backtick-quote every column so special-character names
        # (2023_|_10, Bill-To_Cust, ...) are valid in generated SQL
        quoted_columns = ",".join(
            bq(c) for c in (column_name or "").split(",") if c.strip())
        return condition_func(spark, catalog_name, schema_name, table_name,
                              quoted_columns, condition_criteria)

    except ValueError as e:
        dq_error_logs(spark, result_catalog, result_schema, rule_id, pipeline_key, None,
                      real_catalog or catalog_name, real_schema or schema_name,
                      real_table or table_name, f"Value Error: {str(e)}", batch_timestamp)
        raise e
    except AnalysisException as e:
        dq_error_logs(spark, result_catalog, result_schema, rule_id, pipeline_key, None,
                      real_catalog or catalog_name, real_schema or schema_name,
                      real_table or table_name, f"Analysis Exception: {str(e)}", batch_timestamp)
        raise e
    except Exception as e:
        dq_error_logs(spark, result_catalog, result_schema, rule_id, pipeline_key, None,
                      real_catalog or catalog_name, real_schema or schema_name,
                      real_table or table_name, f"Unexpected Error: {str(e)}", batch_timestamp)
        raise e

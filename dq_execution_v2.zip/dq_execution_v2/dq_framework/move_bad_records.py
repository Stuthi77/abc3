from pyspark.sql import functions as F
import random
import time

from dq_error_logger import dq_error_logs

# Concurrent rule execution (ThreadPoolExecutor in dq_executor.py) means
# multiple rules can append to dq_bad_records at the same moment. A
# DELTA_CONCURRENT_APPEND / ROW_LEVEL_CHANGES conflict is transient — retrying
# is the mitigation Databricks documents for it, so we retry a few times with
# jittered backoff before giving up and logging the failure.
MAX_WRITE_RETRIES = 4
BASE_BACKOFF_SECONDS = 1.5


def move_bad_records_to_table(spark, result_catalog, result_schema, rule_id, pipeline_key,
                              catalog_name, schema_name, table_name,
                              violation_df, violation_id, batch_timestamp):
    """Same output schema as the original (br_id, violation_id, pipeline_key,
    catalog_name, schema_name, table_name, bad_record_data JSON, batch_timestamp)
    but written distributed instead of driver-side .collect() — the original
    would OOM on large violation sets (e.g. 300k+ records)."""
    try:
        # internal helper columns (_dq_row_id, _dq_*) must not leak into audit
        data_cols = [c for c in violation_df.columns if not c.startswith("_dq_")]
        if not data_cols:
            print("✅ No bad records found. Skipping insert.")
            return

        payload = (violation_df
                   .withColumn("br_id", F.concat(F.lit("dqbr_"), F.expr("uuid()")))
                   .withColumn("violation_id", F.lit(violation_id))
                   .withColumn("pipeline_key",
                               F.lit(str(pipeline_key) if pipeline_key is not None else None))
                   .withColumn("catalog_name", F.lit(catalog_name))
                   .withColumn("schema_name", F.lit(schema_name))
                   .withColumn("table_name", F.lit(table_name))
                   .withColumn("bad_record_data",
                               F.to_json(F.struct(*[F.col(c) for c in data_cols])))
                   .withColumn("batch_timestamp", F.lit(batch_timestamp))
                   .select("br_id", "violation_id", "pipeline_key", "catalog_name",
                           "schema_name", "table_name", "bad_record_data",
                           "batch_timestamp"))

        target_table = f"{result_catalog}.{result_schema}.dq_bad_records"

        last_error = None
        for attempt in range(1, MAX_WRITE_RETRIES + 1):
            try:
                payload.write.format("delta").mode("append").saveAsTable(target_table)
                if attempt > 1:
                    print(f"✅ dq_bad_records append succeeded on retry {attempt}.")
                return
            except Exception as write_err:
                last_error = write_err
                is_concurrency_conflict = "CONCURRENT" in str(write_err).upper()
                if not is_concurrency_conflict or attempt == MAX_WRITE_RETRIES:
                    raise
                sleep_seconds = BASE_BACKOFF_SECONDS * (2 ** (attempt - 1)) + random.uniform(0, 1)
                print(f"⚠️ Concurrent write conflict on dq_bad_records "
                      f"(attempt {attempt}/{MAX_WRITE_RETRIES}), retrying in "
                      f"{sleep_seconds:.1f}s: {write_err}")
                time.sleep(sleep_seconds)

    except Exception as e:
        print(f"❌ Error in move_bad_records_to_table: {str(e)}")
        dq_error_logs(spark, result_catalog, result_schema, rule_id, pipeline_key, None,
                      catalog_name, schema_name, table_name,
                      f"Error moving bad records: {str(e)}", batch_timestamp)
        raise


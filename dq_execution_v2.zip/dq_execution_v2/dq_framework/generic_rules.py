import json
import re
from datetime import datetime, timezone

from validate_json import *
from constants import *
from utils import qualified, bq, unbq

# ---------------------------------------------------------------------------
# NOTE vs original repo version:
#   * All row-level builders now SELECT * (full record) instead of just the
#     rule column — required so bad_record_data holds the complete record and
#     clean records can be identified via cdw_hash_key anti-join.
#   * Table references go through qualified() so the same builders run against
#     a batch TEMP VIEW (incremental) or the real table (full scan).
#   * pipeline_metadata is NOT referenced anywhere.
#   * A few SQL bugs from the original are fixed (marked with "FIX:").
# ---------------------------------------------------------------------------


def _null_check_condition(col, mode):
    """Builds the presence-check SQL expression for a single column, scoped
    to whichever 'check' mode this specific rule's condition_criteria asked
    for. This is purely per-rule -- it changes nothing about any other rule,
    since the mode always comes from that one rule's own criteria, defaulting
    to "all" (the original combined null+blank+placeholder behavior) when a
    rule doesn't specify one at all. Existing rules with no 'check' key are
    therefore byte-for-byte unaffected by this change.

    Modes:
      "all"              -> NULL OR blank OR placeholder (default, original behavior)
      "blank_only"        -> ONLY empty/whitespace-only string; NULL is NOT flagged
      "null_only"         -> ONLY a true SQL NULL; blank/placeholder are NOT flagged
      "placeholder_only"  -> ONLY a recognized null-equivalent placeholder (e.g. "N/A")
    """
    null_equivalents = [f"'{item.lower()}'" for item in NULL_EQUIVALENTS if item]
    is_null = f"{col} IS NULL"
    is_blank = f"TRIM(CAST({col} AS STRING)) = ''"
    is_placeholder = f"LOWER(TRIM(CAST({col} AS STRING))) IN ({', '.join(null_equivalents)})"

    mode = (mode or "all").strip().lower()
    if mode == "blank_only":
        return is_blank
    if mode == "null_only":
        return is_null
    if mode == "placeholder_only":
        return is_placeholder
    # "all" or anything unrecognized falls back to the original combined check
    return f"({is_null} OR {is_blank} OR {is_placeholder})"


def _extract_check_mode(condition_criteria):
    """Reads an optional {"check": "..."} key out of condition_criteria
    without requiring it -- NOT_NULL/BLANK/NOT_NULL_LENGTH_CHECK all accept
    no criteria at all today, so this must tolerate None/blank/malformed
    input and fall back to "all" rather than erroring."""
    if not condition_criteria:
        return "all"
    try:
        parsed = json.loads(condition_criteria)
        if isinstance(parsed, dict):
            return str(parsed.get("check", "all"))
    except (json.JSONDecodeError, TypeError):
        pass
    return "all"


def construct_not_null_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria=None):
    mode = _extract_check_mode(condition_criteria)
    columns = [col.strip() for col in column_name.split(',')]
    condition = [_null_check_condition(col, mode) for col in columns]
    cond = ' OR '.join(condition)
    return f"SELECT * FROM {qualified(catalog_name, schema_name, table_name)} WHERE {cond}"


def construct_blank_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria=None):
    mode = _extract_check_mode(condition_criteria)
    column = column_name.strip()
    condition = _null_check_condition(column, mode)
    return f"SELECT * FROM {qualified(catalog_name, schema_name, table_name)} WHERE {condition}"


def construct_length_check_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria):
    is_valid, result = validate_json_conditions(spark, condition_criteria, {'value': (int, float)})
    if not is_valid:
        return result

    expected_length = int(result['value'])
    column = column_name.strip()

    is_valid_col, col_validation_msg = validate_multiple_columns_type(
        spark, catalog_name, schema_name, table_name, [column], ['string'])
    if not is_valid_col:
        return col_validation_msg

    null_equivalents = [f"'{item.lower()}'" for item in NULL_EQUIVALENTS if item]
    cleaned_column = f"REGEXP_REPLACE(TRIM({column}), '[^a-zA-Z0-9]', '')"

    # FIX: original mixed OR/AND without parentheses (precedence bug) —
    # NULLs are flagged; placeholder values are ignored; others must match length.
    query = f"""
        SELECT *
        FROM {qualified(catalog_name, schema_name, table_name)}
        WHERE ({column} IS NULL)
           OR (LOWER(TRIM({column})) NOT IN ({', '.join(null_equivalents)})
               AND LENGTH({cleaned_column}) <> {expected_length})
    """
    return query


def construct_not_null_length_check_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria):
    is_valid, result = validate_json_conditions(spark, condition_criteria, {"value": (int, float)})
    if not is_valid:
        return result

    expected_length = int(result['value'])
    column = column_name.strip()

    is_valid_col, col_validation_msg = validate_multiple_columns_type(
        spark, catalog_name, schema_name, table_name, [column], ['string'])
    if not is_valid_col:
        return col_validation_msg

    cleaned_column = f"REGEXP_REPLACE(TRIM({column}), '[^a-zA-Z0-9]', '')"

    # Presence-check portion respects an optional {"check": "..."} mode in
    # this rule's own condition_criteria (see _null_check_condition), same
    # as NOT_NULL/BLANK. Defaults to "all" (original behavior: flags NULL
    # and placeholder values) when not specified, so existing rules are
    # unaffected. The length comparison itself is unconditional either way
    # -- that's this rule type's defining feature, not something a mode
    # should be able to turn off.
    mode = _extract_check_mode(condition_criteria)
    if mode == "all":
        # Preserve the exact original two-clause form (NULL OR placeholder)
        # rather than the parenthesized 3-clause form _null_check_condition
        # would produce, so this rule's SQL is byte-for-byte unchanged for
        # every rule that doesn't opt into a mode.
        null_equivalents = [f"'{item.lower()}'" for item in NULL_EQUIVALENTS if item]
        presence_check = (
            f"{column} IS NULL OR LOWER(TRIM({column})) IN ({', '.join(null_equivalents)})"
        )
    else:
        presence_check = _null_check_condition(column, mode)

    query = f"""
        SELECT *
        FROM {qualified(catalog_name, schema_name, table_name)}
        WHERE {presence_check}
           OR LENGTH({cleaned_column}) <> {expected_length}
    """
    return query


def construct_must_have_value_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria):
    is_valid, result = validate_json_conditions(spark, condition_criteria, {'value': list})
    if not is_valid:
        return result

    values = [str(v).strip() for v in result['value']]
    if not values:
        return "Error: 'value' list cannot be empty."

    column = column_name.strip().strip("'")

    is_valid_col, col_validation_msg = validate_multiple_columns_type(
        spark, catalog_name, schema_name, table_name, [column],
        ['string', 'int', 'bigint', 'smallint', 'tinyint', 'float', 'double', 'decimal'])
    if not is_valid_col:
        return col_validation_msg

    all_numeric = all(v.replace('-', '').replace('.', '', 1).isdigit() for v in values)
    if all_numeric:
        formatted_values = ", ".join(values)
        value_check = f"({column} IS NULL OR {column} NOT IN ({formatted_values}))"
    else:
        formatted_values = ", ".join(f"'{v.lower()}'" for v in values)
        value_check = f"({column} IS NULL OR LOWER(TRIM({column})) NOT IN ({formatted_values}))"

    return f"""
        SELECT *
        FROM {qualified(catalog_name, schema_name, table_name)}
        WHERE {value_check}
    """


def construct_reference_check_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria):
    """REFERENCE_CHECK — like MUST_HAVE_VALUE, but instead of a fixed list of
    allowed values in condition_criteria, the allowed set is the LIVE
    DISTINCT values of a column in a DIFFERENT table (a cross-table lookup /
    referential-integrity check — e.g. "every STATE code here must exist in
    the reference.state_codes.code column").

    condition_criteria:
      {"catalog": "<ref_catalog>", "schema": "<ref_schema>",
       "table_name": "<ref_table>", "targeted_column": "<ref_column>"}

    A row is flagged if its (non-null) value for column_name does NOT appear
    among the reference table's targeted_column distinct values."""
    is_valid, result = validate_json_conditions(
        spark, condition_criteria,
        {'catalog': str, 'schema': str, 'table_name': str, 'targeted_column': str})
    if not is_valid:
        return result

    ref_catalog = result['catalog'].strip()
    ref_schema = result['schema'].strip()
    ref_table = result['table_name'].strip()
    ref_column = unbq(result['targeted_column'].strip())

    if not (ref_catalog and ref_schema and ref_table and ref_column):
        return ("Error: 'catalog', 'schema', 'table_name', and "
                "'targeted_column' must all be non-empty.")

    ref_full_table = qualified(ref_catalog, ref_schema, ref_table)
    try:
        ref_columns = spark.table(ref_full_table).columns
    except Exception as e:
        return f"Error: reference table '{ref_full_table}' could not be read: {e}"
    if ref_column not in ref_columns:
        return (f"Error: Column '{ref_column}' not found in reference "
                f"table '{ref_full_table}'.")

    column = column_name.strip().strip("'")

    # Compare as STRING on both sides. The rule's column and the reference
    # column may be different underlying types (e.g. a code stored as
    # STRING here but SMALLINT in the reference table) — casting avoids the
    # exact IN()-list DATATYPE_MISMATCH class of bug already fixed elsewhere
    # in this framework (see the profile_table true-rate fix).
    return f"""
        SELECT *
        FROM {qualified(catalog_name, schema_name, table_name)}
        WHERE {column} IS NOT NULL
          AND CAST({column} AS STRING) NOT IN (
              SELECT DISTINCT CAST({bq(ref_column)} AS STRING)
              FROM {ref_full_table}
              WHERE {bq(ref_column)} IS NOT NULL
          )
    """


# Transforms supported by REFERENCE_CHECK_CUSTOM — each maps a value
# expression to the SQL expression that extracts the portion to compare.
REFERENCE_CHECK_CUSTOM_TRANSFORMS = (
    "FIRST_N", "LAST_N", "MIDDLE", "AFTER_DELIMITER", "BEFORE_DELIMITER"
)


def _build_substring_transform(value_expr, transform, criteria):
    """Returns (sql_expr, error). sql_expr is a SQL expression string that
    extracts the requested portion of value_expr (which should already be a
    full column/CAST reference, e.g. "CAST(`EMAIL` AS STRING)"). Used by
    REFERENCE_CHECK_CUSTOM to compare only part of a value — a prefix,
    suffix, fixed substring, or text before/after a delimiter — against the
    reference set, instead of the whole value.

    Examples this enables:
      FIRST_N (length=15)               -> first 15 characters of a code
      LAST_N (length=10)                -> last 10 characters of an account #
      MIDDLE (start=5, length=3)        -> a fixed-position substring
      AFTER_DELIMITER (delimiter="@")   -> the domain part of an email
      BEFORE_DELIMITER (delimiter="@")  -> the local part of an email
    """
    transform = (transform or "").strip().upper()

    if transform == "FIRST_N":
        length = criteria.get("length")
        if not isinstance(length, (int, float)) or length <= 0:
            return None, "Error: 'length' must be a positive number for FIRST_N."
        return f"SUBSTRING({value_expr}, 1, {int(length)})", None

    if transform == "LAST_N":
        length = criteria.get("length")
        if not isinstance(length, (int, float)) or length <= 0:
            return None, "Error: 'length' must be a positive number for LAST_N."
        length = int(length)
        # Negative start position in SUBSTRING counts from the end of the
        # string — e.g. SUBSTRING('WORLD', -3, 3) = 'RLD'.
        return f"SUBSTRING({value_expr}, -{length}, {length})", None

    if transform == "MIDDLE":
        start = criteria.get("start")
        length = criteria.get("length")
        if not isinstance(start, (int, float)) or start <= 0:
            return None, "Error: 'start' must be a positive number (1-based) for MIDDLE."
        if not isinstance(length, (int, float)) or length <= 0:
            return None, "Error: 'length' must be a positive number for MIDDLE."
        return f"SUBSTRING({value_expr}, {int(start)}, {int(length)})", None

    if transform in ("AFTER_DELIMITER", "BEFORE_DELIMITER"):
        delimiter = criteria.get("delimiter")
        if not isinstance(delimiter, str) or delimiter == "":
            return None, f"Error: 'delimiter' must be a non-empty string for {transform}."
        delim_escaped = delimiter.replace("'", "''")
        pos_expr = f"INSTR({value_expr}, '{delim_escaped}')"
        if transform == "AFTER_DELIMITER":
            # Falls back to the full value if the delimiter isn't present,
            # rather than erroring — a row simply won't match the reference
            # set's (presumably delimiter-free) values in that case.
            return (f"CASE WHEN {pos_expr} > 0 "
                    f"THEN SUBSTRING({value_expr}, {pos_expr} + {len(delimiter)}) "
                    f"ELSE {value_expr} END"), None
        return (f"CASE WHEN {pos_expr} > 0 "
                f"THEN SUBSTRING({value_expr}, 1, {pos_expr} - 1) "
                f"ELSE {value_expr} END"), None

    return None, (f"Error: Unsupported transform '{transform}'. Must be one of "
                  f"{', '.join(REFERENCE_CHECK_CUSTOM_TRANSFORMS)}.")


def construct_reference_check_custom_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria):
    """REFERENCE_CHECK_CUSTOM — like REFERENCE_CHECK, but compares only a
    TRANSFORMED PORTION of the rule's column value (a prefix, suffix, fixed
    substring, or text before/after a delimiter) against the reference
    table's distinct values, instead of the whole value.

    condition_criteria:
      {"catalog": "<ref_catalog>", "schema": "<ref_schema>",
       "table_name": "<ref_table>", "targeted_column": "<ref_column>",
       "transform": "FIRST_N | LAST_N | MIDDLE | AFTER_DELIMITER | BEFORE_DELIMITER",
       "length": <number>,       # FIRST_N / LAST_N / MIDDLE
       "start": <number>,        # MIDDLE only (1-based)
       "delimiter": "<string>",  # AFTER_DELIMITER / BEFORE_DELIMITER only
       "apply_transform_to_reference": <bool>}  # optional, default False —
           set True if the reference column's values ALSO need the same
           transform applied before comparing (rare; usually the reference
           table already stores just the short/expected form).
    """
    required_keys = {'catalog': str, 'schema': str, 'table_name': str,
                     'targeted_column': str, 'transform': str}
    is_valid, result = validate_json_conditions(spark, condition_criteria, required_keys)
    if not is_valid:
        return result

    ref_catalog = result['catalog'].strip()
    ref_schema = result['schema'].strip()
    ref_table = result['table_name'].strip()
    ref_column = unbq(result['targeted_column'].strip())
    transform = result['transform'].strip().upper()
    apply_to_reference = bool(condition_criteria.get('apply_transform_to_reference', False))

    if not (ref_catalog and ref_schema and ref_table and ref_column):
        return ("Error: 'catalog', 'schema', 'table_name', and "
                "'targeted_column' must all be non-empty.")

    ref_full_table = qualified(ref_catalog, ref_schema, ref_table)
    try:
        ref_columns = spark.table(ref_full_table).columns
    except Exception as e:
        return f"Error: reference table '{ref_full_table}' could not be read: {e}"
    if ref_column not in ref_columns:
        return (f"Error: Column '{ref_column}' not found in reference "
                f"table '{ref_full_table}'.")

    column = column_name.strip().strip("'")

    source_expr, err = _build_substring_transform(
        f"CAST({column} AS STRING)", transform, condition_criteria)
    if err:
        return err

    if apply_to_reference:
        ref_expr, err = _build_substring_transform(
            f"CAST({bq(ref_column)} AS STRING)", transform, condition_criteria)
        if err:
            return err
    else:
        ref_expr = f"CAST({bq(ref_column)} AS STRING)"

    return f"""
        SELECT *
        FROM {qualified(catalog_name, schema_name, table_name)}
        WHERE {column} IS NOT NULL
          AND {source_expr} NOT IN (
              SELECT DISTINCT {ref_expr}
              FROM {ref_full_table}
              WHERE {bq(ref_column)} IS NOT NULL
          )
    """


def construct_regex_match_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria):
    # Accept either {'value': '<regex>'} (repo style) or {'regex_pattern': '<regex>'} (doc style)
    is_valid, result = validate_json_conditions(spark, condition_criteria, {'value': str})
    if not is_valid:
        is_valid, result = validate_json_conditions(spark, condition_criteria, {'regex_pattern': str})
        if not is_valid:
            return result
        regex = result["regex_pattern"]
    else:
        regex = result["value"]

    escaped_regex = regex.replace("\\", "\\\\")

    is_valid_col, col_validation_msg = validate_multiple_columns_type(
        spark, catalog_name, schema_name, table_name, [column_name], ['string'])
    if not is_valid_col:
        return col_validation_msg

    null_values = ", ".join([f"'{v}'" for v in NULL_EQUIVALENTS])
    null_condition = f"LOWER(TRIM({column_name})) IN ({null_values}) OR {column_name} IS NULL"

    return f"""
        SELECT *
        FROM {qualified(catalog_name, schema_name, table_name)}
        WHERE ({null_condition})
           OR TRIM({column_name}) NOT REGEXP '{escaped_regex.replace("'", "''")}'
    """


def construct_unique_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria):
    """Two modes:
      - criteria has 'identifier_column' -> one-to-one mapping check
      - criteria empty                    -> plain uniqueness of the column(s)
    FIX vs repo: returns the raw offending RECORDS (SELECT *) instead of a
    grouped summary, so they can be quarantined and excluded from clean data."""
    full_table = qualified(catalog_name, schema_name, table_name)
    check_column = column_name.strip()

    identifier_column = None
    if condition_criteria and str(condition_criteria).strip().lower() not in ("", "null", "none"):
        is_valid, result = validate_json_conditions(spark, condition_criteria, {'identifier_column': str})
        if is_valid:
            identifier_column = result['identifier_column'].strip()

    if identifier_column:
        is_valid_col, col_validation_msg = validate_multiple_columns_type(
            spark, catalog_name, schema_name, table_name,
            [check_column, identifier_column], ['string', 'int', 'bigint', 'smallint', 'tinyint'])
        if not is_valid_col:
            return col_validation_msg
        return f"""
            SELECT *
            FROM {full_table}
            WHERE {check_column} IN (
                SELECT {check_column}
                FROM {full_table}
                GROUP BY {check_column}
                HAVING COUNT(DISTINCT {identifier_column}) > 1
            )
        """

    # plain uniqueness (single or composite column list)
    columns = [c.strip() for c in check_column.split(",") if c.strip()]
    group_by_expr = ", ".join(columns)
    join_conditions = " AND ".join([f"main.{c} <=> dup.{c}" for c in columns])
    return f"""
        SELECT main.*
        FROM {full_table} main
        INNER JOIN (
            SELECT {group_by_expr}
            FROM {full_table}
            GROUP BY {group_by_expr}
            HAVING COUNT(*) > 1
        ) dup
        ON {join_conditions}
    """


def construct_duplicate_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria):
    full_table = qualified(catalog_name, schema_name, table_name)
    columns = [c.strip() for c in column_name.split(",")]

    subquery_expr = ", ".join([f"TRIM(CAST({col} AS STRING)) AS {col}" for col in columns])
    group_by_expr = ", ".join([f"TRIM(CAST({col} AS STRING))" for col in columns])
    join_conditions = " AND ".join(
        [f"TRIM(CAST(main.{col} AS STRING)) <=> dup.{col}" for col in columns])

    subquery = f"""
        SELECT {subquery_expr}
        FROM {full_table}
        GROUP BY {group_by_expr}
        HAVING COUNT(*) > 1
    """
    # FIX vs repo: SELECT main.* (full duplicated records) instead of
    # DISTINCT key columns only.
    return f"""
        SELECT main.*
        FROM {full_table} main
        INNER JOIN ({subquery}) dup
        ON {join_conditions}
    """


def construct_range_check_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria):
    required_keys = {"min_value": (int, float), "max_value": (int, float)}
    is_valid, result = validate_json_conditions(spark, condition_criteria, required_keys)
    if not is_valid:
        return result

    min_value = result["min_value"]
    max_value = result["max_value"]
    column = column_name.strip()

    is_valid_col, col_validation_msg = validate_multiple_columns_type(
        spark, catalog_name, schema_name, table_name, [column],
        ['int', 'bigint', 'smallint', 'tinyint', 'float', 'double', 'decimal'])
    if not is_valid_col:
        return col_validation_msg

    return f"""
    SELECT *
    FROM {qualified(catalog_name, schema_name, table_name)}
    WHERE
        {column} IS NULL OR
        TRY_CAST({column} AS DOUBLE) IS NULL OR
        TRY_CAST({column} AS DOUBLE) < {min_value} OR
        TRY_CAST({column} AS DOUBLE) > {max_value}
    """


def construct_format_check_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria):
    is_valid, result = validate_json_conditions(spark, condition_criteria, {'regex_pattern': str})
    if not is_valid:
        return result

    regex_pattern = result['regex_pattern']
    col = column_name.strip()

    is_valid_type, col_type_result = validate_column_type(
        spark, catalog_name, schema_name, table_name, col,
        ['string', 'date', 'timestamp'])
    if not is_valid_type:
        return col_type_result

    col_expr = f'TRIM(CAST({col} AS STRING))'
    null_equivalents = [f"'{item.lower()}'" for item in NULL_EQUIVALENTS if item]
    escaped_regex = regex_pattern.replace("\\", "\\\\")

    # FIX: original had "(col IS NULL AND LOWER(col_expr) NOT IN nulls)" which
    # can never be true (a NULL col has NULL col_expr). Correct: flag NULLs,
    # placeholders, and non-matching values.
    return f"""
    SELECT *
    FROM {qualified(catalog_name, schema_name, table_name)}
    WHERE
        {col} IS NULL
        OR LOWER({col_expr}) IN ({', '.join(null_equivalents)})
        OR NOT ({col_expr} RLIKE "{escaped_regex}")
    """


def construct_value_threshold_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria):
    allowed_operators = ['>', '>=', '<', '<=', '=', '!=']

    # Accept 'threshold' (repo style) or 'value_threshold' (doc style)
    is_valid, result = validate_json_conditions(
        spark, condition_criteria, {'operator': str, 'threshold': (int, float)})
    if not is_valid:
        is_valid, result = validate_json_conditions(
            spark, condition_criteria, {'operator': str, 'value_threshold': (int, float)})
        if not is_valid:
            return result
        threshold = result.get('value_threshold')
    else:
        threshold = result.get('threshold')

    operator = result.get('operator')
    column = column_name.strip()

    if operator not in allowed_operators:
        return f"Unsupported operator: {operator}"

    is_valid_col, col_validation_msg = validate_column_type(
        spark, catalog_name, schema_name, table_name, column,
        ['int', 'bigint', 'smallint', 'tinyint', 'float', 'double', 'decimal'])
    if not is_valid_col:
        return col_validation_msg

    # The operator/threshold define the PASSING condition (per design doc);
    # violations are records that do NOT satisfy it (or are NULL).
    return f"""
    SELECT *
    FROM {qualified(catalog_name, schema_name, table_name)}
    WHERE {column} IS NULL
       OR NOT (TRY_CAST({column} AS DOUBLE) {operator} {threshold})
    """


def construct_time_stamp_check_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria):
    required_keys = {"condition": str}
    is_valid, result = validate_json_conditions(spark, condition_criteria, required_keys)
    if not is_valid:
        return result

    condition_str = result["condition"].strip()
    if not condition_str:
        return "Error: 'condition' must not be empty."
    if not re.match(r"^[a-zA-Z0-9_ <>=!()'\"\.:-]+$", condition_str):
        return "Error: 'condition' contains unsupported characters."

    columns = [c.strip() for c in column_name.split(",") if c.strip()]
    if not columns:
        return "Error: No valid column names provided."

    is_valid_columns, col_validation_msg = validate_multiple_columns_type(
        spark, catalog_name, schema_name, table_name, columns, ['timestamp', 'date'])
    if not is_valid_columns:
        return col_validation_msg

    null_equivalents = [f"'{item.lower()}'" for item in NULL_EQUIVALENTS if item]
    null_conditions = " OR ".join(
        [f"{col} IS NULL OR LOWER(TRIM(CAST({col} AS STRING))) IN ({', '.join(null_equivalents)})"
         for col in columns])

    return f"""
    SELECT *
    FROM {qualified(catalog_name, schema_name, table_name)}
    WHERE NOT ({condition_str})
       OR ({null_conditions})
    """


def construct_outlier_detection_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria):
    is_valid, result = validate_json_conditions(spark, condition_criteria, {'value': (int, float)})
    if not is_valid:
        return result

    k = result.get('value')

    is_valid, column_type = validate_column_type(
        spark, catalog_name, schema_name, table_name, column_name,
        ['int', 'bigint', 'smallint', 'tinyint', 'double', 'float', 'decimal'])
    if not is_valid:
        return column_type

    full_table = qualified(catalog_name, schema_name, table_name)
    # FIX vs repo: exclude stats columns from output (SELECT t.* not *) so
    # bad_record_data matches the source schema exactly.
    return f"""
    WITH stats AS (
        SELECT
            AVG({column_name}) AS mean,
            STDDEV({column_name}) AS stddev
        FROM {full_table}
    )
    SELECT t.*
    FROM {full_table} t CROSS JOIN stats
    WHERE stats.stddev IS NOT NULL AND stats.stddev <> 0
      AND ({column_name} > (stats.mean + {k} * stats.stddev)
        OR {column_name} < (stats.mean - {k} * stats.stddev))
    """


def construct_date_range_check_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria):
    is_valid, result = validate_json_conditions(
        spark, condition_criteria, {'start_date': str, 'end_date': str})
    if not is_valid:
        return result

    start_date = result['start_date']
    end_date = result['end_date']
    col = column_name.strip()

    is_valid_type, type_result = validate_column_type(
        spark, catalog_name, schema_name, table_name, col, ['date', 'timestamp'])
    if not is_valid_type:
        return type_result

    return f"""
    SELECT *
    FROM {qualified(catalog_name, schema_name, table_name)}
    WHERE
        {col} IS NULL OR
        {col} < CAST('{start_date}' AS DATE) OR
        {col} > CAST('{end_date} 23:59:59' AS TIMESTAMP)
    """


def construct_mapping_check_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria):
    """Column value must resolve (via constants.alias_map) to one of the
    canonical values in criteria['value']."""
    is_valid, result = validate_json_conditions(spark, condition_criteria, {'value': list})
    if not is_valid:
        return result

    allowed_values = [str(v).lower() for v in result['value']]
    col = column_name.strip()

    is_valid_type, type_result = validate_column_type(
        spark, catalog_name, schema_name, table_name, col, ['string'])
    if not is_valid_type:
        return type_result

    case_expr = "CASE"
    for canonical, aliases in alias_map.items():
        alias_list = ", ".join(f"'{alias.lower()}'" for alias in aliases)
        case_expr += f"\n        WHEN LOWER(TRIM({col})) IN ({alias_list}) THEN '{canonical}'"
    case_expr += f"\n        ELSE LOWER(TRIM({col}))\n    END"

    formatted_values = ", ".join(f"'{val}'" for val in allowed_values)
    return f"""
    SELECT *
    FROM {qualified(catalog_name, schema_name, table_name)}
    WHERE {col} IS NULL
       OR {case_expr} NOT IN ({formatted_values})
    """


def construct_case_standardization_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria):
    is_valid, result = validate_json_conditions(spark, condition_criteria, {'case': str})
    if not is_valid:
        return result

    case_value = result['case'].strip().upper()
    if case_value not in ['UPPER', 'LOWER']:
        return "Error: 'case' must be either 'UPPER' or 'LOWER'."
    case_func = 'UPPER' if case_value == 'UPPER' else 'LOWER'

    col = column_name.strip()
    is_valid_type, type_result = validate_column_type(
        spark, catalog_name, schema_name, table_name, col, ['string'])
    if not is_valid_type:
        return type_result

    return f"""
    SELECT *
    FROM {qualified(catalog_name, schema_name, table_name)}
    WHERE {col} IS NOT NULL
      AND {col} <> {case_func}({col})
    """


def construct_row_count_trend_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria):
    """Table-level: compares current row count vs mean ± 3σ of the counts
    recorded in dq_logs for this rule type over the lookback interval.
    Returns 1 anomaly row when out of range, 0 rows otherwise.
    NOTE: needs result-schema context, so it is executed directly in
    dq_executor rather than through this builder."""
    return None


def construct_kpi_aggregation_query(spark, catalog_name, schema_name, table_name, column_name, condition_criteria,
                                    result_catalog=None, result_schema=None):
    """FIX vs repo: signature now matches the dispatcher (spark first) and the
    metrics/bad-records lookups point at the RESULT schema instead of the
    source schema."""
    # FIX: condition_criteria being None raises TypeError, not
    # json.JSONDecodeError -- previously unhandled here, surfacing as "the
    # JSON object must be str, bytes or bytearray, not NoneType" instead of
    # a clean error.
    try:
        condition_dict = json.loads(condition_criteria or "{}")
    except (json.JSONDecodeError, TypeError):
        return "Error: Invalid JSON format in condition_criteria."
    agg_type = condition_dict.get("agg_type")
    agg_column = condition_dict.get("agg_column")
    group_by_columns = condition_dict.get("group_by_columns")
    join_tables = condition_dict.get("join_tables")
    join_conditions = condition_dict.get("join_conditions") or []

    if agg_type not in ["avg", "sum", "count", "max", "min"]:
        return f"Error: Unsupported aggregation type '{agg_type}'."
    if not group_by_columns:
        return "Error: 'group_by_columns' must be a non-empty list."

    base_table = qualified(catalog_name, schema_name, table_name)
    result_catalog = result_catalog or catalog_name
    metrics_table = f"{result_catalog}.{result_schema}.dq_table_metrics"
    bad_records_table = f"{result_catalog}.{result_schema}.dq_bad_records"

    join_clauses = []
    if join_tables:
        join_conditions += [None] * (len(join_tables) - len(join_conditions))
        for jt, jc in zip(join_tables, join_conditions):
            if jc:
                join_clauses.append(f"JOIN {qualified(catalog_name, schema_name, jt)} ON {jc}")
            else:
                return f"Error: Missing join condition for table '{jt}'."
    joins_sql = "\n".join(join_clauses)
    group_by_clause = ", ".join(group_by_columns)

    return f"""
    WITH latest_metrics AS (
        SELECT
            {group_by_columns[0]} AS region_name,
            {agg_type.upper()}({agg_column}) AS region_metric
        FROM {base_table}
        {joins_sql}
        GROUP BY {group_by_clause}
    ),
    bad_kpi_records AS (
        SELECT
            get_json_object(get_json_object(bad_record_data, '$.kpi_metric_value_json'), '$.region_name') AS bad_region,
            CAST(get_json_object(get_json_object(bad_record_data, '$.kpi_metric_value_json'), '$.metric_value') AS DOUBLE) AS bad_value
        FROM {bad_records_table}
        WHERE table_name = '{table_name}'
    ),
    valid_metrics AS (
        SELECT
            explode(from_json(kpi_metric_value, 'map<string,double>')) AS (region_name, region_metric)
        FROM {metrics_table}
        WHERE metric_level = 'KPI'
          AND table_name = '{table_name}'
          AND catalog = '{catalog_name}' AND schema = '{schema_name}'
          AND kpi_metric_value IS NOT NULL
    ),
    filtered_metrics AS (
        SELECT v.*
        FROM valid_metrics v
        LEFT ANTI JOIN bad_kpi_records b
        ON v.region_name = b.bad_region AND v.region_metric = b.bad_value
    ),
    threshold_stats AS (
        SELECT
            region_name,
            AVG(region_metric) AS mean_metric,
            STDDEV(region_metric) AS stddev_metric
        FROM filtered_metrics
        GROUP BY region_name
    ),
    eval AS (
        SELECT
            l.region_name,
            l.region_metric,
            t.mean_metric,
            t.stddev_metric,
            (t.mean_metric + 3 * t.stddev_metric) AS upper_threshold,
            (t.mean_metric - 3 * t.stddev_metric) AS lower_threshold
        FROM latest_metrics l
        LEFT JOIN threshold_stats t ON l.region_name = t.region_name
    ),
    labeled_eval AS (
        SELECT *,
            CASE
                WHEN region_metric > upper_threshold THEN 'Threshold exceed'
                WHEN region_metric < lower_threshold THEN 'Below threshold'
                ELSE 'within_range'
            END AS kpi_metric_reason
        FROM eval
    )
    SELECT
        to_json(named_struct(
            'region_name', region_name,
            'metric_value', region_metric,
            'expected_mean', mean_metric,
            'stddev_metric', stddev_metric,
            'threshold_upper', upper_threshold,
            'threshold_lower', lower_threshold,
            'kpi_reason', kpi_metric_reason
        )) AS kpi_metric_value_json
    FROM labeled_eval
    WHERE kpi_metric_reason != 'within_range'
    """.strip()

import re
from datetime import datetime


def fix_iso_timestamp(timestamp: str) -> str:
    try:
        if "." in timestamp:
            date_part, ms_part = timestamp.split(".")
            if len(ms_part) == 2:  # two-digit milliseconds -> pad
                timestamp = f"{date_part}.{ms_part}0"
        dt = datetime.fromisoformat(timestamp)
        return dt.isoformat(timespec="milliseconds")
    except ValueError as e:
        raise ValueError(f"Invalid timestamp format: {timestamp}") from e


def qualified(catalog_name, schema_name, table_name):
    """Build a fully qualified table reference.
    When catalog/schema are empty the table_name is used as-is —
    this lets the same query builders run against a batch TEMP VIEW
    (incremental mode) or the real 3-part table (full mode)."""
    if catalog_name and schema_name:
        return f"{catalog_name}.{schema_name}.{table_name}"
    return table_name


def bq(col):
    """Backtick-quote a column name so SAP-style names like `2023_|_10` or
    `Bill-To_Cust` work in generated SQL. Idempotent."""
    col = col.strip()
    if col.startswith("`") and col.endswith("`"):
        return col
    return f"`{col}`"


def unbq(col):
    """Strip backticks for schema-name comparisons."""
    return col.strip().strip("`")


def fill_placeholders(query, catalog_name, schema_name, table_name):
    """Replace {catalog_name}/{schema_name}/{table_name} in custom SQL.
    Uses plain .replace() instead of str.format(), so any OTHER braces in the
    SQL (JSON paths, map literals, named_struct, ...) no longer raise
    KeyError and break the rule."""
    return (str(query)
            .replace("{catalog_name}", catalog_name or "")
            .replace("{schema_name}", schema_name or "")
            .replace("{table_name}", table_name or ""))


def sanitize_name(col_name):
    """'VIN (1-10)' -> 'VIN_1-10', 'Postal Code' -> 'Postal_Code'.
    Delta forbids these characters in column names
    (DELTA_INVALID_CHARACTERS_IN_COLUMN_NAMES): space , ; { } ( ) \n \t =
    Self-contained on purpose — no module-level constants — so partial
    copies of this file cannot break it with a NameError."""
    import re as _re
    s = _re.sub(r"[ ,;{}()\n\t=]+", "_", str(col_name).strip())
    s = _re.sub(r"_+", "_", s).strip("_")
    return s or "col"


def sanitize_columns(df):
    """Rename columns so the DataFrame can be written to Delta.
    Returns (df, rename_map) where rename_map is {original: sanitized} for
    the columns that actually changed. Collisions get _2, _3 suffixes."""
    seen, new_names, rename_map = {}, [], {}
    for c in df.columns:
        s = sanitize_name(c)
        if s in seen:
            seen[s] += 1
            s = f"{s}_{seen[s]}"
        else:
            seen[s] = 1
        new_names.append(s)
        if s != c:
            rename_map[c] = s
    if rename_map:
        df = df.toDF(*new_names)
    return df, rename_map

# # # from pyspark.sql import Row
# # # from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType
# # # from datetime import datetime, timezone
# # # import uuid

# # # from move_bad_records import move_bad_records_to_table
# # # from dq_error_logger import dq_error_logs

# # # dq_log_schema = StructType([
# # #     StructField("log_id", StringType(), True),
# # #     StructField("rule_id", StringType(), True),
# # #     StructField("pipeline_key", StringType(), True),
# # #     StructField("catalog_name", StringType(), False),
# # #     StructField("schema_name", StringType(), False),
# # #     StructField("table_name", StringType(), False),
# # #     StructField("column_name", StringType(), True),
# # #     StructField("condition_category", StringType(), True),
# # #     StructField("condition_type", StringType(), True),
# # #     StructField("status", StringType(), True),
# # #     StructField("violation_count", IntegerType(), True),
# # #     StructField("violation_id", StringType(), True),
# # #     StructField("severity", StringType(), True),
# # #     StructField("batch_timestamp", TimestampType(), True)
# # # ])


# # # def dq_logs(spark, result_catalog, result_schema, rule_id, query, pipeline_key,
# # #             catalog_name, schema_name, table_name, column_name,
# # #             condition_category, condition_type, severity, batch_timestamp,
# # #             violation_threshold=0):
# # #     """Executes one rule's violation query and writes the audit trail.

# # #     Changes vs original:
# # #       - NO pipeline_metadata / table_id lookup (removed entirely)
# # #       - result tables addressed as {result_catalog}.{result_schema}.*
# # #       - honors violation_threshold from dq_rules for Pass/Fail status
# # #       - returns (success_count, failure_count, severity, violation_id,
# # #         fail_keys_df, fail_key_col): the DISTINCT failing keys captured
# # #         IN-SESSION from the violation DataFrame (_dq_row_id preferred,
# # #         cdw_hash_key fallback) so the executor can exclude failing records
# # #         from the cleaned dataset without any JSON round trip
# # #       - the query builder may return an error STRING instead of SQL
# # #         (original repo convention) — that is logged to dq_error_logs and
# # #         counted as an execution failure."""
# # #     success_count = 0
# # #     failure_count = 0
# # #     violation_count = 0
# # #     violation_id = None
# # #     original_severity = severity

# # #     try:
# # #         if isinstance(batch_timestamp, str):
# # #             try:
# # #                 batch_timestamp = datetime.fromisoformat(batch_timestamp)
# # #             except Exception as e:
# # #                 print(f"❌ Invalid batch_timestamp: {str(e)}")
# # #                 return success_count, 1, severity, None, None, None

# # #         if not isinstance(batch_timestamp, datetime):
# # #             print("❌ batch_timestamp must be a datetime object.")
# # #             return success_count, 1, severity, None, None, None

# # #         # Builders return an "Error: ..." string when validation fails
# # #         if not isinstance(query, str) or not query.strip().upper().startswith(("SELECT", "WITH")):
# # #             error_message = f"Rule construction failed: {query}"
# # #             print(f"❌ {error_message}")
# # #             dq_error_logs(spark, result_catalog, result_schema, rule_id, pipeline_key,
# # #                           None, catalog_name, schema_name, table_name,
# # #                           error_message, batch_timestamp)
# # #             _write_log(spark, result_catalog, result_schema, rule_id, pipeline_key,
# # #                        catalog_name, schema_name, table_name, column_name,
# # #                        condition_category, condition_type, "Error", 0, None,
# # #                        severity, batch_timestamp)
# # #             return success_count, 1, severity, None, None, None

# # #         try:
# # #             violation_df = spark.sql(query)
# # #             violation_count = violation_df.count()
# # #         except Exception as e:
# # #             print(f"❌ Error executing query: {str(e)}")
# # #             dq_error_logs(spark, result_catalog, result_schema, rule_id, pipeline_key,
# # #                           None, catalog_name, schema_name, table_name,
# # #                           f"Query Execution Error: {str(e)}", batch_timestamp)
# # #             _write_log(spark, result_catalog, result_schema, rule_id, pipeline_key,
# # #                        catalog_name, schema_name, table_name, column_name,
# # #                        condition_category, condition_type, "Error", 0, None,
# # #                        severity, batch_timestamp)
# # #             return success_count, 1, severity, None, None, None

# # #         # Capture failing keys in-session (exact, no JSON round trip)
# # #         fail_keys_df, fail_key_col = None, None
# # #         if violation_count > 0:
# # #             for cand in ("_dq_row_id", "cdw_hash_key"):
# # #                 if cand in violation_df.columns:
# # #                     fail_keys_df = violation_df.select(cand).distinct()
# # #                     fail_key_col = cand
# # #                     break

# # #         # Severity escalation vs historical average (same thresholds as original)
# # #         try:
# # #             past_logs_df = spark.sql(f"""
# # #                 SELECT AVG(violation_count) AS avg_violations
# # #                 FROM {result_catalog}.{result_schema}.dq_logs
# # #                 WHERE rule_id = '{rule_id}' AND table_name = '{table_name}'
# # #                   AND violation_count IS NOT NULL
# # #             """)
# # #             avg_violations = past_logs_df.collect()[0]['avg_violations']
# # #             if avg_violations:
# # #                 increase_ratio = violation_count / avg_violations
# # #                 if increase_ratio > 1.10:
# # #                     severity = "Critical"
# # #                     print(f"🚨 Violations {violation_count} >10% over average "
# # #                           f"({avg_violations:.2f}). Severity escalated to CRITICAL.")
# # #                 elif increase_ratio > 1.07:
# # #                     severity = "Alert"
# # #                     print(f"⚠️ Violations {violation_count} >7% over average "
# # #                           f"({avg_violations:.2f}). Severity set to ALERT.")
# # #         except Exception as e:
# # #             print(f"⚠️ Could not compute past average violations: {str(e)}")

# # #         if violation_count > 0:
# # #             violation_id = f"dqv_{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4()}"
# # #             try:
# # #                 move_bad_records_to_table(spark, result_catalog, result_schema,
# # #                                           rule_id, pipeline_key, catalog_name,
# # #                                           schema_name, table_name, violation_df,
# # #                                           violation_id, batch_timestamp)
# # #             except Exception as e:
# # #                 print(f"❌ Error moving bad records: {str(e)}")
# # #                 return success_count, 1, severity, violation_id, fail_keys_df, fail_key_col, None, None
# # #             failure_count += 1
# # #         else:
# # #             success_count += 1

# # #         threshold = int(violation_threshold or 0)
# # #         status = "Fail" if violation_count > threshold else "Pass"

# # #         _write_log(spark, result_catalog, result_schema, rule_id, pipeline_key,
# # #                    catalog_name, schema_name, table_name, column_name,
# # #                    condition_category, condition_type, status, violation_count,
# # #                    violation_id, severity, batch_timestamp)

# # #         if original_severity != "Critical" and severity == "Critical":
# # #             print(f"🚨 Severity escalated to CRITICAL due to abnormal "
# # #                   f"violation count: {violation_count}")

# # #     except Exception as e:
# # #         print(f"❌ Error in dq_logs: {str(e)}")
# # #         dq_error_logs(spark, result_catalog, result_schema, rule_id, pipeline_key,
# # #                       violation_id, catalog_name, schema_name, table_name,
# # #                       f"DQ Logs Error: {str(e)}", batch_timestamp)
# # #         failure_count += 1

# # #     return (success_count, failure_count, severity, violation_id,
# # #             fail_keys_df, fail_key_col)


# # # def _write_log(spark, result_catalog, result_schema, rule_id, pipeline_key,
# # #                catalog_name, schema_name, table_name, column_name,
# # #                condition_category, condition_type, status, violation_count,
# # #                violation_id, severity, batch_timestamp):
# # #     log_id = f"dql_{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4()}"
# # #     log_row = Row(
# # #         log_id=log_id,
# # #         rule_id=rule_id,
# # #         pipeline_key=str(pipeline_key) if pipeline_key is not None else None,
# # #         catalog_name=catalog_name,
# # #         schema_name=schema_name,
# # #         table_name=table_name,
# # #         column_name=column_name,
# # #         condition_category=condition_category,
# # #         condition_type=condition_type,
# # #         status=status,
# # #         violation_count=int(violation_count),
# # #         violation_id=violation_id,
# # #         severity=severity,
# # #         batch_timestamp=batch_timestamp
# # #     )
# # #     spark.createDataFrame([log_row], schema=dq_log_schema) \
# # #          .write.format("delta").mode("append") \
# # #          .saveAsTable(f"{result_catalog}.{result_schema}.dq_logs")




# # from pyspark.sql import Row
# # from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType
# # from datetime import datetime, timezone
# # import uuid

# # from move_bad_records import move_bad_records_to_table
# # from dq_error_logger import dq_error_logs

# # dq_log_schema = StructType([
# #     StructField("log_id", StringType(), True),
# #     StructField("rule_id", StringType(), True),
# #     StructField("pipeline_key", StringType(), True),
# #     StructField("catalog_name", StringType(), False),
# #     StructField("schema_name", StringType(), False),
# #     StructField("table_name", StringType(), False),
# #     StructField("column_name", StringType(), True),
# #     StructField("condition_category", StringType(), True),
# #     StructField("condition_type", StringType(), True),
# #     StructField("status", StringType(), True),
# #     StructField("violation_count", IntegerType(), True),
# #     StructField("violation_id", StringType(), True),
# #     StructField("severity", StringType(), True),
# #     StructField("batch_timestamp", TimestampType(), True)
# # ])


# # def dq_logs(spark, result_catalog, result_schema, rule_id, query, pipeline_key,
# #             catalog_name, schema_name, table_name, column_name,
# #             condition_category, condition_type, severity, batch_timestamp,
# #             violation_threshold=0):
# #     """Executes one rule's violation query and writes the audit trail.

# #     Changes vs original:
# #       - NO pipeline_metadata / table_id lookup (removed entirely)
# #       - result tables addressed as {result_catalog}.{result_schema}.*
# #       - honors violation_threshold from dq_rules for Pass/Fail status
# #       - returns (success_count, failure_count, severity, violation_id,
# #         fail_keys_df, fail_key_col): the DISTINCT failing keys captured
# #         IN-SESSION from the violation DataFrame (_dq_row_id preferred,
# #         cdw_hash_key fallback) so the executor can exclude failing records
# #         from the cleaned dataset without any JSON round trip
# #       - the query builder may return an error STRING instead of SQL
# #         (original repo convention) — that is logged to dq_error_logs and
# #         counted as an execution failure."""
# #     success_count = 0
# #     failure_count = 0
# #     violation_count = 0
# #     violation_id = None
# #     original_severity = severity

# #     try:
# #         if isinstance(batch_timestamp, str):
# #             try:
# #                 batch_timestamp = datetime.fromisoformat(batch_timestamp)
# #             except Exception as e:
# #                 print(f"❌ Invalid batch_timestamp: {str(e)}")
# #                 return success_count, 1, severity, None, None, None

# #         if not isinstance(batch_timestamp, datetime):
# #             print("❌ batch_timestamp must be a datetime object.")
# #             return success_count, 1, severity, None, None, None

# #         # Builders return an "Error: ..." string when validation fails
# #         if not isinstance(query, str) or not query.strip().upper().startswith(("SELECT", "WITH")):
# #             error_message = f"Rule construction failed: {query}"
# #             print(f"❌ {error_message}")
# #             dq_error_logs(spark, result_catalog, result_schema, rule_id, pipeline_key,
# #                           None, catalog_name, schema_name, table_name,
# #                           error_message, batch_timestamp)
# #             _write_log(spark, result_catalog, result_schema, rule_id, pipeline_key,
# #                        catalog_name, schema_name, table_name, column_name,
# #                        condition_category, condition_type, "Error", 0, None,
# #                        severity, batch_timestamp)
# #             return success_count, 1, severity, None, None, None

# #         try:
# #             violation_df = spark.sql(query)
# #             violation_count = violation_df.count()
# #         except Exception as e:
# #             print(f"❌ Error executing query: {str(e)}")
# #             dq_error_logs(spark, result_catalog, result_schema, rule_id, pipeline_key,
# #                           None, catalog_name, schema_name, table_name,
# #                           f"Query Execution Error: {str(e)}", batch_timestamp)
# #             _write_log(spark, result_catalog, result_schema, rule_id, pipeline_key,
# #                        catalog_name, schema_name, table_name, column_name,
# #                        condition_category, condition_type, "Error", 0, None,
# #                        severity, batch_timestamp)
# #             return success_count, 1, severity, None, None, None

# #         # Capture failing keys in-session (exact, no JSON round trip)
# #         fail_keys_df, fail_key_col = None, None
# #         if violation_count > 0:
# #             for cand in ("_dq_row_id", "cdw_hash_key"):
# #                 if cand in violation_df.columns:
# #                     fail_keys_df = violation_df.select(cand).distinct()
# #                     fail_key_col = cand
# #                     break

# #         # Severity escalation vs historical average (same thresholds as original)
# #         try:
# #             past_logs_df = spark.sql(f"""
# #                 SELECT AVG(violation_count) AS avg_violations
# #                 FROM {result_catalog}.{result_schema}.dq_logs
# #                 WHERE rule_id = '{rule_id}' AND table_name = '{table_name}'
# #                   AND violation_count IS NOT NULL
# #             """)
# #             avg_violations = past_logs_df.collect()[0]['avg_violations']
# #             if avg_violations:
# #                 increase_ratio = violation_count / avg_violations
# #                 if increase_ratio > 1.10:
# #                     severity = "Critical"
# #                     print(f"🚨 Violations {violation_count} >10% over average "
# #                           f"({avg_violations:.2f}). Severity escalated to CRITICAL.")
# #                 elif increase_ratio > 1.07:
# #                     severity = "Alert"
# #                     print(f"⚠️ Violations {violation_count} >7% over average "
# #                           f"({avg_violations:.2f}). Severity set to ALERT.")
# #         except Exception as e:
# #             print(f"⚠️ Could not compute past average violations: {str(e)}")

# #         if violation_count > 0:
# #             violation_id = f"dqv_{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4()}"
# #             try:
# #                 move_bad_records_to_table(spark, result_catalog, result_schema,
# #                                           rule_id, pipeline_key, catalog_name,
# #                                           schema_name, table_name, violation_df,
# #                                           violation_id, batch_timestamp)
# #             except Exception as e:
# #                 print(f"❌ Error moving bad records: {str(e)}")
# #                 return success_count, 1, severity, violation_id, fail_keys_df, fail_key_col
# #             failure_count += 1
# #         else:
# #             success_count += 1

# #         threshold = int(violation_threshold or 0)
# #         status = "Fail" if violation_count > threshold else "Pass"

# #         _write_log(spark, result_catalog, result_schema, rule_id, pipeline_key,
# #                    catalog_name, schema_name, table_name, column_name,
# #                    condition_category, condition_type, status, violation_count,
# #                    violation_id, severity, batch_timestamp)

# #         if original_severity != "Critical" and severity == "Critical":
# #             print(f"🚨 Severity escalated to CRITICAL due to abnormal "
# #                   f"violation count: {violation_count}")

# #     except Exception as e:
# #         print(f"❌ Error in dq_logs: {str(e)}")
# #         dq_error_logs(spark, result_catalog, result_schema, rule_id, pipeline_key,
# #                       violation_id, catalog_name, schema_name, table_name,
# #                       f"DQ Logs Error: {str(e)}", batch_timestamp)
# #         failure_count += 1

# #     return (success_count, failure_count, severity, violation_id,
# #             fail_keys_df, fail_key_col)


# # def _write_log(spark, result_catalog, result_schema, rule_id, pipeline_key,
# #                catalog_name, schema_name, table_name, column_name,
# #                condition_category, condition_type, status, violation_count,
# #                violation_id, severity, batch_timestamp):
# #     log_id = f"dql_{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4()}"
# #     log_row = Row(
# #         log_id=log_id,
# #         rule_id=rule_id,
# #         pipeline_key=str(pipeline_key) if pipeline_key is not None else None,
# #         catalog_name=catalog_name,
# #         schema_name=schema_name,
# #         table_name=table_name,
# #         column_name=column_name,
# #         condition_category=condition_category,
# #         condition_type=condition_type,
# #         status=status,
# #         violation_count=int(violation_count),
# #         violation_id=violation_id,
# #         severity=severity,
# #         batch_timestamp=batch_timestamp
# #     )
# #     spark.createDataFrame([log_row], schema=dq_log_schema) \
# #          .write.format("delta").mode("append") \
# #          .saveAsTable(f"{result_catalog}.{result_schema}.dq_logs")


# from pyspark.sql import Row
# from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType
# from datetime import datetime, timezone
# import uuid

# from move_bad_records import move_bad_records_to_table
# from dq_error_logger import dq_error_logs

# dq_log_schema = StructType([
#     StructField("log_id", StringType(), True),
#     StructField("rule_id", StringType(), True),
#     StructField("pipeline_key", StringType(), True),
#     StructField("catalog_name", StringType(), False),
#     StructField("schema_name", StringType(), False),
#     StructField("table_name", StringType(), False),
#     StructField("column_name", StringType(), True),
#     StructField("condition_category", StringType(), True),
#     StructField("condition_type", StringType(), True),
#     StructField("status", StringType(), True),
#     StructField("violation_count", IntegerType(), True),
#     StructField("violation_id", StringType(), True),
#     StructField("severity", StringType(), True),
#     StructField("batch_timestamp", TimestampType(), True)
# ])


# def dq_logs(spark, result_catalog, result_schema, rule_id, query, pipeline_key,
#             catalog_name, schema_name, table_name, column_name,
#             condition_category, condition_type, severity, batch_timestamp,
#             violation_threshold=0):
#     """Executes one rule's violation query and writes the audit trail.

#     Changes vs original:
#       - NO pipeline_metadata / table_id lookup (removed entirely)
#       - result tables addressed as {result_catalog}.{result_schema}.*
#       - honors violation_threshold from dq_rules for Pass/Fail status
#       - returns (success_count, failure_count, severity, violation_id,
#         fail_keys_df, fail_key_col): the DISTINCT failing keys captured
#         IN-SESSION from the violation DataFrame (_dq_row_id preferred,
#         cdw_hash_key fallback) so the executor can exclude failing records
#         from the cleaned dataset without any JSON round trip
#       - the query builder may return an error STRING instead of SQL
#         (original repo convention) — that is logged to dq_error_logs and
#         counted as an execution failure."""
#     success_count = 0
#     failure_count = 0
#     violation_count = 0
#     violation_id = None
#     original_severity = severity

#     try:
#         if isinstance(batch_timestamp, str):
#             try:
#                 batch_timestamp = datetime.fromisoformat(batch_timestamp)
#             except Exception as e:
#                 print(f"❌ Invalid batch_timestamp: {str(e)}")
#                 return success_count, 1, severity, None, None, None

#         if not isinstance(batch_timestamp, datetime):
#             print("❌ batch_timestamp must be a datetime object.")
#             return success_count, 1, severity, None, None, None

#         # Builders return an "Error: ..." string when validation fails
#         if not isinstance(query, str) or not query.strip().upper().startswith(("SELECT", "WITH")):
#             error_message = f"Rule construction failed: {query}"
#             print(f"❌ {error_message}")
#             dq_error_logs(spark, result_catalog, result_schema, rule_id, pipeline_key,
#                           None, catalog_name, schema_name, table_name,
#                           error_message, batch_timestamp)
#             _write_log(spark, result_catalog, result_schema, rule_id, pipeline_key,
#                        catalog_name, schema_name, table_name, column_name,
#                        condition_category, condition_type, "Error", 0, None,
#                        severity, batch_timestamp)
#             return success_count, 1, severity, None, None, None

#         try:
#             violation_df = spark.sql(query)
#             violation_count = violation_df.count()
#         except Exception as e:
#             print(f"❌ Error executing query: {str(e)}")
#             dq_error_logs(spark, result_catalog, result_schema, rule_id, pipeline_key,
#                           None, catalog_name, schema_name, table_name,
#                           f"Query Execution Error: {str(e)}", batch_timestamp)
#             _write_log(spark, result_catalog, result_schema, rule_id, pipeline_key,
#                        catalog_name, schema_name, table_name, column_name,
#                        condition_category, condition_type, "Error", 0, None,
#                        severity, batch_timestamp)
#             return success_count, 1, severity, None, None, None

#         # Capture failing keys in-session (exact, no JSON round trip)
#         fail_keys_df, fail_key_col = None, None
#         if violation_count > 0:
#             for cand in ("_dq_row_id", "cdw_hash_key"):
#                 if cand in violation_df.columns:
#                     fail_keys_df = violation_df.select(cand).distinct()
#                     fail_key_col = cand
#                     break

#         # Severity escalation vs historical average (same thresholds as original)
#         try:
#             past_logs_df = spark.sql(f"""
#                 SELECT AVG(violation_count) AS avg_violations
#                 FROM {result_catalog}.{result_schema}.dq_logs
#                 WHERE rule_id = '{rule_id}' AND table_name = '{table_name}'
#                   AND violation_count IS NOT NULL
#             """)
#             avg_violations = past_logs_df.collect()[0]['avg_violations']
#             if avg_violations:
#                 increase_ratio = violation_count / avg_violations
#                 if increase_ratio > 1.10:
#                     severity = "Critical"
#                     print(f"🚨 Violations {violation_count} >10% over average "
#                           f"({avg_violations:.2f}). Severity escalated to CRITICAL.")
#                 elif increase_ratio > 1.07:
#                     severity = "Alert"
#                     print(f"⚠️ Violations {violation_count} >7% over average "
#                           f"({avg_violations:.2f}). Severity set to ALERT.")
#         except Exception as e:
#             print(f"⚠️ Could not compute past average violations: {str(e)}")

#         if violation_count > 0:
#             violation_id = f"dqv_{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4()}"
#             try:
#                 move_bad_records_to_table(spark, result_catalog, result_schema,
#                                           rule_id, pipeline_key, catalog_name,
#                                           schema_name, table_name, violation_df,
#                                           violation_id, batch_timestamp)
#             except Exception as e:
#                 print(f"❌ Error moving bad records: {str(e)}")
#                 return success_count, 1, severity, violation_id, fail_keys_df, fail_key_col
#             failure_count += 1
#         else:
#             success_count += 1

#         threshold = int(violation_threshold or 0)
#         status = "Fail" if violation_count > threshold else "Pass"

#         _write_log(spark, result_catalog, result_schema, rule_id, pipeline_key,
#                    catalog_name, schema_name, table_name, column_name,
#                    condition_category, condition_type, status, violation_count,
#                    violation_id, severity, batch_timestamp)

#         if original_severity != "Critical" and severity == "Critical":
#             print(f"🚨 Severity escalated to CRITICAL due to abnormal "
#                   f"violation count: {violation_count}")

#     except Exception as e:
#         print(f"❌ Error in dq_logs: {str(e)}")
#         dq_error_logs(spark, result_catalog, result_schema, rule_id, pipeline_key,
#                       violation_id, catalog_name, schema_name, table_name,
#                       f"DQ Logs Error: {str(e)}", batch_timestamp)
#         failure_count += 1

#     return (success_count, failure_count, severity, violation_id,
#             fail_keys_df, fail_key_col)


# def _write_log(spark, result_catalog, result_schema, rule_id, pipeline_key,
#                catalog_name, schema_name, table_name, column_name,
#                condition_category, condition_type, status, violation_count,
#                violation_id, severity, batch_timestamp):
#     log_id = f"dql_{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4()}"
#     log_row = Row(
#         log_id=log_id,
#         rule_id=rule_id,
#         pipeline_key=str(pipeline_key) if pipeline_key is not None else None,
#         catalog_name=catalog_name,
#         schema_name=schema_name,
#         table_name=table_name,
#         column_name=column_name,
#         condition_category=condition_category,
#         condition_type=condition_type,
#         status=status,
#         violation_count=int(violation_count),
#         violation_id=violation_id,
#         severity=severity,
#         batch_timestamp=batch_timestamp
#     )
#     spark.createDataFrame([log_row], schema=dq_log_schema) \
#          .write.format("delta").mode("append") \
#          .saveAsTable(f"{result_catalog}.{result_schema}.dq_logs")







from pyspark.sql import Row
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType
from datetime import datetime, timezone
import uuid

from move_bad_records import move_bad_records_to_table
from dq_error_logger import dq_error_logs

dq_log_schema = StructType([
    StructField("log_id", StringType(), True),
    StructField("rule_id", StringType(), True),
    StructField("pipeline_key", StringType(), True),
    StructField("catalog_name", StringType(), False),
    StructField("schema_name", StringType(), False),
    StructField("table_name", StringType(), False),
    StructField("column_name", StringType(), True),
    StructField("condition_category", StringType(), True),
    StructField("condition_type", StringType(), True),
    StructField("status", StringType(), True),
    StructField("violation_count", IntegerType(), True),
    StructField("violation_id", StringType(), True),
    StructField("severity", StringType(), True),
    StructField("batch_timestamp", TimestampType(), True)
])


def dq_logs(spark, result_catalog, result_schema, rule_id, query, pipeline_key,
            catalog_name, schema_name, table_name, column_name,
            condition_category, condition_type, severity, batch_timestamp,
            violation_threshold=0):
    """Executes one rule's violation query and writes the audit trail.

    Changes vs original:
      - NO pipeline_metadata / table_id lookup (removed entirely)
      - result tables addressed as {result_catalog}.{result_schema}.*
      - honors violation_threshold from dq_rules for Pass/Fail status
      - returns (success_count, failure_count, severity, violation_id,
        fail_keys_df, fail_key_col): the DISTINCT failing keys captured
        IN-SESSION from the violation DataFrame (_dq_row_id preferred,
        cdw_hash_key fallback) so the executor can exclude failing records
        from the cleaned dataset without any JSON round trip
      - the query builder may return an error STRING instead of SQL
        (original repo convention) — that is logged to dq_error_logs and
        counted as an execution failure."""
    success_count = 0
    failure_count = 0
    violation_count = 0
    violation_id = None
    original_severity = severity

    try:
        if isinstance(batch_timestamp, str):
            try:
                batch_timestamp = datetime.fromisoformat(batch_timestamp)
            except Exception as e:
                print(f"❌ Invalid batch_timestamp: {str(e)}")
                return success_count, 1, severity, None, None, None

        if not isinstance(batch_timestamp, datetime):
            print("❌ batch_timestamp must be a datetime object.")
            return success_count, 1, severity, None, None, None

        # Builders return an "Error: ..." string when validation fails
        if not isinstance(query, str) or not query.strip().upper().startswith(("SELECT", "WITH")):
            error_message = f"Rule construction failed: {query}"
            print(f"❌ {error_message}")
            dq_error_logs(spark, result_catalog, result_schema, rule_id, pipeline_key,
                          None, catalog_name, schema_name, table_name,
                          error_message, batch_timestamp)
            _write_log(spark, result_catalog, result_schema, rule_id, pipeline_key,
                       catalog_name, schema_name, table_name, column_name,
                       condition_category, condition_type, "Error", 0, None,
                       severity, batch_timestamp)
            return success_count, 1, severity, None, None, None

        try:
            violation_df = spark.sql(query)
            violation_count = violation_df.count()
        except Exception as e:
            print(f"❌ Error executing query: {str(e)}")
            dq_error_logs(spark, result_catalog, result_schema, rule_id, pipeline_key,
                          None, catalog_name, schema_name, table_name,
                          f"Query Execution Error: {str(e)}", batch_timestamp)
            _write_log(spark, result_catalog, result_schema, rule_id, pipeline_key,
                       catalog_name, schema_name, table_name, column_name,
                       condition_category, condition_type, "Error", 0, None,
                       severity, batch_timestamp)
            return success_count, 1, severity, None, None, None

        # Capture failing keys in-session (exact, no JSON round trip)
        fail_keys_df, fail_key_col = None, None
        if violation_count > 0:
            for cand in ("_dq_row_id", "cdw_hash_key"):
                if cand in violation_df.columns:
                    fail_keys_df = violation_df.select(cand).distinct()
                    fail_key_col = cand
                    break

        # Severity escalation vs historical average (same thresholds as original)
        try:
            past_logs_df = spark.sql(f"""
                SELECT AVG(violation_count) AS avg_violations
                FROM {result_catalog}.{result_schema}.dq_logs
                WHERE rule_id = '{rule_id}' AND table_name = '{table_name}'
                  AND violation_count IS NOT NULL
            """)
            avg_violations = past_logs_df.collect()[0]['avg_violations']
            if avg_violations:
                increase_ratio = violation_count / avg_violations
                if increase_ratio > 1.10:
                    severity = "Critical"
                    print(f"🚨 Violations {violation_count} >10% over average "
                          f"({avg_violations:.2f}). Severity escalated to CRITICAL.")
                elif increase_ratio > 1.07:
                    severity = "Alert"
                    print(f"⚠️ Violations {violation_count} >7% over average "
                          f"({avg_violations:.2f}). Severity set to ALERT.")
        except Exception as e:
            print(f"⚠️ Could not compute past average violations: {str(e)}")

        if violation_count > 0:
            violation_id = f"dqv_{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4()}"
            try:
                move_bad_records_to_table(spark, result_catalog, result_schema,
                                          rule_id, pipeline_key, catalog_name,
                                          schema_name, table_name, violation_df,
                                          violation_id, batch_timestamp)
            except Exception as e:
                print(f"❌ Error moving bad records: {str(e)}")
                return success_count, 1, severity, violation_id, fail_keys_df, fail_key_col
            failure_count += 1
        else:
            success_count += 1

        threshold = int(violation_threshold or 0)
        status = "Fail" if violation_count > threshold else "Pass"

        _write_log(spark, result_catalog, result_schema, rule_id, pipeline_key,
                   catalog_name, schema_name, table_name, column_name,
                   condition_category, condition_type, status, violation_count,
                   violation_id, severity, batch_timestamp)

        if original_severity != "Critical" and severity == "Critical":
            print(f"🚨 Severity escalated to CRITICAL due to abnormal "
                  f"violation count: {violation_count}")

    except Exception as e:
        print(f"❌ Error in dq_logs: {str(e)}")
        dq_error_logs(spark, result_catalog, result_schema, rule_id, pipeline_key,
                      violation_id, catalog_name, schema_name, table_name,
                      f"DQ Logs Error: {str(e)}", batch_timestamp)
        failure_count += 1

    return (success_count, failure_count, severity, violation_id,
            fail_keys_df, fail_key_col)


def _write_log(spark, result_catalog, result_schema, rule_id, pipeline_key,
               catalog_name, schema_name, table_name, column_name,
               condition_category, condition_type, status, violation_count,
               violation_id, severity, batch_timestamp):
    log_id = f"dql_{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4()}"
    log_row = Row(
        log_id=log_id,
        rule_id=rule_id,
        pipeline_key=str(pipeline_key) if pipeline_key is not None else None,
        catalog_name=catalog_name,
        schema_name=schema_name,
        table_name=table_name,
        column_name=column_name,
        condition_category=condition_category,
        condition_type=condition_type,
        status=status,
        violation_count=int(violation_count),
        violation_id=violation_id,
        severity=severity,
        batch_timestamp=batch_timestamp
    )
    spark.createDataFrame([log_row], schema=dq_log_schema) \
         .write.format("delta").mode("append") \
         .saveAsTable(f"{result_catalog}.{result_schema}.dq_logs")

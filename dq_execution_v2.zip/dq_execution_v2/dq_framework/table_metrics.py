"""Table metrics — restored from the original repo with these adaptations:
  - pipeline_key / pipeline_name / table_id come from
    {config}.dq_pipeline_metadata via a TOLERANT lookup (NULLs if the table
    or row is absent, instead of the original hard crash on ds_training_1)
  - KPI metrics computed only for KPI_CHECK rules of THIS table
  - column metrics single-pass and optional (config: compute_column_metrics)
  - writes to {result_catalog}.{result_schema}.dq_table_metrics
  - adds a `flag` column (Success/Failure) updated after DQ execution
"""
import json
import re
from datetime import datetime, timezone

from pyspark.sql import functions as F
from pyspark.sql.functions import col, count, countDistinct, when, trim, lower
from pyspark.sql.types import (StructType, StructField, StringType, LongType,
                               DoubleType, TimestampType)

metrics_schema = StructType([
    StructField("pipeline_key", StringType(), True),
    StructField("pipeline_name", StringType(), True),
    StructField("table_id", LongType(), True),
    StructField("catalog", StringType(), True),
    StructField("schema", StringType(), True),
    StructField("table_name", StringType(), True),
    StructField("metric_level", StringType(), True),
    StructField("process_start_time", TimestampType(), True),
    StructField("process_end_time", TimestampType(), True),
    StructField("execution_duration_sec", DoubleType(), True),
    StructField("row_count", LongType(), True),
    StructField("duplicate_rows", LongType(), True),
    StructField("column_name", StringType(), True),
    StructField("distinct_count", LongType(), True),
    StructField("null_count", LongType(), True),
    StructField("null_percentage", DoubleType(), True),
    StructField("schema_change", StringType(), True),
    StructField("job_run_id", StringType(), True),
    StructField("batch_timestamp", TimestampType(), True),
    StructField("kpi_metric_value", StringType(), True),
    StructField("flag", StringType(), True),
])

SCHEMA_CHANGE_OPERATIONS = [
    "ADD COLUMNS", "DROP COLUMNS", "RENAME COLUMN", "SET TBLPROPERTIES",
    "CREATE OR REPLACE TABLE AS SELECT", "ADD CONSTRAINT",
]


def get_pipeline_info(spark, config_catalog, config_schema,
                      catalog_name, schema_name, table_name):
    """Tolerant lookup in dq_pipeline_metadata: (pipeline_key, pipeline_name,
    table_id) or (None, None, None) when unregistered — never raises."""
    try:
        rows = spark.sql(f"""
            SELECT pipeline_key, pipeline_name, table_id
            FROM {config_catalog}.{config_schema}.dq_pipeline_metadata
            WHERE LOWER(catalog_name) = LOWER('{catalog_name}')
              AND LOWER(schema_name)  = LOWER('{schema_name}')
              AND LOWER(table_name)   = LOWER('{table_name}')
            ORDER BY batch_timestamp DESC LIMIT 1
        """).collect()
        if rows:
            r = rows[0]
            return (str(r["pipeline_key"]) if r["pipeline_key"] is not None else None,
                    r["pipeline_name"], r["table_id"])
    except Exception as e:
        print(f"⚠️ dq_pipeline_metadata lookup skipped: {e}")
    return None, None, None


def _detect_schema_change(spark, result_catalog, result_schema,
                          catalog, schema, table_name):
    """Same approach as the original: compare Delta history schema operations
    against the last version recorded in dq_table_metrics."""
    try:
        history_df = spark.sql(f"DESCRIBE HISTORY {catalog}.{schema}.{table_name}")
        changes = (history_df
                   .filter(col("operation").isin(SCHEMA_CHANGE_OPERATIONS))
                   .select("version", "timestamp", "operation", "operationParameters")
                   .orderBy(col("version").desc()))

        last_recorded = spark.sql(f"""
            SELECT exploded.version AS v
            FROM (SELECT explode(from_json(schema_change,
                    'array<struct<version:int,operation:string,operationParameters:map<string,string>>>')) AS exploded
                  FROM {result_catalog}.{result_schema}.dq_table_metrics
                  WHERE table_name = '{table_name}' AND catalog = '{catalog}'
                    AND schema = '{schema}' AND metric_level = 'TABLE'
                    AND schema_change IS NOT NULL
                    AND schema_change != 'No Schema Change detected')
            ORDER BY v DESC LIMIT 1
        """).collect()
        last_version = last_recorded[0]["v"] if last_recorded else -1

        new_changes = changes.filter(col("version") > last_version).collect()
        if not new_changes:
            return "No Schema Change detected"
        return json.dumps([{
            "version": r["version"],
            "operation": r["operation"],
            "operationParameters": dict(r["operationParameters"] or {}),
        } for r in new_changes])
    except Exception as e:
        print(f"⚠️ Schema-change detection skipped: {e}")
        return None


def _compute_kpi_metrics(spark, config_catalog, config_schema,
                         catalog, schema, table_name):
    """kpi_metric_value JSON for KPI_CHECK rules of THIS table only.
    This history is what construct_kpi_aggregation_query trends against."""
    try:
        rules = spark.sql(f"""
            SELECT rule_id, condition_criteria
            FROM {config_catalog}.{config_schema}.dq_rules
            WHERE UPPER(condition_type) IN ('KPI_CHECK','KPI_METRICS','KPI_METRICS_CHECK')
              AND LOWER(catalog_name) = LOWER('{catalog}')
              AND LOWER(schema_name)  = LOWER('{schema}')
              AND LOWER(table_name)   = LOWER('{table_name}')
        """).collect()
        if not rules:
            return None

        from utils import fill_placeholders
        kpi_metric_value = {}
        for rule in rules:
            raw = (rule["condition_criteria"] or "{}").strip()
            try:
                criteria = json.loads(raw)
            except Exception:
                criteria = json.loads(raw.replace("'", '"'))

            if criteria.get("custom_query"):
                # Style B: custom SQL producing metric_name / metric_value
                query = fill_placeholders(
                    str(criteria["custom_query"]).strip().rstrip(";"),
                    catalog, schema, table_name)
                kdf = spark.sql(query)
                cols = kdf.columns
                name_col = "metric_name" if "metric_name" in cols else cols[0]
                value_col = "metric_value" if "metric_value" in cols else cols[-1]
                grouped = kdf.select(
                    F.col(name_col).cast("string").alias("region_name"),
                    F.col(value_col).cast("double").alias("region_metric"))
            else:
                # Style A: agg_type / agg_column / group_by_columns
                agg_type = str(criteria.get("agg_type", "")).lower()
                agg_column = criteria.get("agg_column")
                group_by_columns = criteria.get("group_by_columns") or []
                if agg_type not in ("avg", "sum", "count", "max", "min") \
                        or not agg_column or not group_by_columns:
                    print(f"⚠️ KPI rule {rule['rule_id']}: unusable criteria "
                          f"{criteria} — skipped in metrics history")
                    continue
                df = spark.table(f"{catalog}.{schema}.{table_name}")
                agg_expr = {"avg": F.avg(F.expr(agg_column)),
                            "sum": F.sum(F.expr(agg_column)),
                            "count": F.count(F.expr(agg_column)),
                            "max": F.max(F.expr(agg_column)),
                            "min": F.min(F.expr(agg_column))}[agg_type]
                grouped = (df.groupBy(*[F.col(c.strip("`")) for c in group_by_columns])
                             .agg(agg_expr.alias("region_metric"))
                             .withColumn("region_name",
                                         F.col(group_by_columns[0].strip("`"))
                                          .cast("string"))
                             .select("region_name", "region_metric"))

            for row in grouped.collect():
                if row["region_metric"] is not None:
                    kpi_metric_value[str(row["region_name"])] = \
                        float(row["region_metric"])
        return json.dumps(kpi_metric_value) if kpi_metric_value else None
    except Exception as e:
        print(f"⚠️ KPI metrics computation skipped: {e}")
        return None


def calculate_dq_table_metrics(spark, config_catalog, config_schema,
                               result_catalog, result_schema,
                               catalog, schema, table_name, job_run_id,
                               start_time, batch_timestamp,
                               compute_column_metrics=True,
                               compute_kpi_metrics=True):
    full_table_name = f"{catalog}.{schema}.{table_name}"
    print(f"\n📊 Executing Table Metrics for {full_table_name}")

    pipeline_key, pipeline_name, table_id = get_pipeline_info(
        spark, config_catalog, config_schema, catalog, schema, table_name)

    start_time = start_time or datetime.now(timezone.utc)
    batch_timestamp = batch_timestamp or datetime.now(timezone.utc)
    if isinstance(start_time, str):
        start_time = datetime.fromisoformat(start_time)
    if isinstance(batch_timestamp, str):
        batch_timestamp = datetime.fromisoformat(batch_timestamp)
    if start_time.tzinfo is None:
        start_time = start_time.replace(tzinfo=timezone.utc)

    try:
        df = spark.table(full_table_name)
    except Exception as e:
        print(f"❌ Error reading table {full_table_name}: {e}")
        return

    # ---- table-level metrics ------------------------------------------------
    row_count, duplicate_rows = 0, 0
    try:
        row_count = df.count()
        dup = (df.groupBy(df.columns).count().filter("count > 1")
                 .agg(F.sum("count").alias("s")).collect()[0]["s"])
        duplicate_rows = int(dup) if dup is not None else 0
    except Exception as e:
        print(f"⚠️ Row metrics error: {e}")

    # ---- column-level metrics (single pass) ---------------------------------
    column_metrics = []
    if compute_column_metrics and row_count > 0:
        try:
            aggs = []
            for c in df.columns:
                aggs.append(countDistinct(col(c)).alias(f"{c}__distinct"))
                aggs.append(count(when(
                    col(c).isNull() |
                    (trim(col(c).cast("string")) == "") |
                    (lower(trim(col(c).cast("string"))) == "none"), 1
                )).alias(f"{c}__nulls"))
            stats = df.select(*aggs).collect()[0]
            for c in df.columns:
                null_count = int(stats[f"{c}__nulls"] or 0)
                distinct_count = int(stats[f"{c}__distinct"] or 0)
                null_percentage = round(null_count / row_count * 100, 2)
                column_metrics.append((c, distinct_count, null_count, null_percentage))
        except Exception as e:
            print(f"⚠️ Column metrics error: {e}")

    # ---- KPI metrics ---------------------------------------------------------
    kpi_metric_value = _compute_kpi_metrics(
        spark, config_catalog, config_schema, catalog, schema, table_name) \
        if compute_kpi_metrics else None

    # ---- schema-change detection ---------------------------------------------
    schema_change = _detect_schema_change(
        spark, result_catalog, result_schema, catalog, schema, table_name)

    end_time = datetime.now(timezone.utc)
    duration = round((end_time - start_time).total_seconds(), 2)

    rows = [(pipeline_key, pipeline_name, table_id, catalog, schema, table_name,
             "TABLE", start_time, end_time, duration, int(row_count),
             int(duplicate_rows), None, None, None, None, schema_change,
             job_run_id, batch_timestamp, None, None)]
    rows += [(pipeline_key, pipeline_name, table_id, catalog, schema, table_name,
              "COLUMN", start_time, end_time, duration, None, None,
              c, d, n, p, None, job_run_id, batch_timestamp, None, None)
             for (c, d, n, p) in column_metrics]
    if kpi_metric_value:
        rows.append((pipeline_key, pipeline_name, table_id, catalog, schema,
                     table_name, "KPI", start_time, end_time, duration, None,
                     None, None, None, None, None, None, job_run_id,
                     batch_timestamp, kpi_metric_value, None))

    try:
        (spark.createDataFrame(rows, schema=metrics_schema)
              .write.format("delta").mode("append")
              .option("mergeSchema", "true")
              .saveAsTable(f"{result_catalog}.{result_schema}.dq_table_metrics"))
        print(f"📊 Table Metrics logged for {full_table_name} ({len(rows)} rows)")
    except Exception as e:
        print(f"❌ Error logging table metrics for {full_table_name}: {e}")

    return pipeline_key, pipeline_name, table_id


def update_metrics_flag(spark, result_catalog, result_schema,
                        catalog, schema, table_name, job_run_id, flag):
    """After DQ execution: mark this run's metrics rows Success/Failure
    (this is what email alerting keyed on in the original)."""
    try:
        spark.sql(f"""
            UPDATE {result_catalog}.{result_schema}.dq_table_metrics
            SET flag = '{flag}'
            WHERE table_name = '{table_name}' AND catalog = '{catalog}'
              AND schema = '{schema}' AND job_run_id = '{job_run_id}'
        """)
        print(f"🏁 dq_table_metrics flag = {flag} for {table_name} (run {job_run_id})")
    except Exception as e:
        print(f"⚠️ Could not update metrics flag: {e}")

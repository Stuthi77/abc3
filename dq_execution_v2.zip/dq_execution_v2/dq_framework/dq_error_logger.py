from pyspark.sql.types import StructType, StructField, StringType, TimestampType
from datetime import datetime, timezone
import uuid
import json

# ============================= #
# DQ Error Logs Schema           #
# ============================= #
dq_error_logs_schema = StructType([
    StructField("error_id", StringType(), True),
    StructField("rule_id", StringType(), True),
    StructField("pipeline_key", StringType(), True),
    StructField("violation_id", StringType(), True),
    StructField("catalog_name", StringType(), False),
    StructField("schema_name", StringType(), False),
    StructField("table_name", StringType(), False),
    StructField("error_details", StringType(), True),
    StructField("batch_timestamp", TimestampType(), True),
])


def dq_error_logs(spark, result_catalog, result_schema, rule_id, pipeline_key, violation_id,
                  catalog_name, schema_name, table_name, error_details, batch_timestamp):
    """Same behavior as the original, except:
    - audit table is {result_catalog}.{result_schema}.dq_error_logs
      (independent of the source table's catalog)
    - no pipeline_metadata involvement (pipeline_key passes through as-is,
      may be None)."""
    try:
        if isinstance(batch_timestamp, str):
            batch_timestamp = datetime.fromisoformat(batch_timestamp)
        if not isinstance(batch_timestamp, datetime):
            batch_timestamp = datetime.now(timezone.utc)

        error_id = f"dqerr{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4()}"

        error_df = spark.createDataFrame([{
            "error_id": error_id,
            "rule_id": rule_id,
            "pipeline_key": str(pipeline_key) if pipeline_key is not None else None,
            "violation_id": violation_id,
            "catalog_name": catalog_name,
            "schema_name": schema_name,
            "table_name": table_name,
            "error_details": json.dumps(error_details) if not isinstance(error_details, str) else error_details,
            "batch_timestamp": batch_timestamp
        }], schema=dq_error_logs_schema)

        error_df.write.format("delta").mode("append") \
                .saveAsTable(f"{result_catalog}.{result_schema}.dq_error_logs")

        print(f"\n⚠️ Error logged for: {catalog_name}.{schema_name}.{table_name} "
              f"| Rule ID: {rule_id}. See {result_catalog}.{result_schema}.dq_error_logs")
    except Exception as e:
        print(f"\n❌ Failed to log error: {str(e)}")

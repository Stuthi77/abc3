import json
from utils import qualified, unbq

# ✅ JSON schema validator
def validate_json_conditions(spark,condition_criteria, required_keys_with_types):
    try:
        parsed_json = json.loads(condition_criteria)
    except json.JSONDecodeError:
        return False, "Error: Invalid JSON format in condition_criteria."

    for key, expected_types in required_keys_with_types.items():
        if key not in parsed_json:
            return False, f"Error: Missing required key '{key}' in condition_criteria."
        if not isinstance(parsed_json[key], expected_types):
            return False, f"Error: Key '{key}' must be of type {expected_types}, but got {type(parsed_json[key])}."

    return True, parsed_json

# ✅ Single-column type validator
def validate_column_type(spark,catalog_name, schema_name, table_name, column_name, allowed_types):
    try:
        full_table = qualified(catalog_name, schema_name, table_name)
        for field in spark.table(full_table).schema.fields:
            if field.name == unbq(column_name):
                column_type = field.dataType.simpleString()
                if not any(column_type == t or column_type.startswith(t + "(") for t in allowed_types):
                    return False, f"Error: Column '{column_name}' must be of type {allowed_types}, found: {column_type}."
                return True, column_type
        return False, f"Error: Column '{column_name}' not found in table {full_table}."
    except Exception as e:
        return False, f"Error checking column type: {str(e)}"

# ✅ Multi-column type validator
def validate_multiple_columns_type(spark,catalog_name, schema_name, table_name, columns, allowed_types):
    try:
        full_table = qualified(catalog_name, schema_name, table_name)
        schema = {field.name: field.dataType.simpleString() for field in spark.table(full_table).schema.fields}
        
        for col in columns:
            col = unbq(col)
            if col not in schema:
                return False, f"Error: Column '{col}' not found in table {full_table}."
            if not any(schema[col] == t or schema[col].startswith(t + "(") for t in allowed_types):
                return False, f"Error: Column '{col}' must be of type {allowed_types}, found: {schema[col]}."

        return True, "All columns valid."
    except Exception as e:
        return False, f"Error validating multiple columns: {str(e)}"


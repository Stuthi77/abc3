NULL_EQUIVALENTS = [
    "''", "null", "none", "n/a", "na", "unknown", "missing",
    "undefined", "nan", "?", "-", "--", "tbd", "0", "9999", "999999"
]

alias_map = {
    'usa': ['us', 'united states', 'u.s.', 'usa', 'u.s.a.', 'america', 'united states of america'],
    'canada': ['canada', 'ca'],
    'mexico': ['mexico', 'mx'],
    'united kingdom': ['uk', 'united kingdom', 'great britain', 'england', 'scotland', 'wales'],
    'germany': ['germany', 'de', 'deutschland'],
    'france': ['france', 'fr'],
    'india': ['india', 'in', 'bharat'],
    'china': ['china', 'cn', 'prc'],
    'japan': ['japan', 'jp', 'nippon'],
    'australia': ['australia', 'au'],
    'brazil': ['brazil', 'br'],
    'italy': ['italy', 'it'],
    'spain': ['spain', 'es'],
    'russia': ['russia', 'ru', 'russian federation'],
    'south korea': ['south korea', 'kr', 'republic of korea'],
    'north korea': ['north korea', 'kp', 'dprk'],
    'south africa': ['south africa', 'za'],
    'new zealand': ['new zealand', 'nz'],
    'netherlands': ['netherlands', 'holland', 'nl'],
    'sweden': ['sweden', 'se'],
    'norway': ['norway', 'no'],
    'denmark': ['denmark', 'dk'],
    'switzerland': ['switzerland', 'ch'],
    'ireland': ['ireland', 'ie'],
    'argentina': ['argentina', 'ar'],
    'colombia': ['colombia', 'co']
}
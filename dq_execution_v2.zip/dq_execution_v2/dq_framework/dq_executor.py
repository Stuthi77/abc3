# ====================================================================================================
# 📊 DQ STATUS SUMMARY for {catalog_name}.{schema_name}.{tbl}
# ----------------------------------------------------------------------------------------------------
# ✅ TOTAL CHECKS: {total}   🟢 SUCCESS: {success}   🔴 FAILURE: {failure}   🏁 FLAG: {final_flag}
# 📜 Logs: {result_catalog}.{result_schema}.dq_logs | Bad records: {result_catalog}.{result_schema}.dq_bad_records | Errors: {result_catalog}.{result_schema}.dq_error_logs
# ====================================================================================================""")

#     # ---- run summary ---------------------------------------------------------
#     print("\n================ RUN SUMMARY ================")
#     print(f"Batch timestamp : {batch_timestamp}")
#     print(f"Catalog.Schema  : {catalog_name}.{schema_name}")
#     for (t, b, c, bad, n, flag, outcome) in run_summary:
#         print(f"  {t:<30} batch={b:<10} clean={c:<10} bad={bad:<8} "
#               f"rules={n:<4} flag={flag:<8} {outcome}")
#     return run_summary



from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import json
import re
import uuid

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

from query_builder import (construct_query, normalize_type,
                           COMPOSITE_COLUMN_TYPES, TABLE_LEVEL_TYPES,
                           NO_COLUMN_TYPES)
from dq_logger import dq_logs, _write_log
from dq_error_logger import dq_error_logs
from utils import (fix_iso_timestamp, fill_placeholders, sanitize_columns,
                   sanitize_name)
from table_metrics import (calculate_dq_table_metrics, update_metrics_flag,
                           get_pipeline_info)

WATERMARK_COLUMN = "cdw_modifieddate"
HASH_KEY_COLUMN = "cdw_hash_key"
ROW_ID_COLUMN = "_dq_row_id"

# Default target types by rule (used when the source column is STRING).
# Override per rule via condition_criteria: {"cast_to": "int|bigint|double|
# decimal(18,2)|date|timestamp|string", ...}
CAST_DEFAULTS = {
    "RANGE_CHECK": "double",
    "VALUE_THRESHOLD": "double",
    "OUTLIER_DETECTION": "double",
    "DATE_RANGE": "timestamp",
    "TIME_STAMP_CHECK": "timestamp",
}
ALLOWED_CAST_TYPES = re.compile(
    r"^(string|int|bigint|smallint|tinyint|float|double|boolean|date|timestamp"
    r"|decimal(\(\d+,\s*\d+\))?)$", re.IGNORECASE)
HOLD_BACK_SEVERITIES = {"CRITICAL"}
MAX_THREADS = 16

# enforcement_action on dq_rules controls what a VIOLATION does once it's
# found (auditing to dq_bad_records always happens regardless of this value):
#   BLOCK_AND_AUDIT (default, backward-compatible): audit AND exclude the
#       record from the cleaned/silver table.
#   AUDIT_ONLY: audit only — the record still gets promoted to the silver
#       table despite the violation.
BLOCKING_ACTION = "BLOCK_AND_AUDIT"
AUDIT_ONLY_ACTION = "AUDIT_ONLY"


def is_blocking_rule(rule):
    """True unless the rule is explicitly marked AUDIT_ONLY. Any other value
    (missing, null, unrecognized) defaults to blocking — the safe, backward
    -compatible behavior for rules created before this column existed."""
    return str(rule.get("enforcement_action") or BLOCKING_ACTION).strip().upper() \
        != AUDIT_ONLY_ACTION


def safe_cache(df):
    """cache() is not supported on serverless compute
    ([NOT_SUPPORTED_WITH_SERVERLESS] PERSIST TABLE). Serverless manages its
    own caching, so on that platform we simply skip it.

    NOTE: this is NOT a substitute for materialize_batch() below. cache()
    (when it works) only hints Spark to reuse a computed result — it does
    NOT detach a DataFrame's lineage. On serverless, where it's a no-op,
    batch_df stays fully lazy for the rest of the run."""
    try:
        return df.cache()
    except Exception:
        return df


def materialize_batch(spark, df, result_catalog, result_schema, table_name):
    """Physically freezes the incremental batch by writing it to a scratch
    Delta table and reading it back.

    WHY THIS IS NECESSARY: select_new_batch()'s incremental mode builds
    batch_df via a `left_anti` join against dq_bad_records (rows already
    logged as bad are "seen" and excluded). That join is lazy. Rule
    execution then writes NEW rows into dq_bad_records as violations are
    found — including AUDIT_ONLY violations, since auditing always happens
    regardless of enforcement_action. Because safe_cache() is a no-op on
    serverless, batch_df is never actually pinned down: every later action
    (each rule's violation query, and eventually clean_df.count() /
    promote_clean_records) RE-EXECUTES the anti-join against dq_bad_records
    AS IT EXISTS AT THAT MOMENT — which by then includes rows THIS SAME RUN
    already wrote. Those rows silently vanish from the recomputed batch_df,
    so they end up excluded from the cleaned table even when the rule that
    flagged them was AUDIT_ONLY and never touched fail_rowid_dfs/
    fail_hashkey_dfs at all. The exclusion looks like enforcement is being
    ignored, but it's actually the batch re-selecting itself against its
    own audit trail mid-run.

    Writing to a scratch Delta table and reading it back forces a real,
    physical materialization: the returned DataFrame's lineage is just "read
    this scratch table", with no path back to dq_bad_records or the source
    table, so nothing written during rule execution can retroactively affect
    it. Caller is responsible for dropping the scratch table when done
    (see drop_batch_scratch_table)."""
    scratch_table = f"{result_catalog}.{result_schema}._dq_batch_scratch_{table_name}_{uuid.uuid4().hex[:8]}"
    df.write.format("delta").mode("overwrite").saveAsTable(scratch_table)
    return spark.table(scratch_table), scratch_table


def drop_batch_scratch_table(spark, scratch_table):
    if not scratch_table:
        return
    try:
        spark.sql(f"DROP TABLE IF EXISTS {scratch_table}")
    except Exception as e:
        print(f"  ⚠️ Could not drop scratch table {scratch_table}: {e}")


def safe_unpersist(df):
    try:
        df.unpersist()
    except Exception:
        pass


def apply_rule_based_casting(batch_df, table_rules):
    """Bronze tables often land with every column as STRING. Before running
    DQ, cast rule columns to the type the rule implies (or an explicit
    'cast_to' in condition_criteria). try_cast is used, so unparseable values
    become NULL — they then fail NOT_NULL / range rules and are quarantined,
    which is the correct DQ outcome. The cleaned table inherits these types.

    Returns (df, cast_plan) where cast_plan is {column: target_type}."""
    dtypes = dict(batch_df.dtypes)
    cast_plan = {}

    for rule in table_rules:
        ctype = rule.get("_ctype")
        cols = [c.strip() for c in (rule.get("column_name") or "").split(",")
                if c.strip()]

        # explicit override wins, for ANY rule type
        explicit = None
        try:
            crit = json.loads(rule.get("condition_criteria") or "{}")
            explicit = crit.get("cast_to")
        except Exception:
            pass

        target = None
        if explicit:
            if not ALLOWED_CAST_TYPES.match(str(explicit).strip()):
                print(f"  ⚠️ cast_to '{explicit}' on rule {rule.get('rule_id')} "
                      f"is not a supported type — ignored")
            else:
                target = str(explicit).strip().lower()
        elif ctype in CAST_DEFAULTS:
            target = CAST_DEFAULTS[ctype]

        if not target or target == "string":
            continue
        for col_name in cols:
            current = dtypes.get(col_name)
            if current is None or current != "string":
                continue  # only cast away from STRING; never fight real types
            prev = cast_plan.get(col_name)
            if prev and prev != target:
                print(f"  ⚠️ Conflicting cast targets for `{col_name}` "
                      f"({prev} vs {target}) — keeping {prev}")
                continue
            cast_plan[col_name] = target

    for col_name, target in cast_plan.items():
        batch_df = batch_df.withColumn(
            col_name, F.expr(f"try_cast(`{col_name}` AS {target})"))
    if cast_plan:
        print(f"  Cast plan (string → typed): {cast_plan}")
    return batch_df, cast_plan


def get_spark_session(app_name="DataQualityChecksApp"):
    return SparkSession.builder.appName(app_name).enableHiveSupport().getOrCreate()


# --------------------------------------------------------------------------- #
# Rule collection                                                              #
# --------------------------------------------------------------------------- #
def fetch_rules(spark, config_catalog, config_schema, catalog_name, schema_name):
    """Step 1 — all unique ACTIVE rules for the catalog+schema.
    NOTE: no pipeline_metadata join — rules come from dq_rules alone;
    pipeline_key passes through from the rule row (may be NULL)."""
    # For each rule_id keep only its MOST RECENT version, judged by the
    # latest of updated_at / created_at (try_cast tolerates '-' or string
    # placeholders in those columns). Older versions of an edited rule are
    # ignored by execution.
    rules_df = spark.sql(f"""
        WITH ranked AS (
            SELECT r.rule_id, r.pipeline_key, r.catalog_name, r.schema_name,
                   r.table_name, r.column_name, r.condition_category,
                   r.condition_type, r.condition_criteria, r.severity,
                   r.violation_threshold,
                   UPPER(TRIM(COALESCE(r.enforcement_action, 'BLOCK_AND_AUDIT')))
                       AS enforcement_action,
                   ROW_NUMBER() OVER (
                       PARTITION BY r.rule_id
                       ORDER BY COALESCE(TRY_CAST(r.updated_at AS TIMESTAMP),
                                         TRY_CAST(r.created_at AS TIMESTAMP),
                                         TIMESTAMP'1900-01-01') DESC,
                                TRY_CAST(r.created_at AS TIMESTAMP) DESC
                   ) AS rn
            FROM {config_catalog}.{config_schema}.dq_rules r
            WHERE LOWER(r.catalog_name) = LOWER('{catalog_name}')
              AND LOWER(r.schema_name) = LOWER('{schema_name}')
              AND (r.effective_date_from IS NULL OR r.effective_date_from <= current_timestamp())
              AND (r.effective_date_to   IS NULL OR r.effective_date_to   >= current_timestamp())
        )
        SELECT rule_id, pipeline_key, catalog_name, schema_name, table_name,
               column_name, condition_category, condition_type,
               condition_criteria, severity, violation_threshold,
               enforcement_action
        FROM ranked WHERE rn = 1
    """)

    rules = [r.asDict() for r in rules_df.collect()]

    # Per-column expansion — composite-key rules (DUPLICATE/UNIQUE) stay intact
    expanded = []
    for rule in rules:
        ctype = normalize_type(rule["condition_type"])
        rule["_ctype"] = ctype
        col_raw = (rule.get("column_name") or "").strip()
        if ctype in COMPOSITE_COLUMN_TYPES or ctype in NO_COLUMN_TYPES or "," not in col_raw:
            expanded.append(rule)
        else:
            for single_col in [c.strip() for c in col_raw.split(",") if c.strip()]:
                r2 = dict(rule)
                r2["column_name"] = single_col
                expanded.append(r2)
    return rules, expanded


# --------------------------------------------------------------------------- #
# Incremental batch selection                                                  #
# --------------------------------------------------------------------------- #
def select_new_batch(spark, result_catalog, result_schema, cleaned_catalog,
                     cleaned_schema, catalog_name, schema_name, table_name):
    """Pick only not-yet-validated records.
    Priority: hash-key anti-join (retry-safe; re-picks batches withheld after
    rule errors) -> timestamp watermark -> full table."""
    source_df = spark.table(f"`{catalog_name}`.`{schema_name}`.`{table_name}`")
    cols = set(source_df.columns)
    cleaned_target = f"{cleaned_catalog}.{cleaned_schema}.{table_name}"

    if HASH_KEY_COLUMN in cols:
        seen = None
        if spark.catalog.tableExists(cleaned_target):
            seen = spark.table(cleaned_target).select(
                F.col(HASH_KEY_COLUMN).alias("k"))
        bad = (spark.table(f"{result_catalog}.{result_schema}.dq_bad_records")
               .filter((F.col("catalog_name") == catalog_name) &
                       (F.col("schema_name") == schema_name) &
                       (F.col("table_name") == table_name))
               .select(F.get_json_object("bad_record_data",
                                         f"$.{HASH_KEY_COLUMN}").alias("k"))
               .filter(F.col("k").isNotNull()))
        seen = bad if seen is None else seen.unionByName(bad)
        batch = source_df.join(seen.distinct(),
                               source_df[HASH_KEY_COLUMN] == seen["k"], "left_anti")
        return batch, f"hash-key anti-join on `{HASH_KEY_COLUMN}` (cleaned ∪ bad records)"

    if WATERMARK_COLUMN in cols:
        last = (spark.table(f"{result_catalog}.{result_schema}.dq_logs")
                .filter((F.col("catalog_name") == catalog_name) &
                        (F.col("schema_name") == schema_name) &
                        (F.col("table_name") == table_name))
                .agg(F.max("batch_timestamp").alias("t")).collect()[0]["t"])
        batch = source_df if last is None else \
            source_df.filter(F.col(WATERMARK_COLUMN).cast("timestamp") > F.lit(last))
        return batch, f"ts watermark on `{WATERMARK_COLUMN}` (last={last})"

    return source_df, "FULL TABLE (no hash key / watermark column)"


# --------------------------------------------------------------------------- #
# Table-level: ROW_COUNT_TREND                                                 #
# --------------------------------------------------------------------------- #
def run_row_count_trend(spark, result_catalog, result_schema, rule,
                        batch_count, batch_timestamp):
    import json as _json
    try:
        criteria = _json.loads(rule.get("condition_criteria") or "{}")
    except Exception:
        criteria = {}
    interval = int(criteria.get("interval", 30))

    hist = spark.sql(f"""
        SELECT AVG(violation_count) AS mu, STDDEV(violation_count) AS sigma
        FROM {result_catalog}.{result_schema}.dq_logs
        WHERE catalog_name = '{rule["catalog_name"]}'
          AND schema_name  = '{rule["schema_name"]}'
          AND table_name   = '{rule["table_name"]}'
          AND condition_type = 'ROW_COUNT_TREND'
          AND status = 'Pass'
          AND batch_timestamp >= date_sub(current_timestamp(), {interval})
    """).collect()[0]

    mu, sigma = hist["mu"], hist["sigma"]
    status = "Pass"
    if mu is not None and sigma not in (None, 0):
        if batch_count < mu - 3 * sigma or batch_count > mu + 3 * sigma:
            status = "Fail"

    # violation_count stores the OBSERVED batch count so history accumulates
    _write_log(spark, result_catalog, result_schema, rule["rule_id"],
               rule.get("pipeline_key"), rule["catalog_name"], rule["schema_name"],
               rule["table_name"], rule.get("column_name"),
               rule.get("condition_category"), "ROW_COUNT_TREND", status,
               batch_count, None, rule.get("severity"), batch_timestamp)
    return status


def run_kpi_check(spark, result_catalog, result_schema, rule,
                  catalog_name, schema_name, table_name, batch_timestamp,
                  violation_threshold=0):
    """Self-contained KPI check (replaces the fragile repo query that depended
    on a dq_metrics table that never existed). Supports BOTH criteria styles:

    Style A (aggregation):
      {"agg_type": "sum", "agg_column": "`2023_|_12`",
       "group_by_columns": ["Category"],
       "upper_threshold": 10000, "lower_threshold": 0}          # optional
    Style B (custom SQL):
      {"custom_query": "SELECT x AS metric_name, AVG(y) AS metric_value
                        FROM {catalog_name}.{schema_name}.{table_name}
                        GROUP BY x",
       "upper_threshold": ..., "lower_threshold": ...}          # optional

    Evaluation:
      - explicit upper/lower thresholds -> metric outside them = violation
      - no thresholds -> compare against mean ± 3σ of this metric's history
        in dq_table_metrics (metric_level='KPI'); with no history yet, PASS
        and just record the observation.
    Violating metric rows are stored in dq_bad_records as JSON for RCA."""
    import json as _json
    from move_bad_records import move_bad_records_to_table

    violation_id = None
    try:
        raw = rule.get("condition_criteria") or "{}"
        try:
            criteria = _json.loads(raw)
        except Exception:
            criteria = _json.loads(raw.replace("'", '"'))

        # ---- build (metric_name, metric_value) --------------------------------
        if criteria.get("custom_query"):
            query = fill_placeholders(
                str(criteria["custom_query"]).strip().rstrip(";"),
                catalog_name, schema_name, table_name)
            kpi_df = spark.sql(query)
            cols = kpi_df.columns
            name_col = "metric_name" if "metric_name" in cols else cols[0]
            value_col = "metric_value" if "metric_value" in cols else cols[-1]
            metrics_df = kpi_df.select(
                F.col(name_col).cast("string").alias("metric_name"),
                F.col(value_col).cast("double").alias("metric_value"))
        else:
            agg_type = str(criteria.get("agg_type", "")).lower()
            agg_column = criteria.get("agg_column")
            group_by = criteria.get("group_by_columns") or []
            if agg_type not in ("avg", "sum", "count", "max", "min")                     or not agg_column or not group_by:
                raise ValueError(
                    "KPI_CHECK needs either 'custom_query' OR "
                    "'agg_type' + 'agg_column' + 'group_by_columns'. "
                    f"Got: {criteria}")
            gb = ", ".join(f"`{c.strip('`')}`" for c in group_by)
            metrics_df = spark.sql(f"""
                SELECT CAST({gb.split(',')[0]} AS STRING) AS metric_name,
                       CAST({agg_type.upper()}({agg_column}) AS DOUBLE)
                           AS metric_value
                FROM `{catalog_name}`.`{schema_name}`.`{table_name}`
                GROUP BY {gb}
            """)

        upper = criteria.get("upper_threshold")
        lower = criteria.get("lower_threshold")

        # ---- evaluate ----------------------------------------------------------
        if upper is not None or lower is not None:
            cond = F.lit(False)
            if upper is not None:
                cond = cond | (F.col("metric_value") > float(upper))
            if lower is not None:
                cond = cond | (F.col("metric_value") < float(lower))
            violating = metrics_df.filter(cond) \
                .withColumn("kpi_reason", F.lit("outside configured thresholds"))
        else:
            hist = spark.sql(f"""
                SELECT explode(from_json(kpi_metric_value,
                           'map<string,double>')) AS (metric_name, metric_value)
                FROM {result_catalog}.{result_schema}.dq_table_metrics
                WHERE metric_level = 'KPI'
                  AND table_name = '{table_name}'
                  AND catalog = '{catalog_name}' AND schema = '{schema_name}'
                  AND kpi_metric_value IS NOT NULL
            """)
            stats = (hist.groupBy("metric_name")
                     .agg(F.mean("metric_value").alias("mu"),
                          F.stddev("metric_value").alias("sigma")))
            joined = metrics_df.join(stats, on="metric_name", how="left")
            violating = (joined
                         .filter(F.col("sigma").isNotNull() & (F.col("sigma") != 0))
                         .filter((F.col("metric_value") >
                                  F.col("mu") + 3 * F.col("sigma")) |
                                 (F.col("metric_value") <
                                  F.col("mu") - 3 * F.col("sigma")))
                         .withColumn("kpi_reason",
                                     F.lit("outside mean ± 3σ of history"))
                         .select("metric_name", "metric_value", "mu", "sigma",
                                 "kpi_reason"))

        violations = violating.count()
        threshold = int(violation_threshold or 0)
        status = "Fail" if violations > threshold else "Pass"

        if violations > 0:
            violation_id = f"dqv_{uuid.uuid4()}"
            try:
                move_bad_records_to_table(
                    spark, result_catalog, result_schema, rule["rule_id"],
                    rule.get("pipeline_key"), catalog_name, schema_name,
                    table_name, violating, violation_id, batch_timestamp)
            except Exception as e:
                print(f"  ⚠️ Could not store violating KPI metrics: {e}")

        _write_log(spark, result_catalog, result_schema, rule["rule_id"],
                   rule.get("pipeline_key"), catalog_name, schema_name,
                   table_name, rule.get("column_name"),
                   rule.get("condition_category"), "KPI_CHECK", status,
                   violations, violation_id, rule.get("severity"),
                   batch_timestamp)
        return status, violations
    except Exception as e:
        dq_error_logs(spark, result_catalog, result_schema, rule["rule_id"],
                      rule.get("pipeline_key"), violation_id, catalog_name,
                      schema_name, table_name, f"KPI_CHECK error: {e}",
                      batch_timestamp)
        _write_log(spark, result_catalog, result_schema, rule["rule_id"],
                   rule.get("pipeline_key"), catalog_name, schema_name,
                   table_name, rule.get("column_name"),
                   rule.get("condition_category"), "KPI_CHECK", "Error", 0,
                   None, rule.get("severity"), batch_timestamp)
        raise


# --------------------------------------------------------------------------- #
# Clean-record promotion                                                       #
# --------------------------------------------------------------------------- #
def count_distinct_keys(dfs):
    """Distinct row count across a list of single-column key DataFrames.
    Used to report how many rows had AUDIT_ONLY violations without an
    extra join against clean_df (those rows were already promoted)."""
    if not dfs:
        return 0
    combined = dfs[0]
    for d in dfs[1:]:
        combined = combined.unionByName(d)
    return combined.distinct().count()


def promote_clean_records(spark, cleaned_catalog, cleaned_schema, table_name,
                          batch_df, fail_rowid_dfs, fail_hashkey_dfs):
    """Records in the batch that failed NO rule -> merged (insert-only) into
    {cleaned_catalog}.{cleaned_schema}.{table_name}.

    Exclusion is done with the failing keys captured IN-SESSION from each
    rule's violation DataFrame (no JSON round trip through dq_bad_records):
      - fail_rowid_dfs: DISTINCT _dq_row_id per rule (row-level rules run on
        the batch view, which carries the stamped row id)
      - fail_hashkey_dfs: DISTINCT cdw_hash_key per rule (custom rules that
        ran on the real table and therefore have no row id)"""
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {cleaned_catalog}.{cleaned_schema}")
    target = f"{cleaned_catalog}.{cleaned_schema}.{table_name}"

    clean_df = batch_df
    if fail_rowid_dfs:
        all_fail_ids = fail_rowid_dfs[0]
        for d in fail_rowid_dfs[1:]:
            all_fail_ids = all_fail_ids.unionByName(d)
        clean_df = clean_df.join(all_fail_ids.distinct(),
                                 on=ROW_ID_COLUMN, how="left_anti")
    if fail_hashkey_dfs and HASH_KEY_COLUMN in clean_df.columns:
        all_fail_keys = fail_hashkey_dfs[0]
        for d in fail_hashkey_dfs[1:]:
            all_fail_keys = all_fail_keys.unionByName(d)
        clean_df = clean_df.join(all_fail_keys.distinct(),
                                 on=HASH_KEY_COLUMN, how="left_anti")

    clean_df = clean_df.drop(ROW_ID_COLUMN)

    # Delta rejects column names containing ' ,;{}()\n\t=' — sanitize before
    # writing (rules still ran on the original names via backtick quoting)
    clean_df, renamed = sanitize_columns(clean_df)
    if renamed:
        print(f"  Renamed {len(renamed)} column(s) for Delta compatibility, "
              f"e.g. {dict(list(renamed.items())[:3])}")

    clean_count = clean_df.count()

    if spark.catalog.tableExists(target) and HASH_KEY_COLUMN in clean_df.columns:
        view = f"dq_clean_batch_{uuid.uuid4().hex[:8]}"
        clean_df.createOrReplaceTempView(view)
        spark.sql(f"""
            MERGE INTO {target} AS t
            USING {view} AS s
            ON t.{HASH_KEY_COLUMN} = s.{HASH_KEY_COLUMN}
            WHEN NOT MATCHED THEN INSERT *
        """)
        spark.catalog.dropTempView(view)
    else:
        clean_df.write.format("delta").mode("append") \
                .option("mergeSchema", "true").saveAsTable(target)

    return clean_count


# --------------------------------------------------------------------------- #
# Main executor                                                                #
# --------------------------------------------------------------------------- #
def execute_dq_checks(catalog_name, schema_name, config_catalog, config_schema,
                      result_catalog, result_schema, cleaned_catalog,
                      cleaned_schema, table_name=None, batch_timestamp=None,
                      job_run_id=None, compute_table_metrics=True,
                      compute_column_metrics=True, compute_kpi_metrics=True,
                      cast_columns_by_rules=True):
    """Runs DQ for every rule-bearing table in {catalog_name}.{schema_name}
    (or a single table when table_name is given)."""
    spark = get_spark_session()

    # --- required config/audit tables (pipeline_metadata intentionally absent)
    required_tables = [f"{config_catalog}.{config_schema}.dq_rules"]
    missing = []
    for t in required_tables:
        try:
            spark.read.table(t).limit(1).count()
        except Exception:
            missing.append(t)
    if missing:
        details = f"Missing tables: {', '.join(missing)}"
        dq_error_logs(spark, result_catalog, result_schema, None, None, None,
                      catalog_name, schema_name, table_name or "-", details,
                      batch_timestamp or datetime.now(timezone.utc))
        print(f"❌ {details}")
        return

    current_time = datetime.now(timezone.utc)
    batch_timestamp = fix_iso_timestamp(batch_timestamp) if isinstance(batch_timestamp, str) \
        else (batch_timestamp or current_time)
    job_run_id = job_run_id or f"m{int(current_time.timestamp())}"

    unique_rules, expanded_rules = fetch_rules(
        spark, config_catalog, config_schema, catalog_name, schema_name)

    if table_name:
        expanded_rules = [r for r in expanded_rules if r["table_name"] == table_name]

    tables = sorted({r["table_name"] for r in expanded_rules})
    print(f"Active unique rules found: {len(unique_rules)}")
    print(f"Rules after per-column expansion: {len(expanded_rules)}")
    print(f"Tables in scope: {tables}")

    run_summary = []

    for tbl in tables:
        table_rules = [r for r in expanded_rules if r["table_name"] == tbl]
        print(f"\n===== Processing `{catalog_name}`.`{schema_name}`.`{tbl}` "
              f"| rules: {len(table_rules)} =====")

        # ---- pipeline metadata enrichment (tolerant; NULLs if unregistered) --
        pl_key, pl_name, tbl_id = get_pipeline_info(
            spark, config_catalog, config_schema, catalog_name, schema_name, tbl)
        if pl_key is not None:
            for rule in table_rules:
                if rule.get("pipeline_key") in (None, "", "null"):
                    rule["pipeline_key"] = pl_key
        if pl_name:
            print(f"  Pipeline: {pl_name} (key={pl_key}, table_id={tbl_id})")

        # ---- table metrics (profiling + schema change + KPI history) ---------
        table_start_time = datetime.now(timezone.utc)
        if compute_table_metrics:
            try:
                calculate_dq_table_metrics(
                    spark, config_catalog, config_schema, result_catalog,
                    result_schema, catalog_name, schema_name, tbl, job_run_id,
                    table_start_time, batch_timestamp,
                    compute_column_metrics=compute_column_metrics,
                    compute_kpi_metrics=compute_kpi_metrics)
            except Exception as e:
                print(f"  ⚠️ Table metrics failed (continuing with DQ): {e}")

        # ---- incremental batch --------------------------------------------
        scratch_table = None
        try:
            batch_df, inc_mode = select_new_batch(
                spark, result_catalog, result_schema, cleaned_catalog,
                cleaned_schema, catalog_name, schema_name, tbl)
            # FIX: materialize (not just safe_cache, which is a no-op on
            # serverless) — batch_df's incremental selection is a left_anti
            # join against dq_bad_records, and rule execution writes NEW rows
            # into dq_bad_records as it runs. Without a real materialization,
            # every later action re-evaluates that join against the
            # now-mutated dq_bad_records and silently drops rows this run
            # itself just logged — including AUDIT_ONLY violations, which
            # are never supposed to be excluded. See materialize_batch().
            batch_df, scratch_table = materialize_batch(
                spark, batch_df, result_catalog, result_schema, tbl)
            batch_count = batch_df.count()
            print(f"  Incremental mode: {inc_mode}")
            print(f"  New records in this batch: {batch_count}")
        except Exception as e:
            for rule in table_rules:
                dq_error_logs(spark, result_catalog, result_schema,
                              rule["rule_id"], rule.get("pipeline_key"), None,
                              catalog_name, schema_name, tbl,
                              f"Batch selection error: {e}", batch_timestamp)
            print(f"  ❌ Could not read table / select batch: {e}")
            drop_batch_scratch_table(spark, scratch_table)
            continue

        if batch_count == 0:
            print("  Nothing new to validate — skipping (no duplicate audits).")
            safe_unpersist(batch_df)
            drop_batch_scratch_table(spark, scratch_table)
            continue

        # ---- rule-driven type casting (string bronze → typed) ----------------
        if cast_columns_by_rules:
            batch_df, cast_plan = apply_rule_based_casting(batch_df, table_rules)

        # ---- stamp a deterministic row id for exact clean/bad separation -----
        batch_df = batch_df.withColumn(ROW_ID_COLUMN,
                                       F.monotonically_increasing_id())
        # FIX: materialize again after stamping the row id, not just
        # safe_cache — monotonically_increasing_id() can be reassigned on
        # re-evaluation, and every rule's violation query plus the later
        # clean_df anti-join each re-evaluate this DataFrame independently.
        # Freezing it here guarantees the _dq_row_id a rule captures in
        # fail_rowid_dfs is the exact same id promote_clean_records sees.
        batch_df, id_scratch_table = materialize_batch(
            spark, batch_df, result_catalog, result_schema, f"{tbl}_ids")
        drop_batch_scratch_table(spark, scratch_table)
        scratch_table = id_scratch_table

        # Register the batch as a temp view; row-level rule queries run on it
        batch_view = f"dq_batch_{tbl}_{uuid.uuid4().hex[:8]}"
        batch_df.createOrReplaceTempView(batch_view)

        total = success = failure = 0
        severities, errored_severities, violation_ids = [], set(), []
        fail_rowid_dfs, fail_hashkey_dfs = [], []
        # Mirrors fail_rowid_dfs/fail_hashkey_dfs but for AUDIT_ONLY rules —
        # these rows are NOT excluded from Silver, but we still want an
        # accurate count of them for the status message (see below), since
        # `batch_count - clean_count` alone would hide them entirely.
        audit_only_rowid_dfs, audit_only_hashkey_dfs = [], []

        row_level_rules = [r for r in table_rules
                           if r["_ctype"] not in TABLE_LEVEL_TYPES]
        table_level_rules = [r for r in table_rules
                             if r["_ctype"] in TABLE_LEVEL_TYPES]

        # ---- table-level rules (sequential) --------------------------------
        for rule in table_level_rules:
            try:
                if rule["_ctype"] == "ROW_COUNT_TREND":
                    st = run_row_count_trend(spark, result_catalog, result_schema,
                                             rule, batch_count, batch_timestamp)
                    print(f"  [ROW_COUNT_TREND] {rule.get('column_name') or '-'} "
                          f"-> {st.upper()} (observed={batch_count})")
                else:  # KPI_CHECK — self-contained (both criteria styles)
                    st, viol = run_kpi_check(
                        spark, result_catalog, result_schema, rule,
                        catalog_name, schema_name, tbl, batch_timestamp,
                        rule.get("violation_threshold"))
                    if st == "Pass":
                        success += 1
                    else:
                        failure += 1
                    severities.append(rule.get("severity"))
                    print(f"  [KPI_CHECK] -> {st.upper()} "
                          f"({viol} metric violations)")
                total += 1
            except Exception as e:
                errored_severities.add(str(rule.get("severity") or "").upper())
                print(f"  ❌ [{rule['_ctype']}] ERROR: {e}")
                failure += 1

        # ---- row-level rules (threaded, same as original) -------------------
        with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
            futures = {}
            for rule in row_level_rules:
                try:
                    query = construct_query(
                        spark, result_catalog, result_schema,
                        rule.get("pipeline_key"), rule["rule_id"],
                        "", "", batch_view,                # run on the batch view
                        rule.get("column_name"), rule["condition_type"],
                        rule.get("condition_criteria"),
                        rule.get("condition_category"), batch_timestamp,
                        real_catalog=catalog_name, real_schema=schema_name,
                        real_table=tbl)
                    fut = executor.submit(
                        dq_logs, spark, result_catalog, result_schema,
                        rule["rule_id"], query, rule.get("pipeline_key"),
                        catalog_name, schema_name, tbl, rule.get("column_name"),
                        rule.get("condition_category"), rule["_ctype"],
                        rule.get("severity"), batch_timestamp,
                        rule.get("violation_threshold"))
                    futures[fut] = rule
                except Exception as e:
                    errored_severities.add(str(rule.get("severity") or "").upper())
                    print(f"  ❌ [{rule['_ctype']}] {rule.get('column_name')} "
                          f"-> construction ERROR: {e}")
                    failure += 1

            for fut in as_completed(futures):
                rule = futures[fut]
                try:
                    sc, fc, sev, vid, fkeys, fkey_col = fut.result()
                    success += sc
                    failure += fc
                    severities.append(sev)
                    if vid:
                        violation_ids.append(vid)
                    if fkeys is not None:
                        if is_blocking_rule(rule):
                            if fkey_col == ROW_ID_COLUMN:
                                fail_rowid_dfs.append(fkeys)
                            elif fkey_col == HASH_KEY_COLUMN:
                                fail_hashkey_dfs.append(fkeys)
                        else:
                            if fkey_col == ROW_ID_COLUMN:
                                audit_only_rowid_dfs.append(fkeys)
                            elif fkey_col == HASH_KEY_COLUMN:
                                audit_only_hashkey_dfs.append(fkeys)
                            print(f"  ℹ️ [{rule['_ctype']}] {rule.get('column_name') or '-'} "
                                  f"-> AUDIT_ONLY: violation logged to "
                                  f"dq_bad_records but NOT excluded from "
                                  f"{cleaned_catalog}.{cleaned_schema}.{tbl}.")
                    if sc == 0 and fc > 0 and vid is None:
                        # rule failed to EXECUTE (not just data failing)
                        errored_severities.add(str(rule.get("severity") or "").upper())
                    total += 1
                except Exception as e:
                    errored_severities.add(str(rule.get("severity") or "").upper())
                    print(f"  ❌ Exception in thread execution: {e}")
                    failure += 1

        # ---- promote clean records / hold back ------------------------------
        hold_back = bool(errored_severities & HOLD_BACK_SEVERITIES)
        outcome = "PROMOTED"
        clean_count = 0
        audit_only_count = 0
        try:
            if hold_back:
                outcome = "WITHHELD (rule errors)"
                print(f"  !! Rule execution errors at severity "
                      f"{sorted(errored_severities & HOLD_BACK_SEVERITIES)} — "
                      f"batch WITHHELD from {cleaned_catalog}.{cleaned_schema}."
                      f"{tbl}; records will be re-validated next run.")
            else:
                clean_count = promote_clean_records(
                    spark, cleaned_catalog, cleaned_schema, tbl, batch_df,
                    fail_rowid_dfs, fail_hashkey_dfs)
                # These rows are already counted in clean_count (promoted,
                # not excluded) - this is purely so the status message can
                # say "N audit-only violations" instead of reading as a
                # fully clean batch.
                audit_only_count = count_distinct_keys(
                    audit_only_rowid_dfs + audit_only_hashkey_dfs)
                if audit_only_count:
                    outcome = (f"PROMOTED ({audit_only_count} audit-only "
                               f"violation(s) logged, not filtered)")
                print(f"  Cleaned records merged into "
                      f"{cleaned_catalog}.{cleaned_schema}.{tbl} | "
                      f"batch={batch_count} clean={clean_count} "
                      f"filtered={batch_count - clean_count} "
                      f"audit_only={audit_only_count}")
        except Exception as e:
            outcome = "WRITE_FAILED"
            dq_error_logs(spark, result_catalog, result_schema, None, None, None,
                          catalog_name, schema_name, tbl,
                          f"Clean promotion error: {e}", batch_timestamp)
            print(f"  ❌ Failed writing cleaned data: {e}")
        finally:
            spark.catalog.dropTempView(batch_view)
            safe_unpersist(batch_df)
            drop_batch_scratch_table(spark, scratch_table)

        final_flag = "Failure" if "Critical" in severities or hold_back else "Success"
        if compute_table_metrics:
            update_metrics_flag(spark, result_catalog, result_schema,
                                catalog_name, schema_name, tbl, job_run_id,
                                final_flag)
        run_summary.append((tbl, batch_count, clean_count,
                            batch_count - clean_count if not hold_back else 0,
                            audit_only_count, total, final_flag, outcome))

        print(f"""
====================================================================================================
📊 DQ STATUS SUMMARY for {catalog_name}.{schema_name}.{tbl}
----------------------------------------------------------------------------------------------------
✅ TOTAL CHECKS: {total}   🟢 SUCCESS: {success}   🔴 FAILURE: {failure}   🏁 FLAG: {final_flag}
🧹 FILTERED (excluded from Silver): {batch_count - clean_count if not hold_back else 0}   ℹ️ AUDIT-ONLY (logged, kept in Silver): {audit_only_count}
📜 Logs: {result_catalog}.{result_schema}.dq_logs | Bad records: {result_catalog}.{result_schema}.dq_bad_records | Errors: {result_catalog}.{result_schema}.dq_error_logs
====================================================================================================""")

    # ---- run summary ---------------------------------------------------------
    print("\n================ RUN SUMMARY ================")
    print(f"Batch timestamp : {batch_timestamp}")
    print(f"Catalog.Schema  : {catalog_name}.{schema_name}")
    for (t, b, c, filtered, audit_only, n, flag, outcome) in run_summary:
        print(f"  {t:<30} batch={b:<10} clean={c:<10} filtered={filtered:<8} "
              f"audit_only={audit_only:<8} rules={n:<4} flag={flag:<8} {outcome}")
    return run_summary
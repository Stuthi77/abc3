# Databricks notebook source
# MAGIC %md
# MAGIC # LakeWatch DQ — Setup DDL
# MAGIC Creates all governance/audit tables in `cdw_dev.domain_config` and the
# MAGIC cleaned-data schema. Run once per environment.
# MAGIC (No `pipeline_metadata` and no `dq_table_metrics` — removed by design.)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS cdw_dev.domain_config;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS cdw_dev.ml_cleaned_datasets;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS cdw_dev.domain_config.dq_rules (
# MAGIC     rule_id STRING,
# MAGIC     pipeline_key STRING,
# MAGIC     catalog_name STRING NOT NULL,
# MAGIC     schema_name STRING NOT NULL,
# MAGIC     table_name STRING NOT NULL,
# MAGIC     column_name STRING,
# MAGIC     condition_category STRING,
# MAGIC     condition_type STRING NOT NULL,
# MAGIC     condition_criteria STRING,
# MAGIC     rule_description STRING,
# MAGIC     severity STRING,
# MAGIC     violation_threshold INT,
# MAGIC     created_at TIMESTAMP,
# MAGIC     updated_at TIMESTAMP,
# MAGIC     effective_date_from TIMESTAMP,
# MAGIC     effective_date_to TIMESTAMP,
# MAGIC     owner STRING
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS cdw_dev.domain_config.dq_logs (
# MAGIC     log_id STRING,
# MAGIC     rule_id STRING,
# MAGIC     pipeline_key STRING,
# MAGIC     catalog_name STRING NOT NULL,
# MAGIC     schema_name STRING NOT NULL,
# MAGIC     table_name STRING NOT NULL,
# MAGIC     column_name STRING,
# MAGIC     condition_category STRING,
# MAGIC     condition_type STRING,
# MAGIC     status STRING,
# MAGIC     violation_count INT,
# MAGIC     violation_id STRING,
# MAGIC     severity STRING,
# MAGIC     batch_timestamp TIMESTAMP
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS cdw_dev.domain_config.dq_bad_records (
# MAGIC     br_id STRING,
# MAGIC     violation_id STRING,
# MAGIC     pipeline_key STRING,
# MAGIC     catalog_name STRING NOT NULL,
# MAGIC     schema_name STRING NOT NULL,
# MAGIC     table_name STRING NOT NULL,
# MAGIC     bad_record_data STRING,
# MAGIC     batch_timestamp TIMESTAMP
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS cdw_dev.domain_config.dq_error_logs (
# MAGIC     error_id STRING,
# MAGIC     rule_id STRING,
# MAGIC     pipeline_key STRING,
# MAGIC     violation_id STRING,
# MAGIC     catalog_name STRING NOT NULL,
# MAGIC     schema_name STRING NOT NULL,
# MAGIC     table_name STRING NOT NULL,
# MAGIC     error_details STRING,
# MAGIC     batch_timestamp TIMESTAMP
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Tracks which alert emails were sent (prevents duplicate alerts per day)
# MAGIC CREATE TABLE IF NOT EXISTS cdw_dev.domain_config.dq_alerts (
# MAGIC     alert_id STRING,
# MAGIC     catalog_name STRING,
# MAGIC     schema_name STRING,
# MAGIC     email STRING,
# MAGIC     batch_timestamp TIMESTAMP,
# MAGIC     date_sent DATE
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Pipeline metadata: maps pipelines to their tables (restored per request)
# MAGIC CREATE TABLE IF NOT EXISTS cdw_dev.domain_config.dq_pipeline_metadata (
# MAGIC     pipeline_key STRING,
# MAGIC     pipeline_name STRING,
# MAGIC     table_id BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 101 INCREMENT BY 1),
# MAGIC     catalog_name STRING NOT NULL,
# MAGIC     schema_name STRING NOT NULL,
# MAGIC     table_name STRING NOT NULL,
# MAGIC     batch_timestamp TIMESTAMP
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Example pipeline registrations (edit to your pipelines/tables)
# MAGIC -- INSERT INTO cdw_dev.domain_config.dq_pipeline_metadata
# MAGIC -- (pipeline_key, pipeline_name, catalog_name, schema_name, table_name, batch_timestamp)
# MAGIC -- VALUES
# MAGIC -- ('2001', 'ASAP Ingestion', 'cdw_dev', 'asap', '0customer_text', current_timestamp()),
# MAGIC -- ('2001', 'ASAP Ingestion', 'cdw_dev', 'asap', 'adr6', current_timestamp());

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Table metrics: profiling, schema-change detection, KPI history, run flag
# MAGIC CREATE TABLE IF NOT EXISTS cdw_dev.domain_config.dq_table_metrics (
# MAGIC     pipeline_key STRING,
# MAGIC     pipeline_name STRING,
# MAGIC     table_id BIGINT,
# MAGIC     catalog STRING,
# MAGIC     schema STRING,
# MAGIC     table_name STRING,
# MAGIC     metric_level STRING,              -- TABLE | COLUMN | KPI
# MAGIC     process_start_time TIMESTAMP,
# MAGIC     process_end_time TIMESTAMP,
# MAGIC     execution_duration_sec DOUBLE,
# MAGIC     row_count BIGINT,
# MAGIC     duplicate_rows BIGINT,
# MAGIC     column_name STRING,
# MAGIC     distinct_count BIGINT,
# MAGIC     null_count BIGINT,
# MAGIC     null_percentage DOUBLE,
# MAGIC     schema_change STRING,
# MAGIC     job_run_id STRING,
# MAGIC     batch_timestamp TIMESTAMP,
# MAGIC     kpi_metric_value STRING,
# MAGIC     flag STRING                        -- Success | Failure (set after DQ run)
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- For EXISTING dq_bad_records installations: add requeue-tracking columns.
# MAGIC -- (New installs: these columns are included in the CREATE above via ALTER.)
# MAGIC ALTER TABLE cdw_dev.domain_config.dq_bad_records
# MAGIC   ADD COLUMNS (reprocess_status STRING, reprocessed_at TIMESTAMP);

# COMMAND ----------

# Databricks notebook source
# MAGIC %md
# MAGIC # LakeWatch DQ — Setup DDL
# MAGIC Creates all governance/audit tables in `cdw_dev.domain_config` and the
# MAGIC cleaned-data schema. Run once per environment.
# MAGIC (No `pipeline_metadata` and no `dq_table_metrics` — removed by design.)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS cdw_dev.domain_config;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS cdw_dev.ml_cleaned_datasets;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS cdw_dev.domain_config.dq_rules (
# MAGIC     rule_id STRING,
# MAGIC     pipeline_key STRING,
# MAGIC     catalog_name STRING NOT NULL,
# MAGIC     schema_name STRING NOT NULL,
# MAGIC     table_name STRING NOT NULL,
# MAGIC     column_name STRING,
# MAGIC     condition_category STRING,
# MAGIC     condition_type STRING NOT NULL,
# MAGIC     condition_criteria STRING,
# MAGIC     rule_description STRING,
# MAGIC     severity STRING,
# MAGIC     violation_threshold INT,
# MAGIC     created_at TIMESTAMP,
# MAGIC     updated_at TIMESTAMP,
# MAGIC     effective_date_from TIMESTAMP,
# MAGIC     effective_date_to TIMESTAMP,
# MAGIC     owner STRING,
# MAGIC     enforcement_action STRING,
# MAGIC     email_alert_enabled BOOLEAN,
# MAGIC     alert_group_id STRING
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS cdw_dev.domain_config.dq_logs (
# MAGIC     log_id STRING,
# MAGIC     rule_id STRING,
# MAGIC     pipeline_key STRING,
# MAGIC     catalog_name STRING NOT NULL,
# MAGIC     schema_name STRING NOT NULL,
# MAGIC     table_name STRING NOT NULL,
# MAGIC     column_name STRING,
# MAGIC     condition_category STRING,
# MAGIC     condition_type STRING,
# MAGIC     status STRING,
# MAGIC     violation_count INT,
# MAGIC     violation_id STRING,
# MAGIC     severity STRING,
# MAGIC     batch_timestamp TIMESTAMP
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS cdw_dev.domain_config.dq_bad_records (
# MAGIC     br_id STRING,
# MAGIC     violation_id STRING,
# MAGIC     pipeline_key STRING,
# MAGIC     catalog_name STRING NOT NULL,
# MAGIC     schema_name STRING NOT NULL,
# MAGIC     table_name STRING NOT NULL,
# MAGIC     bad_record_data STRING,
# MAGIC     batch_timestamp TIMESTAMP
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS cdw_dev.domain_config.dq_error_logs (
# MAGIC     error_id STRING,
# MAGIC     rule_id STRING,
# MAGIC     pipeline_key STRING,
# MAGIC     violation_id STRING,
# MAGIC     catalog_name STRING NOT NULL,
# MAGIC     schema_name STRING NOT NULL,
# MAGIC     table_name STRING NOT NULL,
# MAGIC     error_details STRING,
# MAGIC     batch_timestamp TIMESTAMP
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Tracks which alert emails were sent (prevents duplicate alerts per day)
# MAGIC CREATE TABLE IF NOT EXISTS cdw_dev.domain_config.dq_alerts (
# MAGIC     alert_id STRING,
# MAGIC     catalog_name STRING,
# MAGIC     schema_name STRING,
# MAGIC     email STRING,
# MAGIC     batch_timestamp TIMESTAMP,
# MAGIC     date_sent DATE
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Pipeline metadata: maps pipelines to their tables (restored per request)
# MAGIC CREATE TABLE IF NOT EXISTS cdw_dev.domain_config.dq_pipeline_metadata (
# MAGIC     pipeline_key STRING,
# MAGIC     pipeline_name STRING,
# MAGIC     table_id BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 101 INCREMENT BY 1),
# MAGIC     catalog_name STRING NOT NULL,
# MAGIC     schema_name STRING NOT NULL,
# MAGIC     table_name STRING NOT NULL,
# MAGIC     batch_timestamp TIMESTAMP
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Example pipeline registrations (edit to your pipelines/tables)
# MAGIC -- INSERT INTO cdw_dev.domain_config.dq_pipeline_metadata
# MAGIC -- (pipeline_key, pipeline_name, catalog_name, schema_name, table_name, batch_timestamp)
# MAGIC -- VALUES
# MAGIC -- ('2001', 'ASAP Ingestion', 'cdw_dev', 'asap', '0customer_text', current_timestamp()),
# MAGIC -- ('2001', 'ASAP Ingestion', 'cdw_dev', 'asap', 'adr6', current_timestamp());

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Table metrics: profiling, schema-change detection, KPI history, run flag
# MAGIC CREATE TABLE IF NOT EXISTS cdw_dev.domain_config.dq_table_metrics (
# MAGIC     pipeline_key STRING,
# MAGIC     pipeline_name STRING,
# MAGIC     table_id BIGINT,
# MAGIC     catalog STRING,
# MAGIC     schema STRING,
# MAGIC     table_name STRING,
# MAGIC     metric_level STRING,              -- TABLE | COLUMN | KPI
# MAGIC     process_start_time TIMESTAMP,
# MAGIC     process_end_time TIMESTAMP,
# MAGIC     execution_duration_sec DOUBLE,
# MAGIC     row_count BIGINT,
# MAGIC     duplicate_rows BIGINT,
# MAGIC     column_name STRING,
# MAGIC     distinct_count BIGINT,
# MAGIC     null_count BIGINT,
# MAGIC     null_percentage DOUBLE,
# MAGIC     schema_change STRING,
# MAGIC     job_run_id STRING,
# MAGIC     batch_timestamp TIMESTAMP,
# MAGIC     kpi_metric_value STRING,
# MAGIC     flag STRING                        -- Success | Failure (set after DQ run)
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- For EXISTING dq_bad_records installations: add requeue-tracking columns.
# MAGIC -- (New installs: these columns are included in the CREATE above via ALTER.)
# MAGIC ALTER TABLE cdw_dev.domain_config.dq_bad_records
# MAGIC   ADD COLUMNS (reprocess_status STRING, reprocessed_at TIMESTAMP);

# COMMAND ----------

# MAGIC %sql
# MAGIC -- -----------------------------------------------------------------------
# MAGIC -- Migration: add columns introduced by the enforcement_action and
# MAGIC -- email alert features.
# MAGIC -- Run these ALTER TABLE statements once on any EXISTING installation
# MAGIC -- (tables created after this update already have the columns above).
# MAGIC -- -----------------------------------------------------------------------
# MAGIC
# MAGIC -- Controls whether bad records that fail this rule are:
# MAGIC --   BLOCK_AND_AUDIT (default): excluded from Silver AND written to dq_bad_records
# MAGIC --   AUDIT_ONLY:                kept in Silver but still written to dq_bad_records
# MAGIC ALTER TABLE cdw_dev.domain_config.dq_rules
# MAGIC   ADD COLUMN IF NOT EXISTS enforcement_action STRING;
# MAGIC
# MAGIC -- Per-rule email alert toggle.
# MAGIC -- false  = rule violations are NOT included in alert emails.
# MAGIC -- true / NULL (default) = rule violations ARE included in alert emails.
# MAGIC ALTER TABLE cdw_dev.domain_config.dq_rules
# MAGIC   ADD COLUMN IF NOT EXISTS email_alert_enabled BOOLEAN;
# MAGIC
# MAGIC -- Optional per-rule override for which group receives the alert email.
# MAGIC -- NULL = use the table's own group (dq_tables.group_id).
# MAGIC ALTER TABLE cdw_dev.domain_config.dq_rules
# MAGIC   ADD COLUMN IF NOT EXISTS alert_group_id STRING;
# MAGIC
# MAGIC -- Same three columns on the management side (dq_rule_requests lives in
# MAGIC -- the dqrules management app but may share the same catalog/schema).
# MAGIC ALTER TABLE cdw_dev.domain_config.dq_rule_requests
# MAGIC   ADD COLUMN IF NOT EXISTS enforcement_action STRING;
# MAGIC
# MAGIC ALTER TABLE cdw_dev.domain_config.dq_rule_requests
# MAGIC   ADD COLUMN IF NOT EXISTS email_alert_enabled BOOLEAN;
# MAGIC
# MAGIC ALTER TABLE cdw_dev.domain_config.dq_rule_requests
# MAGIC   ADD COLUMN IF NOT EXISTS alert_group_id STRING;
# MAGIC
# MAGIC -- Optional: backfill so existing rules show "Alert on" instead of NULL
# MAGIC -- UPDATE cdw_dev.domain_config.dq_rules
# MAGIC --   SET email_alert_enabled = true
# MAGIC --   WHERE email_alert_enabled IS NULL;
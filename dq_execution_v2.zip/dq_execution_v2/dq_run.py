# Databricks notebook source
# MAGIC %md
# MAGIC # LakeWatch DQ Run
# MAGIC Entry point mirroring the original `dq_run.py`, adapted to:
# MAGIC - take **catalog_name / schema_name** as widgets (config.yaml as fallback)
# MAGIC - run for **all tables** in the schema that have active rules
# MAGIC - promote records passing all row-level rules into
# MAGIC   `ml_cleaned_datasets.<table>` (insert-only MERGE on `cdw_hash_key`)

# COMMAND ----------

import sys, os

# Point this at wherever the dq_framework folder is deployed in your workspace
FRAMEWORK_PATH = os.path.join(os.path.dirname(
    os.path.abspath("__file__")), "dq_framework")
sys.path.append(FRAMEWORK_PATH)
# If running from a fixed workspace path instead, use e.g.:
# sys.path.append("/Workspace/Users/<you>/data_observability_framework/dq_framework")

import yaml
from datetime import datetime, timezone
from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("DataQualityChecksApp") \
    .enableHiveSupport() \
    .getOrCreate()

# COMMAND ----------

import yaml
import datetime
from datetime import timezone
from dq_executor import execute_dq_checks

# 1. Load YAML config
with open("config.yaml", "r") as file:
    config = yaml.safe_load(file)

# 2. Define all widgets
dbutils.widgets.text("source_id",        config.get("source_id", ""))
dbutils.widgets.text("source_object_id", "NONE")   # comma-separated IDs or NONE = all active
dbutils.widgets.text("DateProcessed",    "")       # e.g. 20240715093000; passed from ADF
dbutils.widgets.text("JobId",            "")
dbutils.widgets.text("Pipelinename",     "")
dbutils.widgets.text("max_workers",      "8")
dbutils.widgets.text("bronze_schema",    "bronze") 
dbutils.widgets.text("silver_schema",    "silver") 
dbutils.widgets.text("target_catalog",   config.get("target_catalog", ""))
dbutils.widgets.text("target_schema",    config.get("target_schema", ""))

# COMMAND ----------

# DBTITLE 1,Cell 4
import datetime

# 1. Retrieve widget values
SOURCE_ID        = dbutils.widgets.get("source_id").strip()
SOURCE_OBJECT_ID = dbutils.widgets.get("source_object_id").strip()
DATE_PROCESSED   = dbutils.widgets.get("DateProcessed").strip() or None
JOB_ID           = dbutils.widgets.get("JobId")
PIPELINE_NAME    = dbutils.widgets.get("Pipelinename")
MAX_WORKERS      = int(dbutils.widgets.get("max_workers") or "8")
BRONZE_SCHEMA    = dbutils.widgets.get("bronze_schema").strip()
SILVER_SCHEMA    = dbutils.widgets.get("silver_schema").strip()

target_catalog = dbutils.widgets.get("target_catalog").strip()
target_schema  = dbutils.widgets.get("target_schema").strip()

if not SOURCE_ID:
    dbutils.notebook.exit("No source_id received — nothing to process.")

# 2. Calculate Date Bounds
SILVER_START_TIME = datetime.datetime.now()
BRONZE_RUN_START = (
    datetime.datetime.strptime(DATE_PROCESSED, "%Y%m%d%H%M%S")
    if DATE_PROCESSED
    else SILVER_START_TIME.replace(minute=0, second=0, microsecond=0)
)

# 3. Parse source_object_id 
source_obj_ids = (
    [x.strip() for x in SOURCE_OBJECT_ID.split(",") if x.strip().isdigit()]
    if SOURCE_OBJECT_ID.upper() not in ("NONE", "")
    else []
)

print(f"source_id        = {SOURCE_ID}")
print(f"source_object_id = {SOURCE_OBJECT_ID}")
print(f"DateProcessed    = {DATE_PROCESSED}")
print(f"bronze_run_start = {BRONZE_RUN_START}")
print(f"silver_start     = {SILVER_START_TIME}")
print(f"objects          = {'ALL active' if not source_obj_ids else source_obj_ids}")

# COMMAND ----------

# 1. Build Query
obj_filter = f"AND v.object_id IN ({','.join(source_obj_ids)})" if source_obj_ids else ""
date_expr  = f"'{DATE_PROCESSED}'" if DATE_PROCESSED else "CAST(NULL AS STRING)"

configs_query = f"""
    SELECT
        v.object_id, v.source_id, v.source_name, v.schema_name, v.object_name,
        v.key_columns, v.load_type, v.is_active,
        get_json_object(v.delete_config, '$.delete_column')  AS delete_column,
        get_json_object(v.delete_config, '$.delete_value')   AS delete_value,
        get_json_object(v.delete_config, '$.delete_mode')    AS delete_mode,
        CAST(get_json_object(v.scoped_config, '$.scoped_mode') AS BOOLEAN) AS scoped_mode,
        get_json_object(v.scoped_config, '$.scoped_mode_column_name') AS scoped_mode_column_name,
        v.domain_catalog                                     AS domain_catalog,
        '{BRONZE_SCHEMA}'                                    AS bronze_schema,
        v.governance_table_name                              AS target_table,
        {date_expr}                                          AS date_processed,
        get_json_object(so.ConfigJson, '$.silver_required_columns') AS required_columns
    FROM prod_platform.config.vw_source_object_config v
    LEFT JOIN prod_platform.config.sourceobject so ON v.object_id = so.ID
    WHERE v.source_id = '{SOURCE_ID}'
      {obj_filter}
"""

# 2. Execute Query
configs = spark.sql(configs_query).collect()

if not configs:
    raise Exception(f"No active rows found in config for source_id={SOURCE_ID}, source_object_id={SOURCE_OBJECT_ID}.")

# 3. Create List of Tables to Process Downstream
tables_to_process = []
for row in configs:
    tables_to_process.append({
        "catalog_name": row["domain_catalog"],
        "table_name": row["target_table"],
        "schema_name": BRONZE_SCHEMA
    })

print(f"Resolved {len(tables_to_process)} object(s) queued for DQ:")
for t in tables_to_process:
    print(f" -> {t['catalog_name']}.{t['schema_name']}.{t['table_name']}")

# COMMAND ----------

import datetime
# 1. Load DQ configuration metrics
config_catalog  = config.get("config_catalog", "dev_platform")
config_schema   = config.get("config_schema", "data_quality_config")
result_catalog  = config.get("result_catalog", "dev_platform")
result_schema   = config.get("result_schema", "data_quality_config")
cleaned_catalog = config.get("cleaned_catalog", "dev_data_quality")
cleaned_schema  = config.get("cleaned_schema", "bronze")

compute_table_metrics  = bool(config.get("compute_table_metrics", True))
compute_column_metrics = bool(config.get("compute_column_metrics", True))
compute_kpi_metrics    = bool(config.get("compute_kpi_metrics", True))

# 2. Get Job Run ID & Batch Timestamp
batch_timestamp = datetime.datetime.now(timezone.utc)
try:
    job_run_id = dbutils.notebook.entry_point.getDbutils().notebook().getContext().currentRunId().toString()
except Exception:
    job_run_id = f"manual_{int(batch_timestamp.timestamp())}"

print(f"Batch Timestamp: {batch_timestamp.isoformat()}")
print(f"Job Run ID: {job_run_id}")
print(f"Compute Table Metrics: {compute_table_metrics}")
print(f"Compute Column Metrics: {compute_column_metrics}")
print(f"Compute KPI Metrics: {compute_kpi_metrics}")
print(f"Config Catalog: {config_catalog}")
print(f"Config Schema: {config_schema}")
print(f"Audit Catalog: {result_catalog}")
print(f"Audit Schema: {result_schema}")

# COMMAND ----------

# DBTITLE 1,About: CDF Setup & Post-DQ Hard-Delete Cleanup
# MAGIC %md
# MAGIC ## CDF Setup & Post-DQ Hard-Delete Cleanup
# MAGIC
# MAGIC ### Cell 8 — Pre-Step: Enable CDF on dev_data_quality tables
# MAGIC Ensures `delta.enableChangeDataFeed = true` on every `dev_data_quality` table. Idempotent.
# MAGIC
# MAGIC ### Cell 10 — Post-Step: Read Bronze CDF → Delete HARD rows from dev_data_quality
# MAGIC After DQ rules run and clean rows are promoted to `dev_data_quality`, this step reads **Bronze CDF** for the run window, identifies keys whose latest state is `delete_mode = 'HARD'`, and deletes them from `dev_data_quality`. Since CDF is enabled, these deletes are tracked — the Silver notebook reads this CDF to propagate deletes to Silver.
# MAGIC
# MAGIC ### End-to-End Flow
# MAGIC
# MAGIC ```
# MAGIC Cell 8   Enable CDF on dev_data_quality tables
# MAGIC             │
# MAGIC Cell 9   DQ rules run  ──>  clean rows written to dev_data_quality (with CDF tracking)
# MAGIC             │
# MAGIC Cell 10  Read Bronze CDF  ──>  delete HARD keys from dev_data_quality
# MAGIC             │                   (delete events recorded in dev_data_quality CDF)
# MAGIC             │
# MAGIC          Silver notebook reads dev_data_quality CDF  ──>  deletes matching keys from Silver
# MAGIC ```

# COMMAND ----------

# DBTITLE 1,Pre-Step: Enable CDF on dev_data_quality tables
# ---------------------------------------------------------------------------
# Pre-Step: Enable CDF on dev_data_quality tables
#
# Ensures delta.enableChangeDataFeed = true on every dev_data_quality table
# that this pipeline writes to. This is idempotent — safe to run every time.
#
# Why: The Silver notebook reads dev_data_quality CDF to detect hard-delete
# events and propagate them to Silver. Without CDF enabled here, Silver
# cannot see what changed in the DQ layer.
# ---------------------------------------------------------------------------

def _ensure_cdf_enabled(cleaned_catalog, cleaned_schema, table_name):
    """Enable CDF on a single dev_data_quality table if it exists."""
    dq_table = f"{cleaned_catalog}.{cleaned_schema}.{table_name}"
    if not spark.catalog.tableExists(dq_table):
        print(f"  [{table_name}] Table not found yet: {dq_table} — will be created by DQ with CDF")
        return {"table": dq_table, "status": "not_found"}

    try:
        props = spark.sql(f"SHOW TBLPROPERTIES {dq_table}").collect()
        cdf_on = any(
            r["key"] == "delta.enableChangeDataFeed" and r["value"].lower() == "true"
            for r in props
        )
        if cdf_on:
            print(f"  [{table_name}] CDF already enabled on {dq_table}")
            return {"table": dq_table, "status": "already_enabled"}

        spark.sql(f"""
            ALTER TABLE {dq_table}
            SET TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
        """)
        print(f"  [{table_name}] CDF enabled on {dq_table}")
        return {"table": dq_table, "status": "enabled"}

    except Exception as e:
        print(f"  [{table_name}] WARN — could not enable CDF on {dq_table}: {e}")
        return {"table": dq_table, "status": "error", "error": str(e)}


# --- Enable CDF on all DQ tables in this run ---
print(f"Pre-Step: Enabling CDF on {len(tables_to_process)} dev_data_quality table(s)\n")

cdf_enable_results = []
for t in tables_to_process:
    res = _ensure_cdf_enabled(cleaned_catalog, cleaned_schema, t["table_name"])
    cdf_enable_results.append(res)

# Summary
enabled   = sum(1 for r in cdf_enable_results if r["status"] == "enabled")
already   = sum(1 for r in cdf_enable_results if r["status"] == "already_enabled")
not_found = sum(1 for r in cdf_enable_results if r["status"] == "not_found")
errors    = sum(1 for r in cdf_enable_results if r["status"] == "error")

print(f"\nPre-Step complete  |  newly enabled={enabled}  already on={already}  "
      f"not found={not_found}  errors={errors}")

# COMMAND ----------

import yaml
from datetime import datetime, timezone
from dq_executor import execute_dq_checks
# Step 5: Execute DQ checks for every rule-bearing table dynamically
print("\n🚀 Starting Data Quality Execution...")
run_summaries = []

for table_info in tables_to_process:
    current_catalog = table_info["catalog_name"]
    current_schema = table_info["schema_name"]
    current_table = table_info["table_name"]
    
    print(f"\n⚙️ Executing DQ checks for: {current_catalog}.{current_schema}.{current_table}")
    
    try:
        run_summary = execute_dq_checks(
            catalog_name=current_catalog,
            schema_name=current_schema,
            config_catalog=config_catalog,
            config_schema=config_schema,
            result_catalog=result_catalog,
            result_schema=result_schema,
            cleaned_catalog=cleaned_catalog,
            cleaned_schema=cleaned_schema,
            table_name=current_table,
            batch_timestamp=batch_timestamp,
            job_run_id=job_run_id,
            compute_table_metrics=compute_table_metrics,
            compute_column_metrics=compute_column_metrics,
            compute_kpi_metrics=compute_kpi_metrics,
        )
        
        # Store summary in case you need to evaluate overall run status later
        run_summaries.append({
            "table": current_table,
            "summary": run_summary,
            "status": "SUCCESS"
        })
        print(f"✅ Successfully completed DQ checks for: {current_table}")
        
    except Exception as e:
        print(f"❌ Failed DQ checks for {current_table}. Error: {str(e)}")
        run_summaries.append({
            "table": current_table,
            "error": str(e),
            "status": "FAILED"
        })
        # Note: You can add `raise e` here if you want the whole pipeline to fail on a single table error

print("\n🏁 Data Quality Execution Completed for all tables.")

# COMMAND ----------

# DBTITLE 1,Post-Step: Read Bronze CDF and Delete HARD rows from dev_data_quality
# ---------------------------------------------------------------------------
# Post-Step: Read Bronze CDF → Delete HARD rows from dev_data_quality
#
# Runs AFTER DQ checks (Cell 9) have promoted clean rows to dev_data_quality.
# Reads Bronze CDF for the current run window, finds keys whose latest state
# is delete_mode='HARD', and deletes them from dev_data_quality.
#
# Because CDF is enabled on dev_data_quality (Cell 8), these deletes are
# recorded in DQ's CDF. The Silver notebook reads that CDF to propagate
# the deletes to Silver — no need for Silver to touch Bronze CDF at all.
# ---------------------------------------------------------------------------
from pyspark.sql.functions import col, upper as _upper, row_number, desc
from pyspark.sql.window import Window
from delta.tables import DeltaTable


def _cdf_hard_delete_from_dq(cfg, bronze_run_start, silver_start_time,
                              cleaned_catalog, cleaned_schema):
    """Read Bronze CDF for one table, find HARD-delete keys, delete from DQ."""
    obj_name     = cfg.object_name
    domain_cat   = cfg.domain_catalog
    bronze_table = f"{domain_cat}.{cfg.bronze_schema}.{cfg.target_table}"
    dq_table     = f"{cleaned_catalog}.{cleaned_schema}.{cfg.target_table}"

    key_cols = [k.strip() for k in (cfg.key_columns or "").split(",") if k.strip()]
    if not key_cols:
        print(f"  [{obj_name}] SKIP — no key_columns configured")
        return {"object": obj_name, "status": "Skipped", "reason": "no key_columns",
                "dq_deleted": 0}

    # --- Read Bronze CDF for this run window ---
    try:
        cdf = (spark.read.format("delta")
               .option("readChangeFeed", "true")
               .option("startingTimestamp", bronze_run_start.strftime("%Y-%m-%d %H:%M:%S"))
               .option("endingTimestamp",   silver_start_time.strftime("%Y-%m-%d %H:%M:%S"))
               .table(bronze_table))
    except Exception as e:
        print(f"  [{obj_name}] SKIP — Bronze CDF unavailable: {e}")
        return {"object": obj_name, "status": "Skipped", "reason": f"CDF unavailable: {e}",
                "dq_deleted": 0}

    changed = cdf.filter(col("_change_type") == "update_postimage")
    if "delete_mode" not in changed.columns:
        print(f"  [{obj_name}] SKIP — no delete_mode column in Bronze CDF")
        return {"object": obj_name, "status": "Skipped", "reason": "no delete_mode col",
                "dq_deleted": 0}

    missing_keys = [k for k in key_cols if k not in changed.columns]
    if missing_keys:
        print(f"  [{obj_name}] SKIP — key column(s) missing from CDF: {missing_keys}")
        return {"object": obj_name, "status": "Skipped", "reason": f"missing keys: {missing_keys}",
                "dq_deleted": 0}

    # Latest commit per key in this window; keep only keys whose final state is HARD
    w = Window.partitionBy(*key_cols).orderBy(desc("_commit_version"))
    hard_keys = (changed
                 .withColumn("_rn", row_number().over(w))
                 .filter(col("_rn") == 1)
                 .filter(_upper(col("delete_mode")) == "HARD")
                 .select(*key_cols)
                 .dropDuplicates(key_cols))

    delete_count = hard_keys.count()
    if delete_count == 0:
        print(f"  [{obj_name}] No HARD-delete keys in this window")
        return {"object": obj_name, "status": "OK", "reason": "0 HARD keys",
                "dq_deleted": 0}

    # --- Delete HARD keys from dev_data_quality ---
    dq_del = 0
    if spark.catalog.tableExists(dq_table):
        try:
            match_cond = " AND ".join(f"target.`{k}` = source.`{k}`" for k in key_cols)
            (DeltaTable.forName(spark, dq_table).alias("target")
             .merge(hard_keys.alias("source"), match_cond)
             .whenMatchedDelete()
             .execute())
            dq_del = delete_count
            print(f"  [{obj_name}] Deleted {delete_count} HARD key(s) from DQ: {dq_table}")
        except Exception as e:
            print(f"  [{obj_name}] WARN — DQ delete failed ({dq_table}): {e}")
    else:
        print(f"  [{obj_name}] DQ table not found: {dq_table} — skipping")

    return {"object": obj_name, "status": "OK", "reason": f"{delete_count} HARD keys",
            "dq_deleted": dq_del}


# --- Run for all HARD-delete-configured objects ---
hard_configs = [c for c in configs if str(c.delete_mode or "").upper() == "HARD"]

if hard_configs:
    print(f"Post-Step: Bronze CDF Hard-Delete Cleanup — {len(hard_configs)} object(s)\n")
    cdf_results = []
    for cfg in hard_configs:
        res = _cdf_hard_delete_from_dq(cfg, BRONZE_RUN_START, SILVER_START_TIME,
                                        cleaned_catalog, cleaned_schema)
        cdf_results.append(res)

    total_dq = sum(r["dq_deleted"] for r in cdf_results)
    print(f"\nPost-Step complete  |  DQ rows deleted={total_dq}")
else:
    print("Post-Step: No HARD-delete objects configured — skipping CDF cleanup.")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM dev_platform.data_quality_config.dq_logs
# MAGIC ORDER BY batch_timestamp DESC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM dev_platform.data_quality_config.dq_error_logs
# MAGIC ORDER BY batch_timestamp DESC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM dev_platform.data_quality_config.dq_bad_records
# MAGIC ORDER BY batch_timestamp DESC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_platform.data_quality_config.dq_table_metrics

# COMMAND ----------

for table_info in tables_to_process:
    current_catalog = table_info["catalog_name"]
    current_schema = table_info["schema_name"]
    current_table = table_info["table_name"]
    try:
        print(f"✅ Successfully completed DQ checks for: {current_table}")
        
        # 2. Trigger Email Alert Notebook
        print(f"📧 Triggering email alert notebook for: {current_table}...")
        dbutils.notebook.run(
            "/Workspace/Users/danduprolu.stuthi@latentview.com/dq_execution_v2/dq_framework/email_alert",
            timeout_seconds=1800,
            arguments={
                "catalog_name": current_catalog, 
                "schema_name": current_schema,
                "table_name": current_table,
                "lookback_hours": "24", 
                "dry_run": "false"
            }
        )
        print(f"✅ Email alert executed for: {current_table}")
        
    except Exception as e:
        print(f"❌ Failed processing for {current_table}. Error: {str(e)}")
        run_summaries.append({
            "table": current_table,
            "error": str(e),
            "status": "FAILED"
        })
# Databricks notebook source
# MAGIC %md
# MAGIC # LakeWatch DQ — Remediation / Requeue
# MAGIC
# MAGIC Re-validates quarantined records from `dq_bad_records` against the
# MAGIC **current** approved rules in `dq_rules`.  Use this after:
# MAGIC - Fixing a rule that was too strict (editing via the management UI and
# MAGIC   getting the UPDATE approved), or
# MAGIC - Disabling / deleting a rule that was incorrectly quarantining good data.
# MAGIC
# MAGIC ## What it does
# MAGIC For every bad record in scope:
# MAGIC 1. Reconstruct the original row from `bad_record_data` (stored as JSON).
# MAGIC 2. Re-apply every **current active rule** for that table.
# MAGIC 3. If the row now passes all blocking rules it is:
# MAGIC    - Merged (INSERT-only MERGE) into `cdw_dev.ml_cleaned_datasets.<table>`.
# MAGIC    - Marked `reprocess_status = 'REPROMOTED'` and `reprocessed_at = now()`
# MAGIC      in `dq_bad_records` (the original audit row is kept; only the status
# MAGIC      columns are updated — the bad-record history is never deleted).
# MAGIC    - Written as a new `REQUEUE` entry in `dq_logs`.
# MAGIC 4. Rows that still fail at least one blocking rule are left in
# MAGIC    `dq_bad_records` unchanged (`reprocess_status = 'STILL_FAILING'`).
# MAGIC 5. Rows that pass all rules but fail at least one `AUDIT_ONLY` rule are
# MAGIC    promoted but their `AUDIT_ONLY` violation is re-logged.
# MAGIC
# MAGIC ## enforcement_action awareness
# MAGIC Identical to `dq_executor.py`:
# MAGIC - `BLOCK_AND_AUDIT` (or NULL/unrecognised): a violation **blocks** promotion.
# MAGIC - `AUDIT_ONLY`: a violation is **logged** but the row is still promoted.
# MAGIC
# MAGIC ## Filters (widgets)
# MAGIC | Widget | Effect |
# MAGIC |---|---|
# MAGIC | `catalog_name` | Scope to one catalog (required) |
# MAGIC | `schema_name` | Scope to one schema (required) |
# MAGIC | `table_name` | Scope to one table; blank = all tables in the schema |
# MAGIC | `rule_id` | Scope to records quarantined by one specific rule |
# MAGIC | `violation_id` | Scope to one specific violation batch |
# MAGIC | `since_date` | Only records quarantined on or after this date (YYYY-MM-DD) |
# MAGIC | `dry_run` | `true` = preview only, nothing written (default: `true`) |
# MAGIC
# MAGIC ## Prerequisites
# MAGIC `dq_bad_records` must have the requeue-tracking columns added (run once):
# MAGIC ```sql
# MAGIC ALTER TABLE cdw_dev.domain_config.dq_bad_records
# MAGIC   ADD COLUMNS (reprocess_status STRING, reprocessed_at TIMESTAMP);
# MAGIC ```
# MAGIC This is already included in the `ADD COLUMN IF NOT EXISTS` block in
# MAGIC `ddl/dq_tables_ddl.py`.

# COMMAND ----------

dbutils.widgets.text("table_name",          "")
dbutils.widgets.text("source_catalog_name", "cdw_dev")
dbutils.widgets.text("source_schema_name",  "")
dbutils.widgets.text("target_catalog_name", "cdw_dev")
dbutils.widgets.text("target_schema_name",  "ml_cleaned_datasets")
dbutils.widgets.text("rule_id",      "")
dbutils.widgets.text("violation_id", "")

# COMMAND ----------

# Databricks notebook source
# MAGIC %md
# MAGIC # LakeWatch DQ — Remediation / Requeue
# MAGIC
# MAGIC Re-validates quarantined records from `dq_bad_records` against the
# MAGIC **current** approved rules in `dq_rules`.  Use this after:
# MAGIC - Fixing a rule that was too strict (editing via the management UI and
# MAGIC   getting the UPDATE approved), or
# MAGIC - Disabling / deleting a rule that was incorrectly quarantining good data.
# MAGIC
# MAGIC ## What it does
# MAGIC For every bad record in scope:
# MAGIC 1. Reconstruct the original row from `bad_record_data` (stored as JSON).
# MAGIC 2. Re-apply every **current active rule** for that table.
# MAGIC 3. If the row now passes all blocking rules it is:
# MAGIC    - Merged (INSERT-only MERGE) into `cdw_dev.ml_cleaned_datasets.<table>`.
# MAGIC    - Marked `reprocess_status = 'REPROMOTED'` and `reprocessed_at = now()`
# MAGIC      in `dq_bad_records` (the original audit row is kept; only the status
# MAGIC      columns are updated — the bad-record history is never deleted).
# MAGIC    - Written as a new `REQUEUE` entry in `dq_logs`.
# MAGIC 4. Rows that still fail at least one blocking rule are left in
# MAGIC    `dq_bad_records` unchanged (`reprocess_status = 'STILL_FAILING'`).
# MAGIC 5. Rows that pass all rules but fail at least one `AUDIT_ONLY` rule are
# MAGIC    promoted but their `AUDIT_ONLY` violation is re-logged.
# MAGIC
# MAGIC ## enforcement_action awareness
# MAGIC Identical to `dq_executor.py`:
# MAGIC - `BLOCK_AND_AUDIT` (or NULL/unrecognised): a violation **blocks** promotion.
# MAGIC - `AUDIT_ONLY`: a violation is **logged** but the row is still promoted.
# MAGIC
# MAGIC ## Filters (widgets)
# MAGIC | Widget | Effect |
# MAGIC |---|---|
# MAGIC | `table_name` | Scope to one table; blank = all tables in the schema |
# MAGIC | `source_catalog_name` | Catalog the quarantined records originally came from (required) |
# MAGIC | `source_schema_name` | Schema the quarantined records originally came from (required) |
# MAGIC | `target_catalog_name` | Catalog to promote passing records into (required) |
# MAGIC | `target_schema_name` | Schema to promote passing records into (required) |
# MAGIC | `rule_id` | Scope to records quarantined by one specific rule |
# MAGIC | `violation_id` | Scope to one specific violation batch |
# MAGIC | `since_date` | Only records quarantined on or after this date (YYYY-MM-DD) |
# MAGIC | `dry_run` | `true` = preview only, nothing written (default: `true`) |
# MAGIC
# MAGIC ## Prerequisites
# MAGIC `dq_bad_records` must have the requeue-tracking columns added (run once):
# MAGIC ```sql
# MAGIC ALTER TABLE cdw_dev.domain_config.dq_bad_records
# MAGIC   ADD COLUMNS (reprocess_status STRING, reprocessed_at TIMESTAMP);
# MAGIC ```
# MAGIC This is already included in the `ADD COLUMN IF NOT EXISTS` block in
# MAGIC `ddl/dq_tables_ddl.py`.

# COMMAND ----------

import json
import sys
import os
import re
from datetime import datetime, timezone

from pyspark.sql import SparkSession, functions as F

# dq_framework lives one directory up from this notebook when it is deployed
# alongside dq_run.py; adjust FRAMEWORK_PATH if your layout differs.
FRAMEWORK_PATH = os.path.join(os.path.dirname(os.path.abspath("__file__")),
                               "dq_framework")
sys.path.append(FRAMEWORK_PATH)

from dq_executor import (
    fetch_rules,
    apply_rule_based_casting,
    safe_cache,
    safe_unpersist,
    is_blocking_rule,
    ROW_ID_COLUMN,
    HASH_KEY_COLUMN,
    HOLD_BACK_SEVERITIES,
)
from query_builder import construct_query, normalize_type
from dq_logger import dq_logs, _write_log
from dq_error_logger import dq_error_logs

# ---------------------------------------------------------------------------
# Spark session
# ---------------------------------------------------------------------------
spark = SparkSession.builder \
    .appName("DQRequeue") \
    .enableHiveSupport() \
    .getOrCreate()

# ---------------------------------------------------------------------------
# Configuration (shared with dq_run.py via config.yaml)
# ---------------------------------------------------------------------------
import yaml

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath("__file__")),
                            "config.yaml")
with open(CONFIG_PATH, "r") as _f:
    _config = yaml.safe_load(_f) or {}

CONFIG_CATALOG  = _config.get("config_catalog",  "dev_platform")
CONFIG_SCHEMA   = _config.get("config_schema",   "data_quality_config")
RESULT_CATALOG  = _config.get("result_catalog",  "dev_platform")
RESULT_SCHEMA   = _config.get("result_schema",   "data_quality_config")
# NOTE: cleaned_catalog/cleaned_schema now come from the target_catalog_name/
# target_schema_name widgets below (overridable per run), not fixed constants.

BAD_RECORDS_TABLE = f"{RESULT_CATALOG}.{RESULT_SCHEMA}.dq_bad_records"
RULES_TABLE       = f"{CONFIG_CATALOG}.{CONFIG_SCHEMA}.dq_rules"
LOGS_TABLE        = f"{RESULT_CATALOG}.{RESULT_SCHEMA}.dq_logs"

# ---------------------------------------------------------------------------
# Widgets — initial state: table_name, source_catalog_name, source_schema_name,
# target_catalog_name, target_schema_name (plus the existing scope filters).
# All five default from config.yaml but can be overridden per run.
# ---------------------------------------------------------------------------
# dbutils.widgets.text("table_name",          "")
# dbutils.widgets.text("source_catalog_name", _config.get("catalog", "cdw_dev"))
# dbutils.widgets.text("source_schema_name",  _config.get("source_schema", ""))
# dbutils.widgets.text("target_catalog_name", _config.get("cleaned_catalog", "cdw_dev"))
# dbutils.widgets.text("target_schema_name",  _config.get("cleaned_schema", "ml_cleaned_datasets"))
# dbutils.widgets.text("rule_id",      "")
# dbutils.widgets.text("violation_id", "")
dbutils.widgets.text("since_date",   "")
dbutils.widgets.dropdown("dry_run",  "true", ["true", "false"])

table_name          = dbutils.widgets.get("table_name").strip() or None
source_catalog_name = dbutils.widgets.get("source_catalog_name").strip()
source_schema_name  = dbutils.widgets.get("source_schema_name").strip()
target_catalog_name = dbutils.widgets.get("target_catalog_name").strip()
target_schema_name  = dbutils.widgets.get("target_schema_name").strip()
rule_id_flt  = dbutils.widgets.get("rule_id").strip()    or None
violation_id_flt = dbutils.widgets.get("violation_id").strip() or None
since_date   = dbutils.widgets.get("since_date").strip()  or None
dry_run      = dbutils.widgets.get("dry_run").strip().lower() == "true"

if not source_catalog_name or not source_schema_name:
    raise ValueError("source_catalog_name and source_schema_name are required.")
if not target_catalog_name or not target_schema_name:
    raise ValueError("target_catalog_name and target_schema_name are required.")

batch_timestamp = datetime.now(timezone.utc)

print(f"Requeue | source={source_catalog_name}.{source_schema_name} "
      f"target={target_catalog_name}.{target_schema_name} "
      f"table={table_name or 'ALL'} rule_id={rule_id_flt or 'ALL'} "
      f"violation_id={violation_id_flt or 'ALL'} "
      f"since_date={since_date or 'ALL'} dry_run={dry_run}")

# COMMAND ----------
# MAGIC %md ### Step 1 — Load quarantined records in scope

# COMMAND ----------

def _bad_records_in_scope():
    """Return a DataFrame of dq_bad_records rows that match the widget filters
    and have not already been repromoted."""
    filters = [
        f"LOWER(catalog_name) = LOWER('{source_catalog_name}')",
        f"LOWER(schema_name)  = LOWER('{source_schema_name}')",
        "(reprocess_status IS NULL OR reprocess_status = 'STILL_FAILING')",
    ]
    if table_name:
        filters.append(f"LOWER(table_name) = LOWER('{table_name}')")
    if violation_id_flt:
        safe_vid = violation_id_flt.replace("'", "''")
        filters.append(f"violation_id = '{safe_vid}'")
    if since_date:
        filters.append(f"batch_timestamp >= '{since_date}'")
    # rule_id filter is applied post-join because violation_id can be shared
    # across several rules for the same batch
    where = " AND ".join(filters)
    df = spark.sql(f"SELECT * FROM {BAD_RECORDS_TABLE} WHERE {where}")

    if rule_id_flt:
        # join to dq_logs to find violation_ids linked to the target rule
        safe_rid = rule_id_flt.replace("'", "''")
        linked_ids = spark.sql(f"""
            SELECT DISTINCT violation_id
            FROM {LOGS_TABLE}
            WHERE rule_id = '{safe_rid}'
        """)
        df = df.join(linked_ids, on="violation_id", how="inner")

    return df

bad_df = _bad_records_in_scope()
total_bad = bad_df.count()
print(f"Quarantined records in scope: {total_bad:,}")
if total_bad == 0:
    print("Nothing to requeue. Exiting.")
    dbutils.notebook.exit("No records in scope")

# COMMAND ----------
# MAGIC %md ### Step 2 — Load current active rules for the schema

# COMMAND ----------

_, all_rules = fetch_rules(spark, CONFIG_CATALOG, CONFIG_SCHEMA,
                           source_catalog_name, source_schema_name)

# Group by (catalog, schema, table) so we can re-validate per table
from collections import defaultdict
rules_by_table = defaultdict(list)
for rule in all_rules:
    rules_by_table[(rule["catalog_name"].lower(),
                    rule["schema_name"].lower(),
                    rule["table_name"].lower())].append(rule)

print(f"Active rules loaded: {len(all_rules)} across "
      f"{len(rules_by_table)} table(s)")

# If scoped to one violation_id, only re-run the specific rule(s) that
# violation_id actually came from -- not every active rule for the table.
# If no violation_id was given, this stays None and every active rule for
# the table gets re-run, same as before.
violation_rule_ids = None
if violation_id_flt:
    safe_vid_lookup = violation_id_flt.replace("'", "''")
    violation_rule_ids = {
        r["rule_id"] for r in spark.sql(f"""
            SELECT DISTINCT rule_id FROM {LOGS_TABLE}
            WHERE violation_id = '{safe_vid_lookup}'
        """).collect()
    }
    print(f"Scoped to violation_id={violation_id_flt} -> "
          f"rule_id(s): {sorted(violation_rule_ids) or ['NONE FOUND']}")

# COMMAND ----------
# MAGIC %md ### Step 3 — Re-validate each table's bad records

# COMMAND ----------

# Result accumulators (populated per table, read in step 4)
repromote_rows_by_table   = {}   # table -> list of Row objects to INSERT
still_failing_br_ids      = []   # list of br_id strings
still_failing_details     = []   # list of dicts for display
repromote_details         = []   # list of dicts for display

# Distinct table names in scope (from the bad records, not dq_rules — a rule
# may have been fully deleted but old bad records still exist for it)
scope_tables = (bad_df
                .select("catalog_name", "schema_name", "table_name")
                .distinct()
                .collect())

for trow in scope_tables:
    cat, sch, tbl = trow["catalog_name"], trow["schema_name"], trow["table_name"]
    tkey = (cat.lower(), sch.lower(), tbl.lower())
    table_rules = rules_by_table.get(tkey, [])
    if violation_rule_ids is not None:
        table_rules = [r for r in table_rules if r["rule_id"] in violation_rule_ids]
    fq_table = f"{cat}.{sch}.{tbl}"

    if not table_rules:
        # Skip rather than silently promoting records with zero rules to
        # check against -- can happen if violation_id_flt's rule lookup
        # missed, or every rule for this table was since deleted.
        reason = ("no rule found for the given violation_id" if violation_rule_ids is not None
                  else "no active rules for this table")
        print(f"\n{'='*60}")
        print(f"Table: {fq_table} | ⚠️  Skipping — {reason}. "
              f"Records left as-is in dq_bad_records.")
        continue

    print(f"\n{'='*60}")
    print(f"Table: {fq_table} | Active rules: {len(table_rules)}")

    # -----------------------------------------------------------------
    # Filter bad_df to this table only
    # -----------------------------------------------------------------
    tbl_bad_df = bad_df.filter(
        (F.lower(F.col("catalog_name")) == cat.lower()) &
        (F.lower(F.col("schema_name"))  == sch.lower()) &
        (F.lower(F.col("table_name"))   == tbl.lower())
    )
    tbl_count = tbl_bad_df.count()
    print(f"  Quarantined records: {tbl_count:,}")

    # -----------------------------------------------------------------
    # Reconstruct original rows from the bad_record_data JSON column
    # -----------------------------------------------------------------
    # bad_record_data is a JSON string; we parse it with from_json.
    # To infer the schema we sample the first row's JSON string, then
    # use it for the whole table.
    sample_json = (tbl_bad_df
                   .select("bad_record_data")
                   .filter(F.col("bad_record_data").isNotNull())
                   .limit(1)
                   .collect())
    if not sample_json:
        print(f"  ⚠️  No non-null bad_record_data rows — skipping.")
        continue

    try:
        sample_dict = json.loads(sample_json[0]["bad_record_data"])
        inferred_schema = spark.createDataFrame([sample_dict]).schema
    except Exception as e:
        print(f"  ⚠️  Could not infer schema from bad_record_data: {e} — skipping.")
        continue

    # Parse every bad_record_data row into a struct column and expand it
    reconstructed = (tbl_bad_df
                     .withColumn("_rec",
                                 F.from_json(F.col("bad_record_data"),
                                             inferred_schema))
                     .select("br_id", "violation_id",
                             F.col("_rec.*")))
    reconstructed = reconstructed.withColumn(
        ROW_ID_COLUMN, F.concat(F.lit("requeue_"), F.col("br_id")))

    reconstructed = safe_cache(reconstructed)

    # -----------------------------------------------------------------
    # Apply rule-based casting (same as main executor)
    # -----------------------------------------------------------------
    if table_rules:
        reconstructed, _ = apply_rule_based_casting(reconstructed, table_rules)

    # -----------------------------------------------------------------
    # Evaluate every active blocking rule; collect failing row IDs
    # -----------------------------------------------------------------
    fail_row_ids    = set()   # {_dq_row_id} — fails at least one blocking rule
    audit_only_ids  = set()   # {_dq_row_id} — fails AUDIT_ONLY rule only
    rule_fail_log   = []      # [(rule, violation_count, status)] for REQUEUE logging

    # Register the reconstructed rows as a temp view so construct_query
    # can SELECT from it using the same "" "" <view_name> pattern the
    # main executor uses for its batch_view.
    REQUEUE_VIEW = "_dq_requeue_view"
    reconstructed.createOrReplaceTempView(REQUEUE_VIEW)

    for rule in table_rules:
        ctype = rule.get("_ctype") or normalize_type(
            rule.get("condition_type", ""))
        # Table-level statistical rules don't apply to individual rows
        if ctype in ("ROW_COUNT_TREND", "KPI_CHECK", "CUSTOM_RULE"):
            continue
        try:
            query = construct_query(
                spark,
                RESULT_CATALOG, RESULT_SCHEMA,
                rule.get("pipeline_key"), rule.get("rule_id"),
                "", "", REQUEUE_VIEW,          # run against the temp view
                rule.get("column_name"), rule.get("condition_type"),
                rule.get("condition_criteria"),
                rule.get("condition_category"), batch_timestamp,
                real_catalog=cat, real_schema=sch, real_table=tbl)

            sc, fc, sev, vid, fkeys_df, fkey_col = dq_logs(
                spark, RESULT_CATALOG, RESULT_SCHEMA,
                rule.get("rule_id"), query, rule.get("pipeline_key"),
                cat, sch, tbl,
                rule.get("column_name"),
                rule.get("condition_category"), ctype,
                rule.get("severity"), batch_timestamp,
                int(rule.get("violation_threshold") or 0))

            if fc > 0 and fkeys_df is not None:
                rule_fail_log.append((rule, fc, "Fail"))
                if is_blocking_rule(rule):
                    if fkey_col == ROW_ID_COLUMN:
                        fkeys = [r[0] for r in fkeys_df.collect()]
                        fail_row_ids.update(fkeys)
                    elif fkey_col == HASH_KEY_COLUMN:
                        fkeys = [r[0] for r in fkeys_df.collect()]
                        keys_lit = ",".join("'" + str(k).replace("'", "\\'") + "'"
                                            for k in fkeys)
                        sql = ("SELECT {rid} FROM {v} WHERE {hk} IN ({ks})"
                               .format(rid=ROW_ID_COLUMN, v=REQUEUE_VIEW,
                                       hk=HASH_KEY_COLUMN, ks=keys_lit))
                        matched = spark.sql(sql).collect()
                        fail_row_ids.update(r[0] for r in matched)
                else:
                    if fkeys_df is not None:
                        if fkey_col == ROW_ID_COLUMN:
                            audit_only_ids.update(
                                r[0] for r in fkeys_df.collect())

        except Exception as e:
            dq_error_logs(spark, RESULT_CATALOG, RESULT_SCHEMA,
                          rule.get("rule_id"), rule.get("pipeline_key"),
                          None, cat, sch, tbl,
                          f"Requeue rule evaluation error: {e}", batch_timestamp)
            print(f"  ⚠️  Rule {rule.get('rule_id')} errored: {e}")

    spark.catalog.dropTempView(REQUEUE_VIEW)

    # -----------------------------------------------------------------
    # Partition into repromote vs still-failing
    # -----------------------------------------------------------------
    recon_collected = reconstructed.collect()
    safe_unpersist(reconstructed)

    promote_rows  = []
    failing_brs   = []

    for row in recon_collected:
        row_id = row[ROW_ID_COLUMN]
        br_id  = row["br_id"]
        if row_id in fail_row_ids:
            failing_brs.append(br_id)
            still_failing_details.append({
                "table": fq_table,
                "br_id": br_id,
                "outcome": "STILL_FAILING",
            })
        else:
            # Convert Row -> dict, strip internal columns
            rd = {k: v for k, v in row.asDict().items()
                  if not k.startswith("_dq_") and k not in ("br_id", "violation_id")}
            promote_rows.append((br_id, rd))
            repromote_details.append({
                "table": fq_table,
                "br_id": br_id,
                "outcome": ("REPROMOTED_WITH_AUDIT_ONLY" if row_id in audit_only_ids
                            else "REPROMOTED"),
            })

    still_failing_br_ids.extend(failing_brs)
    repromote_rows_by_table[(cat, sch, tbl)] = promote_rows

    print(f"  To repromote   : {len(promote_rows):,}")
    print(f"  Still failing  : {len(failing_brs):,}")

# COMMAND ----------
# MAGIC %md ### Step 4 — Preview

# COMMAND ----------

preview_schema = "br_id STRING, table STRING, outcome STRING"
all_preview = repromote_details + still_failing_details

if all_preview:
    preview_df = spark.createDataFrame(
        [(r["br_id"], r["table"], r["outcome"]) for r in all_preview],
        schema=preview_schema)
    display(preview_df.orderBy("outcome", "table"))
else:
    print("No records to preview.")

total_to_promote = sum(len(v) for v in repromote_rows_by_table.values())
total_still_failing = len(still_failing_br_ids)
print(f"\nSummary — to repromote: {total_to_promote:,} | "
      f"still failing: {total_still_failing:,}")

if dry_run:
    print("\nDRY RUN — no changes written. "
          "Set dry_run=false to apply.")
    dbutils.notebook.exit(
        f"DRY RUN: would repromote {total_to_promote}, "
        f"still failing {total_still_failing}")

# COMMAND ----------
# MAGIC %md ### Step 5 — Write changes (only when dry_run = false)

# COMMAND ----------

if total_to_promote == 0 and total_still_failing == 0:
    print("Nothing to write.")
    dbutils.notebook.exit("Nothing to write")

# -----------------------------------------------------------------
# 5a. Promote rows into ml_cleaned_datasets
# -----------------------------------------------------------------
promoted_count   = 0
repromoted_br_ids = []

for (cat, sch, tbl), promote_rows in repromote_rows_by_table.items():
    if not promote_rows:
        continue
    fq_table = f"{cat}.{sch}.{tbl}"
    target   = f"{target_catalog_name}.{target_schema_name}.{tbl}"

    br_ids_to_promote = [br for br, _ in promote_rows]
    row_dicts         = [rd for _, rd in promote_rows]
    repromoted_br_ids.extend(br_ids_to_promote)

    try:
        promote_df = spark.createDataFrame(row_dicts)
        promote_df = safe_cache(promote_df)

        # Determine merge key: prefer cdw_hash_key, fall back to all columns
        if HASH_KEY_COLUMN in promote_df.columns:
            merge_key  = HASH_KEY_COLUMN
            merge_cond = f"target.`{HASH_KEY_COLUMN}` = source.`{HASH_KEY_COLUMN}`"
        else:
            # No stable key — use all non-internal columns; this is a
            # best-effort dedup; exact-duplicate detection is correct
            shared_cols = [c for c in promote_df.columns
                           if not c.startswith("_dq_")]
            merge_cond  = " AND ".join(
                f"target.`{c}` <=> source.`{c}`" for c in shared_cols)

        # CREATE the table if it does not exist yet (first ever promotion)
        try:
            spark.sql(f"DESCRIBE TABLE {target}")
        except Exception:
            promote_df.write \
                .format("delta") \
                .mode("overwrite") \
                .option("overwriteSchema", "true") \
                .saveAsTable(target)
            safe_unpersist(promote_df)
            promoted_count += len(row_dicts)
            print(f"  Created and populated {target} ({len(row_dicts):,} rows)")
            continue

        # INSERT-only MERGE (never update existing Silver rows)
        promote_df.createOrReplaceTempView("_requeue_promote")
        spark.sql(f"""
            MERGE INTO {target} AS target
            USING _requeue_promote AS source
            ON {merge_cond}
            WHEN NOT MATCHED THEN INSERT *
        """)
        spark.catalog.dropTempView("_requeue_promote")
        safe_unpersist(promote_df)
        promoted_count += len(row_dicts)
        print(f"  Merged {len(row_dicts):,} rows → {target}")

    except Exception as e:
        dq_error_logs(spark, RESULT_CATALOG, RESULT_SCHEMA, None, None, None,
                      cat, sch, tbl,
                      f"Requeue Silver merge error: {e}", batch_timestamp)
        print(f"  ❌ Error promoting to {target}: {e}")

# -----------------------------------------------------------------
# 5b. Update dq_bad_records status
# -----------------------------------------------------------------
update_ts_str = batch_timestamp.strftime("%Y-%m-%d %H:%M:%S")

if repromoted_br_ids:
    # Spark UPDATE on Delta — partition by br_id list
    # Large sets are split into chunks to stay inside query-plan limits
    CHUNK = 500
    for i in range(0, len(repromoted_br_ids), CHUNK):
        chunk = repromoted_br_ids[i:i + CHUNK]
        ids_lit = ", ".join(f"'{bid}'" for bid in chunk)
        spark.sql(f"""
            UPDATE {BAD_RECORDS_TABLE}
            SET    reprocess_status = 'REPROMOTED',
                   reprocessed_at   = TIMESTAMP '{update_ts_str}'
            WHERE  br_id IN ({ids_lit})
        """)
    print(f"  Marked {len(repromoted_br_ids):,} bad-record rows REPROMOTED")

if still_failing_br_ids:
    for i in range(0, len(still_failing_br_ids), CHUNK):
        chunk = still_failing_br_ids[i:i + CHUNK]
        ids_lit = ", ".join(f"'{bid}'" for bid in chunk)
        spark.sql(f"""
            UPDATE {BAD_RECORDS_TABLE}
            SET    reprocess_status = 'STILL_FAILING',
                   reprocessed_at   = TIMESTAMP '{update_ts_str}'
            WHERE  br_id IN ({ids_lit})
        """)
    print(f"  Marked {len(still_failing_br_ids):,} bad-record rows STILL_FAILING")

# -----------------------------------------------------------------
# 5c. Write REQUEUE entries to dq_logs (one row per table)
# -----------------------------------------------------------------
for (cat, sch, tbl), promote_rows in repromote_rows_by_table.items():
    if not promote_rows:
        continue
    _write_log(spark, RESULT_CATALOG, RESULT_SCHEMA,
               rule_id=None,
               pipeline_key=None,
               catalog_name=cat, schema_name=sch, table_name=tbl,
               column_name=None,
               condition_category="REQUEUE",
               condition_type="REQUEUE",
               status="Pass",
               violation_count=0,
               violation_id=violation_id_flt,
               severity="Info",
               batch_timestamp=batch_timestamp)

# COMMAND ----------
# MAGIC %md ### Step 6 — Final summary

# COMMAND ----------

print("\n" + "=" * 60)
print("REQUEUE COMPLETE")
print(f"  Records repromoted to Silver : {promoted_count:,}")
print(f"  Records still failing        : {total_still_failing:,}")
print(f"  dq_bad_records rows updated  : "
      f"{len(repromoted_br_ids) + len(still_failing_br_ids):,}")
print(f"  dq_logs REQUEUE entries      : {len(repromote_rows_by_table):,}")
print("=" * 60)